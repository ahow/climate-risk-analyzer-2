import { z } from 'zod';
import { insertCompanySchema, companies, documents, analysisResults, measureScores } from './schema';

// ============================================
// SHARED ERROR SCHEMAS
// ============================================
export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

// ============================================
// API CONTRACT
// ============================================
export const api = {
  companies: {
    list: {
      method: 'GET' as const,
      path: '/api/companies',
      input: z.object({
        search: z.string().optional(),
        sort: z.enum(['score', 'name', 'updated']).optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof companies.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/companies/:id',
      responses: {
        200: z.custom<typeof companies.$inferSelect & { documents: typeof documents.$inferSelect[], analysisResults: typeof analysisResults.$inferSelect[], measureScores: typeof measureScores.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    import: {
      method: 'POST' as const,
      path: '/api/companies/import',
      input: z.object({
        url: z.string().url(),
      }),
      responses: {
        200: z.object({ message: z.string(), count: z.number() }),
        400: errorSchemas.validation,
      },
    },
    analyze: {
      method: 'POST' as const,
      path: '/api/companies/:id/analyze',
      input: z.object({
        forceRefresh: z.boolean().optional(),
      }),
      responses: {
        202: z.object({ message: z.string(), jobId: z.string().optional() }),
        404: errorSchemas.notFound,
      },
    },
  },
  documents: {
    list: {
      method: 'GET' as const,
      path: '/api/companies/:id/documents',
      responses: {
        200: z.array(z.custom<typeof documents.$inferSelect>()),
        404: errorSchemas.notFound,
      },
    },
  },
  batch: {
    analyze: {
      method: 'POST' as const,
      path: '/api/batch/analyze',
      input: z.object({
        companyIds: z.array(z.number()).optional(),
      }),
      responses: {
        202: z.object({ message: z.string(), totalCompanies: z.number() }),
      },
    },
    status: {
      method: 'GET' as const,
      path: '/api/batch/status',
      responses: {
        200: z.object({
          isRunning: z.boolean(),
          currentCompany: z.string().optional(),
          completed: z.number(),
          total: z.number(),
          failed: z.number(),
        }),
      },
    },
  },
  export: {
    spreadsheet: {
      method: 'GET' as const,
      path: '/api/export/spreadsheet',
      responses: {
        200: z.any(),
      },
    },
  },
};

// ============================================
// REQUIRED: buildUrl helper
// ============================================
export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

// ============================================
// TYPE HELPERS
// ============================================
export type ImportInput = z.infer<typeof api.companies.import.input>;
export type AnalyzeInput = z.infer<typeof api.companies.analyze.input>;
