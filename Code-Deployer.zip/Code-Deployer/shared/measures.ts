export interface Measure {
  id: string;
  category: string;
  categoryNumber: number;
  title: string;
  definition: string;
  whatConstitutesEvidence: string[];
  whatDoesNotConstituteEvidence: string[];
  scoringGuidance: Record<number, string>;
  coverageMetric?: string;
  notes?: string;
  climateSpecificity: 'HIGH' | 'MEDIUM' | 'LOW';
}

export const CATEGORIES = [
  { number: 1, name: "Governance & Strategic Oversight", measures: "M01-M07" },
  { number: 2, name: "Risk Identification & Assessment", measures: "M08-M16" },
  { number: 3, name: "Asset Design & Resilience", measures: "M17-M21" },
  { number: 4, name: "Crisis Management & Response", measures: "M22-M26" },
  { number: 5, name: "Supply Chain Resilience", measures: "M27-M31" },
  { number: 6, name: "Insurance & Risk Transfer", measures: "M32-M35" },
  { number: 7, name: "Data Quality & Assurance", measures: "M36-M37" },
  { number: 8, name: "Social & Community Resilience", measures: "M38-M39" },
  { number: 9, name: "Performance Metrics & Continuous Improvement", measures: "M40-M44" }
];

export const MEASURES: Measure[] = [
  {
    id: "M01",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Board-level Physical Risk Oversight",
    definition: "Board of Directors has explicit oversight responsibility for physical climate risks (not just general climate/sustainability issues).",
    whatConstitutesEvidence: [
      "Board committee charter specifically mentioning physical/adaptation/resilience risks",
      "Documented board meeting agendas/minutes discussing physical climate risks",
      "Board expertise in climate science, risk management, or sustainability",
      "Board approval of climate adaptation strategies or major adaptation investments"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic sustainability committee without climate risk specificity",
      "Board oversight of ESG or climate mitigation (decarbonization) only",
      "General risk committee without documented physical climate risk discussions"
    ],
    scoringGuidance: {
      1: "Board mentions climate in general terms without physical risk specificity",
      2: "Board committee has climate in mandate but no evidence of physical risk focus",
      3: "Board committee explicitly oversees physical climate risks, meets ≥2x/year on topic",
      4: "Board with climate expertise, quarterly physical risk reviews, strategic decisions documented",
      5: "Best practice governance with board KPIs, external reporting on oversight activities"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M02",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Senior Management Responsibility",
    definition: "C-suite executives have defined, documented responsibilities for managing physical climate risks with accountability mechanisms.",
    whatConstitutesEvidence: [
      "Named executive role (e.g., Chief Risk Officer, Chief Sustainability Officer) with physical climate risk in job description/mandate",
      "Executive KPIs or objectives explicitly including physical risk management",
      "Executive compensation linked to climate resilience/adaptation metrics",
      "Regular management committee meetings on physical climate risks"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic sustainability officer without physical risk mandate",
      "Executive responsibility for emissions reduction only",
      "Vague statements about 'management oversight'"
    ],
    scoringGuidance: {
      1: "General management oversight without named accountabilities",
      2: "Named role but no evidence of specific physical risk responsibilities",
      3: "C-suite executive with explicit physical risk mandate, regular reporting documented",
      4: "Executive KPIs or compensation linked to physical risk metrics",
      5: "Enterprise-wide accountability with cross-functional coordination and performance tracking"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M03",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Integration into Enterprise Risk Management",
    definition: "Physical climate risks are formally integrated into the company's enterprise risk management (ERM) framework, not managed as a separate sustainability issue.",
    whatConstitutesEvidence: [
      "Physical climate risks listed in enterprise risk register/risk matrix",
      "Climate risks assessed using standard ERM methodology (likelihood × impact, risk appetite, etc.)",
      "Integration with other enterprise risks (financial, operational, strategic, reputational)",
      "Board/audit committee oversight of climate risks through ERM process",
      "Risk quantification using same methods as other enterprise risks"
    ],
    whatDoesNotConstituteEvidence: [
      "Climate risks mentioned in sustainability report but not in risk disclosures",
      "Separate climate risk assessment not connected to ERM",
      "Generic statement that 'we consider climate as a risk'"
    ],
    scoringGuidance: {
      1: "Climate mentioned in passing but not in formal risk framework",
      2: "Climate risks listed but not assessed with ERM methodology",
      3: "Physical risks in risk register, assessed using standard ERM methods",
      4: "Full integration with risk appetite statements, mitigation plans, regular monitoring",
      5: "Climate quantified using same financial models as other risks, fully embedded in ERM processes"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M04",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Public Adaptation/Resilience Commitments",
    definition: "Company has made specific, measurable, time-bound public commitments to climate adaptation or resilience building (not decarbonization targets).",
    whatConstitutesEvidence: [
      "Public commitment to adaptation goals (e.g., 'climate-proof all facilities by 2030')",
      "Specific, quantified targets (e.g., 'reduce climate-related downtime by 50% by 2025')",
      "Time-bound commitments with interim milestones",
      "Regular public reporting on progress against commitments",
      "Science-based adaptation targets (e.g., aligned with warming scenarios)"
    ],
    whatDoesNotConstituteEvidence: [
      "Net zero or emissions reduction commitments (these are mitigation, not adaptation)",
      "Generic aspirations without specific targets or timelines",
      "Internal goals not publicly disclosed"
    ],
    scoringGuidance: {
      1: "Aspiration to build resilience without specific commitments",
      2: "Qualitative commitment without measurable targets or timelines",
      3: "Public commitment with time-bound goals (but limited specificity)",
      4: "Specific, measurable targets with interim milestones and progress reporting",
      5: "Science-based, externally validated commitments with regular third-party progress assessments"
    },
    notes: "This is one of the most difficult measures to score high, as few companies make explicit adaptation commitments.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M05",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Scenario Analysis & Strategic Planning",
    definition: "Company uses formal climate scenario analysis (e.g., IPCC scenarios) to assess physical risks under different warming futures and integrates insights into strategic planning.",
    whatConstitutesEvidence: [
      "Use of recognized climate scenarios: IPCC RCPs (2.6, 4.5, 8.5), SSPs, IEA scenarios, etc.",
      "Multiple time horizons analyzed (typically 2030, 2050, 2100 or similar)",
      "Assessment of physical risk impacts under each scenario",
      "Scenario insights integrated into business strategy, capital allocation, or M&A decisions",
      "Quantification of impacts under different scenarios"
    ],
    whatDoesNotConstituteEvidence: [
      "Acknowledgment that climate scenarios exist without conducting analysis",
      "Scenario analysis focused only on transition risks (policy, technology, market changes)",
      "Single scenario or single time horizon only"
    ],
    scoringGuidance: {
      1: "Awareness of scenarios without analysis conducted",
      2: "Scenario analysis mentioned but no details on scenarios or findings",
      3: "Analysis of ≥2 scenarios for ≥1 time horizon with some quantification",
      4: "Comprehensive analysis of ≥3 scenarios across multiple time horizons (2030, 2050+)",
      5: "Scenario analysis directly informing strategic decisions (capital allocation, site selection, etc.) with documented examples"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M06",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Stakeholder Engagement on Physical Risk",
    definition: "Company actively engages with key stakeholders (investors, customers, employees, communities, suppliers) specifically on physical climate risk management.",
    whatConstitutesEvidence: [
      "Investor engagement on physical risk exposure and management",
      "Customer communication about supply chain or product resilience",
      "Employee training or communication on climate risks and preparedness",
      "Community engagement on local climate adaptation (especially for facilities in vulnerable areas)",
      "Supplier engagement on supply chain climate resilience",
      "Documentation of engagement activities (meetings, surveys, workshops) and outcomes"
    ],
    whatDoesNotConstituteEvidence: [
      "General stakeholder engagement on sustainability without physical risk focus",
      "One-way communication (disclosure) without actual engagement/dialogue",
      "Engagement only on emissions reduction (mitigation)"
    ],
    scoringGuidance: {
      1: "Minimal documented stakeholder engagement on physical risks",
      2: "Engagement with 1-2 stakeholder groups in limited manner",
      3: "Regular engagement with ≥3 stakeholder groups with documented feedback",
      4: "Comprehensive engagement program with feedback integration into risk management",
      5: "Leading multi-stakeholder engagement with collaborative adaptation initiatives"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M07",
    category: "Governance & Strategic Oversight",
    categoryNumber: 1,
    title: "Policy Advocacy & Industry Collaboration",
    definition: "Company engages in policy advocacy or industry collaboration specifically on climate adaptation, resilience, or physical risk management (not just general climate policy).",
    whatConstitutesEvidence: [
      "Membership in adaptation-focused industry initiatives",
      "Policy advocacy for adaptation funding, resilient infrastructure, building codes, etc.",
      "Collaboration with peers, government, NGOs on adaptation solutions",
      "Thought leadership (white papers, conferences) on physical climate risk",
      "Support for adaptation-related regulations or standards"
    ],
    whatDoesNotConstituteEvidence: [
      "Membership in general sustainability groups without adaptation focus",
      "Policy advocacy solely on emissions reduction or climate mitigation",
      "General corporate political activity"
    ],
    scoringGuidance: {
      1: "No documented policy engagement on adaptation",
      2: "Membership in industry groups that mention adaptation among many topics",
      3: "Active participation in ≥1 adaptation-focused initiative with documented contributions",
      4: "Policy advocacy and multi-stakeholder collaboration with demonstrated impact",
      5: "Leadership role in shaping adaptation policy, standards, or industry best practices"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M08",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Hazard Identification & Prioritization",
    definition: "Company has systematically identified the specific physical climate hazards relevant to its operations and prioritized them based on likelihood and impact.",
    whatConstitutesEvidence: [
      "List of specific hazards identified: acute (floods, storms, wildfires, extreme heat, drought) and/or chronic (sea level rise, temperature shifts, water stress)",
      "Evidence of prioritization based on risk criteria (likelihood, impact, financial materiality)",
      "Geographic specificity (which hazards affect which locations)",
      "Number of priority hazards identified (more comprehensive = higher score)"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic mention of 'climate risks' without naming specific hazards",
      "List of hazards without any prioritization or geographic specificity",
      "Hazards mentioned only in hypothetical or scenario analysis context"
    ],
    scoringGuidance: {
      1: "Generic awareness of climate change without specific hazards identified",
      2: "1-2 hazards mentioned without prioritization or geographic detail",
      3: "≥3 priority hazards identified with geographic specificity",
      4: "Comprehensive hazard assessment (≥5 hazards) across all operations with prioritization",
      5: "Detailed hazard prioritization with quantified likelihood, impact, and financial materiality for each"
    },
    coverageMetric: "Number of distinct hazards assessed and % of operations/geographies covered",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M09",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Asset Exposure Mapping",
    definition: "Company has mapped which specific assets, facilities, or operations are exposed to which physical climate hazards.",
    whatConstitutesEvidence: [
      "Asset-level exposure mapping (facility names, locations, specific hazards)",
      "Use of GIS or mapping tools overlaying climate hazard data on asset locations",
      "Identification of high-risk assets or facilities",
      "Quantification of assets at risk (number of facilities, value of assets, % of capacity)"
    ],
    whatDoesNotConstituteEvidence: [
      "General statement that 'we have facilities in vulnerable areas'",
      "List of facility locations without hazard overlay",
      "Awareness of mapping tools without evidence of use"
    ],
    scoringGuidance: {
      1: "Awareness of asset locations without hazard exposure analysis",
      2: "Some exposure identification but <50% of assets mapped",
      3: "Exposure mapping covering 50-79% of assets by value with hazard identification",
      4: "Comprehensive mapping (80-94%) with multiple hazards per asset",
      5: "Detailed exposure analysis (≥95%) with financial quantification of assets at risk"
    },
    coverageMetric: "% of total assets by value (or number of facilities) with exposure assessed",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M10",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Vulnerability Assessment",
    definition: "Company has assessed the vulnerability or resilience of its assets to identified hazards (not just exposure, but likelihood of damage/disruption if hazard occurs).",
    whatConstitutesEvidence: [
      "Assessment of asset resilience characteristics (building standards, protective measures, age, etc.)",
      "Vulnerability scoring or classification (e.g., low/medium/high vulnerability)",
      "Identification of specific vulnerabilities (e.g., 'Facility X has inadequate flood defenses')",
      "Assessment of adaptive capacity (ability to respond and recover)"
    ],
    whatDoesNotConstituteEvidence: [
      "Exposure mapping without vulnerability assessment (exposure ≠ vulnerability)",
      "Generic statements about 'assessing resilience' without specifics",
      "Third-party data on vulnerability without company-specific assessment"
    ],
    scoringGuidance: {
      1: "No vulnerability assessment conducted",
      2: "Vulnerability mentioned for some assets without systematic assessment",
      3: "Vulnerability assessment covering 50-79% of high-risk assets",
      4: "Comprehensive assessment (80-94%) with vulnerability scoring methodology",
      5: "Detailed vulnerability analysis with adaptation planning and investment prioritization"
    },
    notes: "Key Distinction: Exposure (asset is in flood zone) vs. Vulnerability (asset lacks flood barriers and would be damaged by 1-meter flood)",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M11",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Scenario Modeling & Quantification",
    definition: "Company uses climate models or third-party tools to quantify physical risk impacts (not just qualitative assessment).",
    whatConstitutesEvidence: [
      "Use of climate models: Global Climate Models (GCMs), Regional Climate Models (RCMs), or third-party platforms (e.g., Jupiter, Four Twenty Seven, Climate X)",
      "Quantification of physical impacts: days of disruption, asset damage, crop loss, etc.",
      "Multiple scenarios and time horizons modeled",
      "Model validation or calibration to company-specific conditions"
    ],
    whatDoesNotConstituteEvidence: [
      "Qualitative scenario narratives without quantification",
      "Use of generic industry reports without company-specific modeling",
      "'We are exploring modeling tools' without evidence of actual use"
    ],
    scoringGuidance: {
      1: "Awareness of modeling tools without use",
      2: "Use of third-party data/reports without company-specific modeling",
      3: "Scenario modeling for ≥2 scenarios covering priority risks",
      4: "Comprehensive modeling with ≥3 scenarios, multiple hazards, multiple time horizons",
      5: "Advanced modeling with validation, regular updates, and integration into financial planning"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M12",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Financial Impact Quantification",
    definition: "Company has quantified the potential financial impacts of physical climate risks in monetary terms (revenue, costs, asset impairments, etc.).",
    whatConstitutesEvidence: [
      "Quantification of potential losses: revenue impact, EBITDA impact, capex requirements, asset impairments",
      "Financial impact ranges or scenarios (e.g., '$50-100M annual impact under RCP 4.5')",
      "Assessment of insurance costs or uninsurable risks",
      "Quantification of adaptation investment needs",
      "Integration of financial impacts into business planning or financial disclosures"
    ],
    whatDoesNotConstituteEvidence: [
      "Qualitative statements about 'potential material impacts'",
      "Physical impact quantification without financial translation (e.g., '10 days downtime' without cost)",
      "Generic industry estimates not specific to company"
    ],
    scoringGuidance: {
      1: "No financial quantification, qualitative discussion only",
      2: "Directional financial impact discussion (e.g., 'could be material') without numbers",
      3: "Quantification for ≥1 major hazard or geography with specific $ figures",
      4: "Comprehensive quantification across multiple hazards/scenarios",
      5: "Detailed financial modeling integrated into enterprise financial planning and risk management"
    },
    notes: "This is often the weakest area for companies. Even scores of 2-3 are relatively good performance.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M13",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Supply Chain Risk Assessment",
    definition: "Company has assessed physical climate risks in its supply chain, including supplier exposure and vulnerability.",
    whatConstitutesEvidence: [
      "Assessment of supplier locations and exposure to climate hazards",
      "Identification of critical supply chain vulnerabilities",
      "Supply chain risk mapping or heat maps",
      "Supplier engagement or surveys on climate resilience",
      "Tier 1 and/or Tier 2+ supplier assessment"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic supply chain sustainability programs without physical risk focus",
      "Awareness of supply chain risks without assessment conducted",
      "Third-party supply chain data without company-specific analysis"
    ],
    scoringGuidance: {
      1: "Awareness of supply chain climate risks without assessment",
      2: "Ad hoc or limited supplier risk assessment (<50% coverage)",
      3: "Risk assessment covering 50-79% of suppliers by spend",
      4: "Comprehensive assessment (80-94%) with geographic mapping and multi-tier analysis",
      5: "Detailed supply chain risk analysis with quantified vulnerabilities and mitigation plans"
    },
    coverageMetric: "% of supplier spend or % of critical suppliers assessed",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M14",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Third-Party Validation & External Review",
    definition: "Company's physical risk assessment has been reviewed, validated, or assured by external parties (consultants, academics, auditors).",
    whatConstitutesEvidence: [
      "External review by climate risk consultants or engineering firms",
      "Academic partnerships or peer review of methodology",
      "Certification or accreditation of risk assessment (e.g., ISO standards)",
      "Independent assurance of climate disclosures by auditors",
      "Public disclosure of external validation reports"
    ],
    whatDoesNotConstituteEvidence: [
      "Use of third-party tools/data without validation of company's own assessment",
      "General sustainability report assurance that doesn't cover climate risk assessment",
      "Membership in industry groups without specific external review"
    ],
    scoringGuidance: {
      0: "No external validation",
      2: "Informal external consultation without formal review",
      3: "Third-party review of risk assessment methodology",
      4: "External validation of risk quantification and findings with report",
      5: "Independent limited or reasonable assurance with public disclosure"
    },
    notes: "This is rare and typically only seen in leading companies. Score 0 is very common.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M15",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Regulatory Compliance & Disclosure",
    definition: "Company complies with relevant regulatory requirements for physical climate risk disclosure.",
    whatConstitutesEvidence: [
      "TCFD-aligned disclosure with physical risk specifics",
      "SEC climate disclosure compliance (if US-listed or SEC registrant)",
      "EU CSRD/ESRS compliance (if EU operations or listing)",
      "Other regional disclosure frameworks (e.g., UK TCFD requirements, Singapore)",
      "Explicit statement of compliance with framework(s)"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic sustainability reporting without framework compliance",
      "Partial or incomplete TCFD disclosure missing physical risk elements",
      "Statement of 'support for TCFD' without implementation"
    ],
    scoringGuidance: {
      1: "Minimal disclosure, non-compliant with any framework",
      2: "Partial disclosure, some alignment with framework but gaps",
      3: "Full compliance with ≥1 major disclosure framework (TCFD, SEC, or CSRD)",
      4: "Comprehensive compliance with 2+ frameworks",
      5: "Leading disclosure exceeding regulatory requirements with additional voluntary detail"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M16",
    category: "Risk Identification & Assessment",
    categoryNumber: 2,
    title: "Disclosure Quality & Transparency",
    definition: "Beyond compliance, company provides high-quality, detailed, transparent disclosure of physical climate risks.",
    whatConstitutesEvidence: [
      "Detailed disclosure of risk assessment methodology with references",
      "Quantitative disclosure of impacts, not just qualitative",
      "Geographic and asset-specific disclosure (not just generic statements)",
      "Regular updates (annual or more frequent) with progress reporting",
      "Use of standardized metrics for comparability",
      "Accessible disclosure (not buried in hundreds of pages)"
    ],
    whatDoesNotConstituteEvidence: [
      "Compliance-focused disclosure with minimal detail",
      "Generic or boilerplate language",
      "Disclosure scattered across multiple documents without integration"
    ],
    scoringGuidance: {
      1: "Minimal, generic, qualitative disclosure",
      2: "Compliance-level disclosure with some specifics but limited detail",
      3: "Detailed methodology and priority risks disclosed with some quantification",
      4: "Quantitative disclosure with geographic specificity and regular updates",
      5: "Best-in-class transparency: detailed quantitative disclosure, asset-level specifics, trends over time"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M17",
    category: "Asset Design & Resilience",
    categoryNumber: 3,
    title: "Climate-Resilient Design Standards",
    definition: "Company uses design standards for new assets that explicitly incorporate climate change projections and resilience requirements.",
    whatConstitutesEvidence: [
      "Engineering or design standards referencing climate projections (e.g., 'design for 100-year flood + 20% for climate change')",
      "Building codes or specifications exceeding baseline requirements for climate resilience",
      "Design guidelines for specific hazards (flood-resistant, wind-resistant, heat-resistant)",
      "Examples of projects using climate-resilient design",
      "Coverage: % of new construction using these standards"
    ],
    whatDoesNotConstituteEvidence: [
      "Standard building codes without climate enhancement",
      "Energy efficiency or sustainability design (LEED, etc.) without climate resilience focus",
      "Aspirational statements without implemented standards"
    ],
    scoringGuidance: {
      1: "Standard building codes without climate considerations",
      2: "Some enhanced design for specific projects but no systematic standards",
      3: "Climate-resilient standards for 50-79% of new assets",
      4: "Comprehensive standards (80-94%) incorporating future climate projections",
      5: "Group-wide mandatory standards with specific hazard criteria and validation"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M18",
    category: "Asset Design & Resilience",
    categoryNumber: 3,
    title: "Retrofitting & Hardening Programs",
    definition: "Company has active programs to retrofit or harden existing assets to improve climate resilience.",
    whatConstitutesEvidence: [
      "Documented retrofitting program with investment amounts",
      "Specific adaptation measures implemented (flood barriers, roof reinforcement, cooling systems, etc.)",
      "Asset hardening initiatives (protective coatings, storm shutters, backup power, etc.)",
      "Number or % of facilities retrofitted",
      "Outcomes tracked (e.g., reduced damage in subsequent events)"
    ],
    whatDoesNotConstituteEvidence: [
      "Standard facility maintenance without climate focus",
      "Energy efficiency upgrades without resilience component",
      "Aspirations to retrofit without actual implementation"
    ],
    scoringGuidance: {
      1: "Standard maintenance without adaptation focus",
      2: "Ad hoc retrofitting of individual assets without program",
      3: "Formal retrofitting program covering 25-49% of vulnerable assets",
      4: "Comprehensive program (50-79%) with quantified investment ($X invested)",
      5: "Extensive program (≥80%) with outcomes tracking and continuous improvement"
    },
    coverageMetric: "% of vulnerable assets retrofitted or % of total assets by value",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M19",
    category: "Asset Design & Resilience",
    categoryNumber: 3,
    title: "Nature-Based Solutions",
    definition: "Company uses nature-based solutions (green infrastructure, ecosystem restoration) for climate adaptation.",
    whatConstitutesEvidence: [
      "Green infrastructure projects: wetlands, mangroves, green roofs, bioswales, rain gardens",
      "Natural flood defenses: restored floodplains, living shorelines",
      "Urban forestry or vegetation for heat mitigation",
      "Ecosystem restoration for resilience (coral reefs, forests, grasslands)",
      "Specific examples with locations and outcomes"
    ],
    whatDoesNotConstituteEvidence: [
      "Biodiversity projects without adaptation rationale",
      "Tree planting for carbon offsets (mitigation, not adaptation)",
      "Landscaping without climate resilience function"
    ],
    scoringGuidance: {
      0: "No nature-based solutions implemented",
      2: "Pilot nature-based project at 1 site",
      3: "Nature-based solutions at ≥2 sites with documented outcomes",
      4: "Systematic approach across multiple sites integrated with infrastructure",
      5: "Leading nature-based approach with quantified benefits and scalability"
    },
    notes: "This is relatively rare outside of certain industries (utilities, real estate, agriculture).",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M20",
    category: "Asset Design & Resilience",
    categoryNumber: 3,
    title: "Protective Infrastructure",
    definition: "Company has installed protective infrastructure specifically to reduce climate hazard impacts.",
    whatConstitutesEvidence: [
      "Flood barriers, levees, or sea walls",
      "Storm shelters or reinforced structures",
      "Drainage improvements or stormwater management",
      "Wildfire defensible space or fire breaks",
      "Cooling infrastructure (air conditioning, reflective surfaces)",
      "Backup power systems for extreme weather"
    ],
    whatDoesNotConstituteEvidence: [
      "Standard infrastructure without climate adaptation focus",
      "Infrastructure for non-climate purposes that happens to provide some protection",
      "Planned infrastructure not yet implemented"
    ],
    scoringGuidance: {
      0: "No protective infrastructure installed",
      2: "Some protective measures at individual high-risk sites",
      3: "Protective infrastructure at 25-49% of vulnerable sites",
      4: "Comprehensive protection (50-79%) with multiple hazard coverage",
      5: "Extensive protection (≥80%) with outcomes tracking and regular upgrades"
    },
    coverageMetric: "% of vulnerable sites with protective infrastructure",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M21",
    category: "Asset Design & Resilience",
    categoryNumber: 3,
    title: "Relocation & Managed Retreat",
    definition: "Company has relocated or planned to relocate assets away from high-risk areas, or implemented managed retreat strategies.",
    whatConstitutesEvidence: [
      "Relocation of facilities from flood zones, coastal areas, or wildfire-prone areas",
      "Strategic decisions to not invest in high-risk locations",
      "Managed retreat plans with timelines",
      "Asset divestment from high-risk areas",
      "New facility siting criteria incorporating climate risk"
    ],
    whatDoesNotConstituteEvidence: [
      "Asset closures for non-climate reasons",
      "Consideration of climate in site selection without documented criteria",
      "Future plans without concrete action"
    ],
    scoringGuidance: {
      0: "No relocation or managed retreat",
      2: "Consideration of relocation for specific high-risk assets",
      3: "Relocation of ≥1 asset or documented managed retreat plan",
      4: "Systematic approach to managed retreat with investment criteria",
      5: "Proactive portfolio optimization including divestment from high-risk areas"
    },
    notes: "This is rare and typically only seen in companies with very high physical risk exposure.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M22",
    category: "Crisis Management & Response",
    categoryNumber: 4,
    title: "Business Continuity Planning",
    definition: "Company has business continuity plans (BCPs) that address climate-related or weather-related disruptions.",
    whatConstitutesEvidence: [
      "BCPs covering climate/weather events (storms, floods, extreme heat, etc.)",
      "Site-specific BCPs for high-risk locations",
      "Regular BCP testing and updates",
      "Recovery time objectives (RTOs) and recovery point objectives (RPOs)",
      "Coverage: % of critical operations with BCPs"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic BCPs without climate/weather component",
      "IT disaster recovery only",
      "BCPs mentioned without evidence of climate coverage"
    ],
    scoringGuidance: {
      1: "Generic BCPs without climate/weather focus",
      2: "Some climate/weather BCPs but limited coverage (<50%)",
      3: "BCPs covering 50-79% of critical operations with climate scenarios",
      4: "Comprehensive BCPs (80-94%) with testing and regular updates",
      5: "Best practice BCPs with quantified RTOs, regular testing, and continuous improvement"
    },
    coverageMetric: "% of critical operations with climate-inclusive BCPs",
    notes: "Can credit general BCP coverage even without climate specificity for partial score.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M23",
    category: "Crisis Management & Response",
    categoryNumber: 4,
    title: "Emergency Response Procedures",
    definition: "Company has emergency response procedures for climate-related or weather-related events.",
    whatConstitutesEvidence: [
      "Emergency response protocols for specific weather events",
      "Emergency response teams or roles defined",
      "Emergency communication systems",
      "Evacuation procedures and drills",
      "Emergency supplies and equipment",
      "Coordination with local emergency services"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic emergency procedures without weather/climate focus",
      "Fire safety procedures only",
      "Mention of 'emergency response' without specifics"
    ],
    scoringGuidance: {
      1: "Generic emergency procedures without climate/weather focus",
      2: "Some weather-specific procedures but limited scope",
      3: "Emergency procedures for major weather events at 50-79% of sites",
      4: "Comprehensive procedures (80-94%) with regular drills and coordination",
      5: "Best practice emergency response with real-time monitoring and tested effectiveness"
    },
    coverageMetric: "% of sites with weather-specific emergency procedures",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M24",
    category: "Crisis Management & Response",
    categoryNumber: 4,
    title: "Early Warning Systems",
    definition: "Company uses early warning systems to anticipate and prepare for climate/weather events.",
    whatConstitutesEvidence: [
      "Weather monitoring systems or subscriptions",
      "Real-time hazard monitoring (flood gauges, fire detection, etc.)",
      "Early warning alerts to employees and operations",
      "Integration of weather data into operations planning",
      "Predictive analytics for weather impacts"
    ],
    whatDoesNotConstituteEvidence: [
      "Reliance on public weather forecasts only",
      "General awareness of weather without systematic monitoring",
      "Weather monitoring for non-operational purposes"
    ],
    scoringGuidance: {
      0: "No early warning systems",
      2: "Basic weather monitoring for some locations",
      3: "Early warning systems for 50-79% of high-risk locations",
      4: "Comprehensive monitoring (80-94%) with real-time alerts",
      5: "Advanced predictive systems with integration into operations and demonstrated effectiveness"
    },
    coverageMetric: "% of high-risk locations with early warning systems",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M25",
    category: "Crisis Management & Response",
    categoryNumber: 4,
    title: "Post-Event Recovery Processes",
    definition: "Company has documented processes for recovery and restoration after climate/weather events.",
    whatConstitutesEvidence: [
      "Documented recovery processes and protocols",
      "Recovery teams or roles defined",
      "Damage assessment procedures",
      "Restoration prioritization criteria",
      "Lessons learned processes after events",
      "Historical recovery examples with timelines"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic statements about 'recovering from disruptions'",
      "Insurance claims process only (see M35)",
      "No documented recovery process"
    ],
    scoringGuidance: {
      0: "No documented recovery processes",
      2: "Ad hoc recovery without formal processes",
      3: "Documented recovery processes with some historical examples",
      4: "Comprehensive recovery framework with lessons learned integration",
      5: "Best practice recovery with continuous improvement and demonstrated speed"
    },
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M26",
    category: "Crisis Management & Response",
    categoryNumber: 4,
    title: "Crisis Communication Protocols",
    definition: "Company has communication protocols for climate/weather-related crises.",
    whatConstitutesEvidence: [
      "Crisis communication plans for weather events",
      "Stakeholder communication protocols (employees, customers, investors, media)",
      "Communication templates or pre-approved messaging",
      "Designated spokespersons for climate/weather events",
      "Examples of crisis communications during past events"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic corporate communications policies",
      "One-way disclosure without crisis-specific protocols",
      "Communications after events without pre-planned protocols"
    ],
    scoringGuidance: {
      0: "No crisis communication protocols",
      2: "Basic communication procedures but not weather-specific",
      3: "Weather-specific communication protocols with designated roles",
      4: "Comprehensive protocols with multiple stakeholder channels",
      5: "Best practice communications with tested effectiveness and stakeholder feedback"
    },
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M27",
    category: "Supply Chain Resilience",
    categoryNumber: 5,
    title: "Supplier Diversification",
    definition: "Company has diversified its supplier base to reduce climate-related supply chain concentration risks.",
    whatConstitutesEvidence: [
      "Multiple suppliers for critical inputs in different geographic regions",
      "Supplier diversification strategy explicitly for climate resilience",
      "Reduction in single-source dependencies",
      "Geographic distribution of supplier base",
      "Dual or multi-sourcing policies"
    ],
    whatDoesNotConstituteEvidence: [
      "Multiple suppliers for cost/quality reasons without climate consideration",
      "Supplier diversification for non-climate risks only",
      "Plans to diversify without implementation"
    ],
    scoringGuidance: {
      1: "Single-source suppliers for most critical inputs",
      2: "Some diversification but high concentration remains (>50% single-source)",
      3: "Diversification for 50-79% of critical inputs",
      4: "Comprehensive diversification (80-94%) with geographic distribution",
      5: "Strategic multi-sourcing with climate risk explicitly considered and redundancy tested"
    },
    coverageMetric: "% of critical inputs with multiple suppliers in different climate zones",
    notes: "Can credit general diversification strategy even without climate specificity.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M28",
    category: "Supply Chain Resilience",
    categoryNumber: 5,
    title: "Supplier Engagement on Resilience",
    definition: "Company engages with suppliers on climate resilience, including assessments and improvement programs.",
    whatConstitutesEvidence: [
      "Supplier surveys or assessments on climate risk management",
      "Supplier training or capacity building on resilience",
      "Supplier requirements or contractual provisions for climate risk",
      "Collaborative resilience improvement programs",
      "Supplier scorecards including climate resilience"
    ],
    whatDoesNotConstituteEvidence: [
      "General supplier sustainability engagement without resilience focus",
      "Supplier engagement on emissions reduction only",
      "One-time assessments without ongoing engagement"
    ],
    scoringGuidance: {
      1: "No supplier engagement on resilience",
      2: "Limited engagement with top suppliers (<50% of spend)",
      3: "Engagement with 50-79% of suppliers by spend",
      4: "Comprehensive engagement (80-94%) with documented outcomes",
      5: "Leading supplier partnership with joint resilience improvements"
    },
    coverageMetric: "% of supplier spend with climate resilience engagement",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M29",
    category: "Supply Chain Resilience",
    categoryNumber: 5,
    title: "Alternative Sourcing Plans",
    definition: "Company has pre-identified alternative suppliers that can be activated if primary suppliers are disrupted.",
    whatConstitutesEvidence: [
      "Pre-qualified alternative suppliers documented",
      "Alternative sourcing plans for specific disruption scenarios",
      "Contracts or agreements with backup suppliers",
      "Regular testing or exercising of alternative sourcing",
      "Speed of activation documented"
    ],
    whatDoesNotConstituteEvidence: [
      "General awareness of alternative suppliers without pre-qualification",
      "Ad hoc sourcing during disruptions",
      "Alternative suppliers for non-climate reasons only"
    ],
    scoringGuidance: {
      0: "No alternative sourcing plans",
      2: "Some alternative suppliers identified but not pre-qualified",
      3: "Alternative sourcing plans for 50-79% of critical inputs",
      4: "Comprehensive plans (80-94%) with pre-qualified alternatives",
      5: "Tested alternative sourcing with demonstrated activation capability"
    },
    coverageMetric: "% of critical inputs with pre-qualified alternative suppliers",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M30",
    category: "Supply Chain Resilience",
    categoryNumber: 5,
    title: "Inventory & Buffer Stocks",
    definition: "Company maintains strategic inventory or buffer stocks to manage supply chain disruptions.",
    whatConstitutesEvidence: [
      "Strategic inventory policies for critical inputs",
      "Buffer stocks above normal operating requirements",
      "Inventory levels explicitly set considering climate/weather risks",
      "Safety stock calculations incorporating disruption scenarios",
      "Examples of buffer stocks being used during disruptions"
    ],
    whatDoesNotConstituteEvidence: [
      "Standard inventory management without disruption consideration",
      "Just-in-time inventory only",
      "Inventory for demand variability only (not supply disruption)"
    ],
    scoringGuidance: {
      0: "JIT inventory without buffers",
      2: "Some buffer stocks for specific inputs (<50% of critical inputs)",
      3: "Buffer stocks for 50-79% of critical inputs",
      4: "Comprehensive buffering (80-94%) with climate risk criteria",
      5: "Dynamic inventory management optimized for resilience with quantified approach"
    },
    coverageMetric: "% of critical inputs with buffer inventory maintained",
    notes: "Can credit general resilience buffering even without climate specificity.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M31",
    category: "Supply Chain Resilience",
    categoryNumber: 5,
    title: "Logistics & Transportation Resilience",
    definition: "Company has resilient logistics and transportation networks with multiple routes or modes available.",
    whatConstitutesEvidence: [
      "Multiple transportation routes or modes for critical shipments",
      "Logistics network redundancy (backup distribution centers, ports, etc.)",
      "Alternative distribution channels documented",
      "Transportation risk monitoring systems",
      "Examples of re-routing during disruptions"
    ],
    whatDoesNotConstituteEvidence: [
      "Single transportation route without alternatives",
      "Cost-optimized logistics without resilience consideration",
      "Use of freight forwarders without assessment of their redundancy"
    ],
    scoringGuidance: {
      1: "Single-route logistics without alternatives",
      2: "Some alternative routes but limited coverage (<50% of critical flows)",
      3: "Alternative routes for 50-79% of critical shipments",
      4: "Comprehensive network redundancy (80-94%) with multiple modes",
      5: "Resilient logistics with real-time monitoring and dynamic rerouting capabilities"
    },
    coverageMetric: "% of critical shipment lanes with alternative routes",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M32",
    category: "Insurance & Risk Transfer",
    categoryNumber: 6,
    title: "Insurance Coverage Adequacy",
    definition: "Company has adequate insurance coverage for physical climate risks, regularly reviews coverage, and understands protection gaps.",
    whatConstitutesEvidence: [
      "Property insurance covering climate hazards (flood, windstorm, earthquake, etc.)",
      "Business interruption (BI) or contingent business interruption (CBI) insurance",
      "Coverage amounts disclosed or characterized as adequate",
      "Regular review of coverage adequacy (annual reviews documented)",
      "Quantification of insured vs. uninsured risks",
      "Discussion of insurance market challenges (cost, availability)"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic statement 'we maintain insurance' without specifics",
      "Only liability or professional indemnity insurance (not property/BI)",
      "Insurance mentioned only in boilerplate risk factors"
    ],
    scoringGuidance: {
      1: "Generic insurance without climate hazard assessment",
      2: "Some climate hazard coverage but limited scope or large gaps",
      3: "Climate-specific coverage for 50-79% of high-risk assets",
      4: "Comprehensive coverage (80-94%) with gap analysis",
      5: "Optimal insurance strategy with regular reviews and quantified coverage adequacy"
    },
    coverageMetric: "% of asset value covered for key climate hazards",
    notes: "Disclosure of insurance strategy is rare. Even basic evidence deserves credit.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M33",
    category: "Insurance & Risk Transfer",
    categoryNumber: 6,
    title: "Parametric Insurance & Innovative Products",
    definition: "Company uses parametric (index-based) or other innovative insurance products for climate risks.",
    whatConstitutesEvidence: [
      "Parametric insurance policies (trigger-based payouts)",
      "Weather derivatives or index insurance",
      "Catastrophe bonds issued by company",
      "Pilot programs for new insurance solutions",
      "Use of specialized climate risk insurance products"
    ],
    whatDoesNotConstituteEvidence: [
      "Awareness of parametric insurance without purchase",
      "Standard property/casualty insurance (covered in M32)",
      "Investment in cat bonds (need company to issue or purchase protection)"
    ],
    scoringGuidance: {
      0: "No innovative insurance products used",
      2: "Pilot or small-scale use of innovative products",
      3: "Parametric or innovative products for ≥1 hazard or geography",
      4: "Systematic use across multiple hazards or geographies",
      5: "Leading adoption with portfolio optimization and outcomes tracking"
    },
    notes: "This is rare. Score 0 is very common, and any evidence deserves credit.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M34",
    category: "Insurance & Risk Transfer",
    categoryNumber: 6,
    title: "Captives & Alternative Risk Transfer",
    definition: "Company uses captive insurance companies or other alternative risk transfer mechanisms.",
    whatConstitutesEvidence: [
      "Captive insurance company owned by company",
      "Self-insurance programs or pools",
      "Risk pooling arrangements or mutual insurance",
      "Alternative risk transfer (ART) mechanisms",
      "Disclosure of retained vs. transferred risks"
    ],
    whatDoesNotConstituteEvidence: [
      "Standard commercial insurance (covered in M32)",
      "Self-retention within standard deductibles",
      "Informal risk retention without structured program"
    ],
    scoringGuidance: {
      0: "No alternative risk transfer mechanisms",
      2: "Captive or self-insurance for limited risks",
      3: "Captive or self-insurance for ≥1 major risk category",
      4: "Comprehensive ART strategy with multiple mechanisms",
      5: "Optimized risk financing with quantified cost/benefit analysis"
    },
    notes: "Captives are common in some industries (e.g., utilities, large manufacturers). Disclosure is limited.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M35",
    category: "Insurance & Risk Transfer",
    categoryNumber: 6,
    title: "Claims Management & Recovery",
    definition: "Company has effective claims management and recovery processes following insured events.",
    whatConstitutesEvidence: [
      "Claims management procedures documented",
      "Recovery process following insured losses",
      "Historical claims data disclosed (number, amounts recovered)",
      "Lessons learned from claims process",
      "Claims success rate or recovery rates",
      "Continuous improvement of claims handling"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic statement about filing claims when needed",
      "Insurance policy details without claims experience",
      "No historical claims (not their fault, but can't score without evidence)"
    ],
    scoringGuidance: {
      0: "No evidence of claims management process",
      2: "Basic claims handling but no documented process",
      3: "Documented claims process with historical data",
      4: "Comprehensive process with recovery optimization",
      5: "Best practice claims management with continuous improvement and lessons learned"
    },
    notes: "Very rare to find disclosure on this. Score 0 or 1 is typical.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M36",
    category: "Data Quality & Assurance",
    categoryNumber: 7,
    title: "Data Governance & Quality",
    definition: "Company has governance processes to ensure quality of climate risk data used in assessments and disclosures.",
    whatConstitutesEvidence: [
      "Data governance framework for climate data",
      "Data quality standards or validation procedures",
      "Climate data management systems or platforms",
      "Regular data quality audits",
      "Documentation of data sources and assumptions",
      "Data lineage or traceability"
    ],
    whatDoesNotConstituteEvidence: [
      "Use of third-party data without validation",
      "Generic data governance without climate-specific application",
      "Ad hoc data collection without quality assurance"
    ],
    scoringGuidance: {
      1: "Ad hoc data management without governance",
      2: "Some data quality procedures but limited formalization",
      3: "Data governance framework with quality standards",
      4: "Comprehensive governance with validation procedures and audits",
      5: "Best practice data management with continuous improvement and traceability"
    },
    notes: "This is rare. Even score 2-3 indicates relatively mature approach.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M37",
    category: "Data Quality & Assurance",
    categoryNumber: 7,
    title: "External Assurance & Verification",
    definition: "Company obtains external assurance or verification of climate risk disclosures or assessments.",
    whatConstitutesEvidence: [
      "Third-party assurance of climate disclosures (limited or reasonable assurance)",
      "Assurance by Big 4 accounting firms or specialist sustainability assurance providers",
      "Independent verification of climate risk assessments",
      "Public disclosure of assurance reports or statements",
      "Scope of assurance (what's covered, what's not)"
    ],
    whatDoesNotConstituteEvidence: [
      "General financial audit that doesn't cover climate disclosures",
      "Participation in CDP or other disclosure platforms (these don't provide assurance)",
      "Internal audit without external party involvement"
    ],
    scoringGuidance: {
      0: "No external assurance of climate disclosures",
      2: "External review or consultation but not formal assurance",
      3: "Limited assurance of selected climate disclosures",
      4: "Reasonable assurance of key climate disclosures including physical risks",
      5: "Comprehensive reasonable assurance with public reporting and continuous expansion of scope"
    },
    notes: "External assurance is rare and expensive. Score 0 is very common.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M38",
    category: "Social & Community Resilience",
    categoryNumber: 8,
    title: "Employee Safety & Well-being",
    definition: "Company has programs to protect employee safety and well-being during climate events or extreme weather.",
    whatConstitutesEvidence: [
      "Employee safety programs for extreme weather (heat, cold, storms, flooding)",
      "Heat stress management programs for outdoor workers",
      "Emergency evacuation procedures and drills",
      "Employee support during climate events (emergency leave, relocation assistance, financial support)",
      "Occupational health programs addressing climate hazards",
      "Employee training on extreme weather safety"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic occupational health and safety programs without weather/climate component",
      "Office climate control without consideration of extreme events",
      "Standard emergency procedures without weather specificity"
    ],
    scoringGuidance: {
      1: "Generic safety programs without climate/weather focus",
      2: "Some climate safety programs but limited coverage (<50% of exposed employees)",
      3: "Climate-specific safety programs for 50-79% of exposed employees",
      4: "Comprehensive programs (80-94%) with training and support",
      5: "Best practice employee protection with well-being support and outcomes tracking"
    },
    coverageMetric: "% of employees in climate-exposed roles with specific safety programs",
    notes: "Heat stress programs are common in some industries (outdoor work, agriculture, construction).",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M39",
    category: "Social & Community Resilience",
    categoryNumber: 8,
    title: "Community Engagement & Support",
    definition: "Company engages with and supports communities on climate resilience, especially in areas where company operates.",
    whatConstitutesEvidence: [
      "Community engagement on local climate risks",
      "Support for community adaptation projects (funding, technical assistance, volunteering)",
      "Collaboration with local governments on resilience planning",
      "Community disaster response support or emergency assistance",
      "Vulnerable population support during climate events",
      "Community resilience partnerships or programs"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic corporate philanthropy without climate/resilience focus",
      "Community engagement on other sustainability topics (e.g., conservation without resilience link)",
      "One-off emergency responses without ongoing engagement"
    ],
    scoringGuidance: {
      0: "Minimal community engagement on climate resilience",
      2: "Limited community engagement (<3 communities)",
      3: "Engagement and support in ≥3 major operating locations",
      4: "Systematic engagement with documented programs and outcomes",
      5: "Leading community resilience partnerships with measurable community benefits"
    },
    notes: "This is relatively rare unless company operates in highly vulnerable areas or has strong community engagement culture.",
    climateSpecificity: 'MEDIUM'
  },
  {
    id: "M40",
    category: "Performance Metrics & Continuous Improvement",
    categoryNumber: 9,
    title: "Just Transition & Equity Considerations",
    definition: "Company considers equity, vulnerable populations, and just transition principles in climate adaptation planning and implementation.",
    whatConstitutesEvidence: [
      "Assessment of adaptation impacts on vulnerable populations (workers, communities)",
      "Just transition principles in adaptation planning",
      "Equity considerations in resource allocation for adaptation",
      "Stakeholder engagement with vulnerable groups on adaptation",
      "Support for workers affected by facility closures or relocations due to climate risk",
      "Community support in adaptation implementation"
    ],
    whatDoesNotConstituteEvidence: [
      "Just transition considerations only for emissions reduction (mitigation)",
      "Generic DEI programs without climate adaptation connection",
      "Community benefits without focus on vulnerable populations"
    ],
    scoringGuidance: {
      0: "No equity considerations in adaptation",
      2: "Awareness of equity issues but limited action",
      3: "Equity assessment for ≥1 major adaptation initiative",
      4: "Systematic equity integration across adaptation planning",
      5: "Leading just transition approach with stakeholder validation and measurable equity outcomes"
    },
    notes: "This is very rare. Most companies haven't considered equity dimensions of adaptation. Score 0 is most common.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M41",
    category: "Performance Metrics & Continuous Improvement",
    categoryNumber: 9,
    title: "Downtime & Disruption Metrics",
    definition: "Company tracks operational downtime and disruptions from climate events or other causes.",
    whatConstitutesEvidence: [
      "Tracking of climate-related downtime (days, hours)",
      "Disruption metrics for extreme weather events",
      "Historical trend analysis of climate-related disruptions",
      "Performance against downtime targets or benchmarks",
      "NOTE: Can also credit general downtime tracking even if not climate-specific (useful for climate resilience)"
    ],
    whatDoesNotConstituteEvidence: [
      "Qualitative descriptions of disruptions without metrics",
      "Planned maintenance downtime (not disruptions)",
      "Financial impacts without operational metrics (see M42)"
    ],
    scoringGuidance: {
      0: "No systematic downtime tracking",
      2: "Ad hoc tracking of major events only",
      3: "Systematic tracking for 50-79% of facilities",
      4: "Comprehensive tracking (80-94%) with trend analysis",
      5: "Best practice metrics with targets and continuous improvement"
    },
    coverageMetric: "% of facilities with downtime tracking systems",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M42",
    category: "Performance Metrics & Continuous Improvement",
    categoryNumber: 9,
    title: "Financial Impact Tracking",
    definition: "Company tracks financial impacts of climate events, including losses, recovery costs, and insurance claims.",
    whatConstitutesEvidence: [
      "Tracking of climate-related financial losses by event or cumulative",
      "Revenue, EBITDA, or profit impacts from climate disruptions",
      "Capital expenditure on recovery or repairs",
      "Insurance claims and recoveries tracked",
      "Historical trend analysis of financial impacts",
      "Comparison to budgets or forecasts"
    ],
    whatDoesNotConstituteEvidence: [
      "One-time disclosure of major event impact without systematic tracking",
      "Future projections without historical tracking",
      "Operational impacts without financial translation"
    ],
    scoringGuidance: {
      0: "No systematic financial impact tracking",
      2: "Ad hoc tracking of major events without systematic process",
      3: "Systematic tracking for ≥1 major impact category (revenue, costs, capex, claims)",
      4: "Comprehensive tracking across multiple categories with trend analysis",
      5: "Detailed financial tracking with forecasting and risk-adjusted planning"
    },
    climateSpecificity: 'HIGH'
  },
  {
    id: "M43",
    category: "Performance Metrics & Continuous Improvement",
    categoryNumber: 9,
    title: "Supplier Disruption Metrics",
    definition: "Company tracks supply chain disruptions from climate events, including supplier downtime and performance during events.",
    whatConstitutesEvidence: [
      "Tracking of supplier disruptions from climate events",
      "Supply chain downtime or delays due to weather/climate",
      "Supplier performance metrics during climate events",
      "Historical trend analysis of supply chain climate impacts",
      "Correlation of disruptions to specific climate events"
    ],
    whatDoesNotConstituteEvidence: [
      "Generic supply chain KPIs without climate event tracking",
      "Supplier quality metrics without disruption focus",
      "Awareness of supply chain risks without measurement"
    ],
    scoringGuidance: {
      0: "No systematic supplier disruption tracking",
      2: "Ad hoc tracking of major supply chain disruptions",
      3: "Systematic tracking for 50-79% of critical suppliers",
      4: "Comprehensive tracking (80-94%) with trend analysis",
      5: "Best practice supply chain metrics with predictive capabilities"
    },
    coverageMetric: "% of critical suppliers with disruption monitoring",
    notes: "This is rare. Most companies don't have visibility into supplier disruptions, let alone track them systematically.",
    climateSpecificity: 'HIGH'
  },
  {
    id: "M44",
    category: "Performance Metrics & Continuous Improvement",
    categoryNumber: 9,
    title: "Adaptation Spend & Outcomes",
    definition: "Company tracks investment in climate adaptation and quantifies outcomes achieved (e.g., reduced downtime, avoided losses, return on investment).",
    whatConstitutesEvidence: [
      "Tracking of adaptation capital expenditures (capex)",
      "Tracking of adaptation operating expenses (opex)",
      "Quantification of adaptation outcomes (reduced downtime, avoided losses, lower insurance costs)",
      "Return on investment (ROI) analysis for adaptation investments",
      "Comparison of costs vs. benefits",
      "Continuous improvement based on outcomes"
    ],
    whatDoesNotConstituteEvidence: [
      "Capex mentioned without tracking over time",
      "Outcomes described qualitatively without quantification",
      "Investment in general maintenance or sustainability (must be adaptation-specific)"
    ],
    scoringGuidance: {
      0: "No tracking of adaptation spend",
      2: "Ad hoc reporting of major adaptation investments without outcomes",
      3: "Systematic tracking of spend for ≥1 major adaptation program",
      4: "Comprehensive tracking of spend and outcomes with ROI analysis",
      5: "Best practice ROI analysis with continuous improvement and investment optimization"
    },
    notes: "This is the holy grail of adaptation metrics and very rare. Even score 2 is good performance.",
    climateSpecificity: 'HIGH'
  }
];

export const MAX_SCORE = MEASURES.length * 5; // 44 measures * 5 = 220
