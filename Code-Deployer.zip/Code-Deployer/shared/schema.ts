import { pgTable, text, serial, integer, boolean, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  isin: text("isin"),
  sector: text("sector"),
  industry: text("industry"),
  country: text("country"),
  analysisStatus: text("analysis_status").default("idle").notNull(), // idle, searching, analyzing, completed, failed
  totalScore: real("total_score"),
  summary: text("summary"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull(),
  url: text("url").notNull(),
  title: text("title"),
  type: text("type").notNull(), // pdf, html
  publicationYear: integer("publication_year"),
  content: text("content"), // Extracted text content
  downloadedAt: timestamp("downloaded_at").defaultNow(),
});

export const analysisResults = pgTable("analysis_results", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull(),
  documentId: integer("document_id"), // Optional: if specific to a document
  category: text("category"), // e.g., "Physical Risk", "Governance"
  criteria: text("criteria"),
  score: real("score"),
  reasoning: text("reasoning"),
  rawData: jsonb("raw_data"), // Full JSON for this point
  analyzedAt: timestamp("analyzed_at").defaultNow(),
});

export const measureScores = pgTable("measure_scores", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull(),
  measureId: text("measure_id").notNull(), // e.g., "M01", "M02", etc.
  category: text("category").notNull(),
  categoryNumber: integer("category_number").notNull(),
  title: text("title").notNull(),
  score: integer("score").notNull(), // 0-5
  evidenceSummary: text("evidence_summary"),
  coverage: text("coverage"), // e.g., "80% of facilities"
  confidence: text("confidence"), // High, Medium, Low
  quotes: jsonb("quotes").$type<Array<{text: string, source: string, page?: string}>>(), // Array of evidence quotes
  analyzedAt: timestamp("analyzed_at").defaultNow(),
});

// === JOB QUEUE FOR HEROKU WORKERS ===

export const analysisJobs = pgTable("analysis_jobs", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull(),
  companyName: text("company_name").notNull(),
  status: text("status").default("pending").notNull(), // pending, processing, completed, failed
  priority: integer("priority").default(0).notNull(), // Higher = more urgent
  workerId: text("worker_id"), // Which worker is processing this job
  attempts: integer("attempts").default(0).notNull(),
  maxAttempts: integer("max_attempts").default(3).notNull(),
  errorMessage: text("error_message"),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const batchRuns = pgTable("batch_runs", {
  id: serial("id").primaryKey(),
  status: text("status").default("pending").notNull(), // pending, running, completed, cancelled
  totalJobs: integer("total_jobs").default(0).notNull(),
  completedJobs: integer("completed_jobs").default(0).notNull(),
  failedJobs: integer("failed_jobs").default(0).notNull(),
  parallelWorkers: integer("parallel_workers").default(3).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  completedAt: timestamp("completed_at"),
});

// === RELATIONS ===

export const companiesRelations = relations(companies, ({ many }) => ({
  documents: many(documents),
  analysisResults: many(analysisResults),
  measureScores: many(measureScores),
}));

export const measureScoresRelations = relations(measureScores, ({ one }) => ({
  company: one(companies, {
    fields: [measureScores.companyId],
    references: [companies.id],
  }),
}));

export const documentsRelations = relations(documents, ({ one, many }) => ({
  company: one(companies, {
    fields: [documents.companyId],
    references: [companies.id],
  }),
  analysisResults: many(analysisResults),
}));

export const analysisResultsRelations = relations(analysisResults, ({ one }) => ({
  company: one(companies, {
    fields: [analysisResults.companyId],
    references: [companies.id],
  }),
  document: one(documents, {
    fields: [analysisResults.documentId],
    references: [documents.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertCompanySchema = createInsertSchema(companies).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});

export const insertDocumentSchema = createInsertSchema(documents).omit({ 
  id: true, 
  downloadedAt: true 
});

export const insertMeasureScoreSchema = createInsertSchema(measureScores).omit({
  id: true,
  analyzedAt: true
});

export const insertAnalysisJobSchema = createInsertSchema(analysisJobs).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertBatchRunSchema = createInsertSchema(batchRuns).omit({
  id: true,
  createdAt: true
});

// === EXPLICIT API CONTRACT TYPES ===

export type Company = typeof companies.$inferSelect;
export type InsertCompany = z.infer<typeof insertCompanySchema>;

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

export type AnalysisResult = typeof analysisResults.$inferSelect;

export type MeasureScore = typeof measureScores.$inferSelect;
export type InsertMeasureScore = z.infer<typeof insertMeasureScoreSchema>;

export type AnalysisJob = typeof analysisJobs.$inferSelect;
export type InsertAnalysisJob = z.infer<typeof insertAnalysisJobSchema>;

export type BatchRun = typeof batchRuns.$inferSelect;
export type InsertBatchRun = z.infer<typeof insertBatchRunSchema>;

export type ImportRequest = {
  url: string;
};

export type AnalysisRequest = {
  forceRefresh?: boolean;
};

// Response types
export type CompanyResponse = Company & {
  documents?: Document[];
  analysisResults?: AnalysisResult[];
  measureScores?: MeasureScore[];
};
