# Physical Climate Risk Assessment Framework v3.0
## Enhanced Framework for Systematic Company Assessment

**Framework Version**: 3.0  
**Total Measures**: 44  
**Scoring Scale**: 0-5 for each measure  
**Maximum Score**: 220 points (44 measures × 5 points)  
**Last Updated**: December 2025

---

## EXECUTIVE SUMMARY

This framework provides a comprehensive, evidence-based methodology for assessing corporate management of physical climate risks across 44 specific measures organized into 9 categories. It is designed for systematic evaluation using AI-driven document analysis with rigorous evidence requirements to ensure accurate, reproducible assessments.

### Key Framework Principles

1. **Evidence-Based Assessment**: All scores must be supported by specific, verbatim quotes from company documents
2. **Climate-Specificity**: Most measures require explicit evidence of physical climate risk management (not generic risk management)
3. **Hazard-Agnostic Exceptions**: Category 4 (Crisis Management) measures accept evidence for any major disruption
4. **Quantification Preference**: Higher scores require quantitative evidence, specific metrics, and measurable outcomes
5. **No Hallucination**: Assessors must cite exact page references and cannot infer beyond what documents explicitly state

---

## PART 1: ASSESSMENT METHODOLOGY

### 1.1 Document Discovery Process

**Objective**: Identify all relevant company disclosure documents

**Search Strategy**:
- **Primary sources**: CDP Climate Change responses, TCFD reports, Sustainability/ESG reports, Annual Reports (10-K, 20-F)
- **Secondary sources**: Climate strategy documents, risk management disclosures, investor presentations
- **Search queries**: Use company domain (e.g., site:company.com) combined with keywords:
  - "climate risk" OR "physical risk" OR "climate change"
  - "TCFD" OR "CDP" OR "sustainability report"
  - "flood" OR "drought" OR "wildfire" OR "storm" OR "heat"
- **Document limit**: Analyze up to 30 documents per company, prioritizing most recent and comprehensive sources

**Document Prioritization**:
1. Most recent CDP Climate Change response (highest priority - most comprehensive)
2. Latest TCFD report or TCFD-aligned disclosure
3. Current year sustainability/ESG report
4. Annual report (10-K/20-F) with climate risk section
5. Dedicated climate strategy or adaptation documents

### 1.2 Evidence Extraction Process

**Keyword-Based Filtering**:
- Extract all passages containing physical climate hazard keywords:
  - **Acute hazards**: flood, flooding, hurricane, cyclone, typhoon, storm, tornado, wildfire, fire, heatwave, extreme heat, cold snap, drought
  - **Chronic hazards**: sea level rise, temperature increase, precipitation change, water stress, coastal erosion
- Include context (3-5 sentences before and after keyword mention)
- Tag each passage with: document title, page number, section heading

**Quality Criteria for Evidence**:
- **Specific**: Names concrete actions, measures, or outcomes (not generic statements)
- **Quantified**: Includes numbers, percentages, coverage metrics where applicable
- **Attributed**: Can be traced to specific document location (page, section)
- **Relevant**: Directly addresses the measure being assessed
- **Recent**: From last 2-3 years (older evidence receives lower weight)

### 1.3 Scoring Methodology

**General Scoring Scale (0-5)**:

- **Score 0 - No Evidence**
  - No relevant information found in any document
  - Generic statements that don't address the measure
  - Evidence that mentions topic but shows no action or implementation
  
- **Score 1 - Minimal Evidence**
  - Awareness or acknowledgment only, no concrete actions
  - High-level aspirational statements without specifics
  - Generic processes that aren't climate-specific (where climate-specificity required)
  - Coverage: <25% of relevant scope
  
- **Score 2 - Basic Evidence**
  - Some concrete actions but limited in scope
  - Pilot programs or site-specific initiatives
  - Qualitative descriptions without quantification
  - Coverage: 25-49% of relevant scope
  
- **Score 3 - Moderate Evidence**
  - Systematic approach with documented processes
  - Multiple specific examples or geographies
  - Some quantification (basic metrics or coverage percentages)
  - Coverage: 50-79% of relevant scope
  
- **Score 4 - Strong Evidence**
  - Comprehensive, organization-wide approach
  - Detailed quantification and specific metrics
  - Evidence of implementation and progress tracking
  - Coverage: 80-94% of relevant scope
  
- **Score 5 - Excellent Evidence**
  - Best practice approach with outcomes tracked
  - Extensive quantification with trend analysis
  - External validation or third-party verification
  - Coverage: ≥95% of relevant scope
  - Clear evidence of continuous improvement

**Coverage Calculation**:
- For asset-based measures: % of assets by value, number, or criticality
- For geographic measures: % of operations, facilities, or employees
- For supply chain measures: % of suppliers by spend or criticality
- For process measures: % of relevant business units or functions

**Scoring Decision Framework**:

```
START: Review all extracted evidence for the measure

STEP 1: Is there any specific evidence?
├─ NO → Score 0
└─ YES → Continue to STEP 2

STEP 2: Does evidence show concrete action/implementation?
├─ NO → Score 1 (awareness only)
└─ YES → Continue to STEP 3

STEP 3: Is approach systematic (not just one-off)?
├─ NO → Score 2 (isolated actions)
└─ YES → Continue to STEP 4

STEP 4: What is the coverage/scope?
├─ <50% → Score 2
├─ 50-79% → Score 3
├─ 80-94% → Score 4
└─ ≥95% → Continue to STEP 5

STEP 5: Is there quantification and outcomes tracking?
├─ NO → Use coverage to assign Score 3-4
└─ YES → Score 4-5 based on comprehensiveness
```

### 1.4 Evidence Documentation Requirements

**For Each Measure, Document**:
1. **Evidence Summary**: 2-3 sentence summary of findings
2. **Verbatim Quotes**: Exact text from source documents (with page references)
3. **Source Citations**: Document title, year, page number, section
4. **Score Justification**: Explanation linking evidence to score
5. **Coverage Assessment**: Estimated percentage of scope covered (with basis)
6. **Confidence Level**: High/Medium/Low based on evidence quality and completeness

**Evidence Citation Format**:
```
"[Exact quote from document]" (Document Title, Year, p. XX, Section Y)
```

**Example Evidence Entry**:
```
Measure: M08 - Hazard identification & prioritization
Score: 4
Evidence Summary: Company has identified 5 priority physical climate hazards with 
detailed geographic analysis across all operating regions.

Verbatim Quote 1: "We have identified five priority physical climate hazards based 
on likelihood and financial impact assessment: flooding (affecting 45 facilities), 
extreme heat (38 facilities), water stress (22 facilities), wildfires (15 facilities), 
and tropical cyclones (12 facilities)." (Climate Risk Report 2024, p. 23, Risk 
Assessment section)

Verbatim Quote 2: "Geographic hazard mapping completed for 100% of owned facilities 
across 15 countries, with facility-level risk scores ranging from low (1) to critical (5)." 
(CDP Climate Change Response 2024, p. 47, C2.3a)

Coverage: 100% of facilities assessed (247/247 facilities)
Confidence: High
```

### 1.5 Handling Ambiguous Cases

**When Evidence is Partial**:
- Score based on what is demonstrated, not inferred
- Note gaps in coverage or specificity in justification
- If coverage is unclear, estimate conservatively with explanation

**When Evidence is Indirect**:
- Generic risk management processes: Only credit if explicitly applied to climate risks
- Industry standard practices: Only credit if company specifically confirms adoption
- Implied actions: Do not credit without explicit statement

**When Evidence is Contradictory**:
- Prioritize most recent evidence
- Note contradictions in assessment
- Consider whether contradiction indicates improving or declining performance

**When Multiple Documents Provide Different Information**:
- Use most comprehensive and specific source
- Cross-reference to ensure consistency
- Note discrepancies if material to assessment

---

## PART 2: THE 44 MEASURES

### CATEGORY 1: Governance & Strategic Oversight (M01-M07)

**Category Purpose**: Assess whether physical climate risks are governed at the highest levels of the organization with clear accountability, strategic integration, and stakeholder engagement.

**Climate-Specificity**: HIGH - Requires explicit evidence of physical climate risk governance

---

#### M01 - Board-level Physical Risk Oversight

**Definition**: Board of Directors has explicit oversight responsibility for physical climate risks (not just general climate/sustainability issues).

**What Constitutes Evidence**:
- Board committee charter specifically mentioning physical/adaptation/resilience risks
- Documented board meeting agendas/minutes discussing physical climate risks
- Board expertise in climate science, risk management, or sustainability
- Board approval of climate adaptation strategies or major adaptation investments

**What Does NOT Constitute Evidence**:
- Generic sustainability committee without climate risk specificity
- Board oversight of ESG or climate mitigation (decarbonization) only
- General risk committee without documented physical climate risk discussions

**Scoring Guidance**:
- **Score 1**: Board mentions climate in general terms without physical risk specificity
- **Score 2**: Board committee has climate in mandate but no evidence of physical risk focus
- **Score 3**: Board committee explicitly oversees physical climate risks, meets ≥2x/year on topic
- **Score 4**: Board with climate expertise, quarterly physical risk reviews, strategic decisions documented
- **Score 5**: Best practice governance with board KPIs, external reporting on oversight activities

**Evidence Examples**:

*Score 5 Example*:
"The Board Sustainability Committee, chaired by Director Jane Smith (former NOAA climate scientist), reviews physical climate risk quarterly. In 2024, the Committee approved $50M for coastal facility flood protection and updated our Climate Adaptation Strategy. Committee performance is evaluated annually based on risk management outcomes." (Annual Report 2024, p. 15, Corporate Governance)

*Score 2 Example*:
"Our Board oversees climate-related risks and opportunities through the Risk Committee." (Sustainability Report 2024, p. 8) [Generic statement without physical risk specificity]

---

#### M02 - Senior Management Responsibility

**Definition**: C-suite executives have defined, documented responsibilities for managing physical climate risks with accountability mechanisms.

**What Constitutes Evidence**:
- Named executive role (e.g., Chief Risk Officer, Chief Sustainability Officer) with physical climate risk in job description/mandate
- Executive KPIs or objectives explicitly including physical risk management
- Executive compensation linked to climate resilience/adaptation metrics
- Regular management committee meetings on physical climate risks

**What Does NOT Constitute Evidence**:
- Generic sustainability officer without physical risk mandate
- Executive responsibility for emissions reduction only
- Vague statements about "management oversight"

**Scoring Guidance**:
- **Score 1**: General management oversight without named accountabilities
- **Score 2**: Named role but no evidence of specific physical risk responsibilities
- **Score 3**: C-suite executive with explicit physical risk mandate, regular reporting documented
- **Score 4**: Executive KPIs or compensation linked to physical risk metrics
- **Score 5**: Enterprise-wide accountability with cross-functional coordination and performance tracking

**Key Question**: Can you identify a specific person by name and title who is accountable for physical climate risks?

---

#### M03 - Integration into Enterprise Risk Management

**Definition**: Physical climate risks are formally integrated into the company's enterprise risk management (ERM) framework, not managed as a separate sustainability issue.

**What Constitutes Evidence**:
- Physical climate risks listed in enterprise risk register/risk matrix
- Climate risks assessed using standard ERM methodology (likelihood × impact, risk appetite, etc.)
- Integration with other enterprise risks (financial, operational, strategic, reputational)
- Board/audit committee oversight of climate risks through ERM process
- Risk quantification using same methods as other enterprise risks

**What Does NOT Constitute Evidence**:
- Climate risks mentioned in sustainability report but not in risk disclosures
- Separate climate risk assessment not connected to ERM
- Generic statement that "we consider climate as a risk"

**Scoring Guidance**:
- **Score 1**: Climate mentioned in passing but not in formal risk framework
- **Score 2**: Climate risks listed but not assessed with ERM methodology
- **Score 3**: Physical risks in risk register, assessed using standard ERM methods
- **Score 4**: Full integration with risk appetite statements, mitigation plans, regular monitoring
- **Score 5**: Climate quantified using same financial models as other risks, fully embedded in ERM processes

**Key Evidence**: Look for physical climate risks appearing in 10-K/20-F Risk Factors sections, not just sustainability reports.

---

#### M04 - Public Adaptation/Resilience Commitments

**Definition**: Company has made specific, measurable, time-bound public commitments to climate adaptation or resilience building (not decarbonization targets).

**What Constitutes Evidence**:
- Public commitment to adaptation goals (e.g., "climate-proof all facilities by 2030")
- Specific, quantified targets (e.g., "reduce climate-related downtime by 50% by 2025")
- Time-bound commitments with interim milestones
- Regular public reporting on progress against commitments
- Science-based adaptation targets (e.g., aligned with warming scenarios)

**What Does NOT Constitute Evidence**:
- Net zero or emissions reduction commitments (these are mitigation, not adaptation)
- Generic aspirations without specific targets or timelines
- Internal goals not publicly disclosed

**Scoring Guidance**:
- **Score 1**: Aspiration to build resilience without specific commitments
- **Score 2**: Qualitative commitment without measurable targets or timelines
- **Score 3**: Public commitment with time-bound goals (but limited specificity)
- **Score 4**: Specific, measurable targets with interim milestones and progress reporting
- **Score 5**: Science-based, externally validated commitments with regular third-party progress assessments

**Note**: This is one of the most difficult measures to score high, as few companies make explicit adaptation commitments.

---

#### M05 - Scenario Analysis & Strategic Planning

**Definition**: Company uses formal climate scenario analysis (e.g., IPCC scenarios) to assess physical risks under different warming futures and integrates insights into strategic planning.

**What Constitutes Evidence**:
- Use of recognized climate scenarios: IPCC RCPs (2.6, 4.5, 8.5), SSPs, IEA scenarios, etc.
- Multiple time horizons analyzed (typically 2030, 2050, 2100 or similar)
- Assessment of physical risk impacts under each scenario
- Scenario insights integrated into business strategy, capital allocation, or M&A decisions
- Quantification of impacts under different scenarios

**What Does NOT Constitute Evidence**:
- Acknowledgment that climate scenarios exist without conducting analysis
- Scenario analysis focused only on transition risks (policy, technology, market changes)
- Single scenario or single time horizon only

**Scoring Guidance**:
- **Score 1**: Awareness of scenarios without analysis conducted
- **Score 2**: Scenario analysis mentioned but no details on scenarios or findings
- **Score 3**: Analysis of ≥2 scenarios for ≥1 time horizon with some quantification
- **Score 4**: Comprehensive analysis of ≥3 scenarios across multiple time horizons (2030, 2050+)
- **Score 5**: Scenario analysis directly informing strategic decisions (capital allocation, site selection, etc.) with documented examples

**Key Question**: Can the company articulate how their business strategy would differ under 2°C vs. 4°C warming?

---

#### M06 - Stakeholder Engagement on Physical Risk

**Definition**: Company actively engages with key stakeholders (investors, customers, employees, communities, suppliers) specifically on physical climate risk management.

**What Constitutes Evidence**:
- Investor engagement on physical risk exposure and management
- Customer communication about supply chain or product resilience
- Employee training or communication on climate risks and preparedness
- Community engagement on local climate adaptation (especially for facilities in vulnerable areas)
- Supplier engagement on supply chain climate resilience
- Documentation of engagement activities (meetings, surveys, workshops) and outcomes

**What Does NOT Constitute Evidence**:
- General stakeholder engagement on sustainability without physical risk focus
- One-way communication (disclosure) without actual engagement/dialogue
- Engagement only on emissions reduction (mitigation)

**Scoring Guidance**:
- **Score 1**: Minimal documented stakeholder engagement on physical risks
- **Score 2**: Engagement with 1-2 stakeholder groups in limited manner
- **Score 3**: Regular engagement with ≥3 stakeholder groups with documented feedback
- **Score 4**: Comprehensive engagement program with feedback integration into risk management
- **Score 5**: Leading multi-stakeholder engagement with collaborative adaptation initiatives

---

#### M07 - Policy Advocacy & Industry Collaboration

**Definition**: Company engages in policy advocacy or industry collaboration specifically on climate adaptation, resilience, or physical risk management (not just general climate policy).

**What Constitutes Evidence**:
- Membership in adaptation-focused industry initiatives
- Policy advocacy for adaptation funding, resilient infrastructure, building codes, etc.
- Collaboration with peers, government, NGOs on adaptation solutions
- Thought leadership (white papers, conferences) on physical climate risk
- Support for adaptation-related regulations or standards

**What Does NOT Constitute Evidence**:
- Membership in general sustainability groups without adaptation focus
- Policy advocacy solely on emissions reduction or climate mitigation
- General corporate political activity

**Scoring Guidance**:
- **Score 1**: No documented policy engagement on adaptation
- **Score 2**: Membership in industry groups that mention adaptation among many topics
- **Score 3**: Active participation in ≥1 adaptation-focused initiative with documented contributions
- **Score 4**: Policy advocacy and multi-stakeholder collaboration with demonstrated impact
- **Score 5**: Leadership role in shaping adaptation policy, standards, or industry best practices

---

### CATEGORY 2: Risk Identification & Assessment (M08-M16)

**Category Purpose**: Assess the comprehensiveness and quality of the company's physical climate risk assessment, from hazard identification through financial quantification to disclosure.

**Climate-Specificity**: HIGH - Requires explicit physical climate risk assessment, not generic risk assessment

---

#### M08 - Hazard Identification & Prioritization

**Definition**: Company has systematically identified the specific physical climate hazards relevant to its operations and prioritized them based on likelihood and impact.

**What Constitutes Evidence**:
- List of specific hazards identified: acute (floods, storms, wildfires, extreme heat, drought) and/or chronic (sea level rise, temperature shifts, water stress)
- Evidence of prioritization based on risk criteria (likelihood, impact, financial materiality)
- Geographic specificity (which hazards affect which locations)
- Number of priority hazards identified (more comprehensive = higher score)

**What Does NOT Constitute Evidence**:
- Generic mention of "climate risks" without naming specific hazards
- List of hazards without any prioritization or geographic specificity
- Hazards mentioned only in hypothetical or scenario analysis context

**Scoring Guidance**:
- **Score 1**: Generic awareness of climate change without specific hazards identified
- **Score 2**: 1-2 hazards mentioned without prioritization or geographic detail
- **Score 3**: ≥3 priority hazards identified with geographic specificity
- **Score 4**: Comprehensive hazard assessment (≥5 hazards) across all operations with prioritization
- **Score 5**: Detailed hazard prioritization with quantified likelihood, impact, and financial materiality for each

**Coverage Metric**: Number of distinct hazards assessed and % of operations/geographies covered.

---

#### M09 - Asset Exposure Mapping

**Definition**: Company has mapped which specific assets, facilities, or operations are exposed to which physical climate hazards.

**What Constitutes Evidence**:
- Asset-level exposure mapping (facility names, locations, specific hazards)
- Use of GIS or mapping tools overlaying climate hazard data on asset locations
- Identification of high-risk assets or facilities
- Quantification of assets at risk (number of facilities, value of assets, % of capacity)

**What Does NOT Constitute Evidence**:
- General statement that "we have facilities in vulnerable areas"
- List of facility locations without hazard overlay
- Awareness of mapping tools without evidence of use

**Scoring Guidance**:
- **Score 1**: Awareness of asset locations without hazard exposure analysis
- **Score 2**: Some exposure identification but <50% of assets mapped
- **Score 3**: Exposure mapping covering 50-79% of assets by value with hazard identification
- **Score 4**: Comprehensive mapping (80-94%) with multiple hazards per asset
- **Score 5**: Detailed exposure analysis (≥95%) with financial quantification of assets at risk

**Coverage Metric**: % of total assets by value (or number of facilities) with exposure assessed.

---

#### M10 - Vulnerability Assessment

**Definition**: Company has assessed the vulnerability or resilience of its assets to identified hazards (not just exposure, but likelihood of damage/disruption if hazard occurs).

**What Constitutes Evidence**:
- Assessment of asset resilience characteristics (building standards, protective measures, age, etc.)
- Vulnerability scoring or classification (e.g., low/medium/high vulnerability)
- Identification of specific vulnerabilities (e.g., "Facility X has inadequate flood defenses")
- Assessment of adaptive capacity (ability to respond and recover)

**What Does NOT Constitute Evidence**:
- Exposure mapping without vulnerability assessment (exposure ≠ vulnerability)
- Generic statements about "assessing resilience" without specifics
- Third-party data on vulnerability without company-specific assessment

**Scoring Guidance**:
- **Score 1**: No vulnerability assessment conducted
- **Score 2**: Vulnerability mentioned for some assets without systematic assessment
- **Score 3**: Vulnerability assessment covering 50-79% of high-risk assets
- **Score 4**: Comprehensive assessment (80-94%) with vulnerability scoring methodology
- **Score 5**: Detailed vulnerability analysis with adaptation planning and investment prioritization

**Key Distinction**: Exposure (asset is in flood zone) vs. Vulnerability (asset lacks flood barriers and would be damaged by 1-meter flood).

---

#### M11 - Scenario Modeling & Quantification

**Definition**: Company uses climate models or third-party tools to quantify physical risk impacts (not just qualitative assessment).

**What Constitutes Evidence**:
- Use of climate models: Global Climate Models (GCMs), Regional Climate Models (RCMs), or third-party platforms (e.g., Jupiter, Four Twenty Seven, Climate X)
- Quantification of physical impacts: days of disruption, asset damage, crop loss, etc.
- Multiple scenarios and time horizons modeled
- Model validation or calibration to company-specific conditions

**What Does NOT Constitute Evidence**:
- Qualitative scenario narratives without quantification
- Use of generic industry reports without company-specific modeling
- "We are exploring modeling tools" without evidence of actual use

**Scoring Guidance**:
- **Score 1**: Awareness of modeling tools without use
- **Score 2**: Use of third-party data/reports without company-specific modeling
- **Score 3**: Scenario modeling for ≥2 scenarios covering priority risks
- **Score 4**: Comprehensive modeling with ≥3 scenarios, multiple hazards, multiple time horizons
- **Score 5**: Advanced modeling with validation, regular updates, and integration into financial planning

---

#### M12 - Financial Impact Quantification

**Definition**: Company has quantified the potential financial impacts of physical climate risks in monetary terms (revenue, costs, asset impairments, etc.).

**What Constitutes Evidence**:
- Quantification of potential losses: revenue impact, EBITDA impact, capex requirements, asset impairments
- Financial impact ranges or scenarios (e.g., "$50-100M annual impact under RCP 4.5")
- Assessment of insurance costs or uninsurable risks
- Quantification of adaptation investment needs
- Integration of financial impacts into business planning or financial disclosures

**What Does NOT Constitute Evidence**:
- Qualitative statements about "potential material impacts"
- Physical impact quantification without financial translation (e.g., "10 days downtime" without cost)
- Generic industry estimates not specific to company

**Scoring Guidance**:
- **Score 1**: No financial quantification, qualitative discussion only
- **Score 2**: Directional financial impact discussion (e.g., "could be material") without numbers
- **Score 3**: Quantification for ≥1 major hazard or geography with specific $ figures
- **Score 4**: Comprehensive quantification across multiple hazards/scenarios
- **Score 5**: Detailed financial modeling integrated into enterprise financial planning and risk management

**Note**: This is often the weakest area for companies. Even scores of 2-3 are relatively good performance.

---

#### M13 - Supply Chain Risk Assessment

**Definition**: Company has assessed physical climate risks in its supply chain, including supplier exposure and vulnerability.

**What Constitutes Evidence**:
- Assessment of supplier locations and exposure to climate hazards
- Identification of critical supply chain vulnerabilities
- Supply chain risk mapping or heat maps
- Supplier engagement or surveys on climate resilience
- Tier 1 and/or Tier 2+ supplier assessment

**What Does NOT Constitute Evidence**:
- Generic supply chain sustainability programs without physical risk focus
- Awareness of supply chain risks without assessment conducted
- Third-party supply chain data without company-specific analysis

**Scoring Guidance**:
- **Score 1**: Awareness of supply chain climate risks without assessment
- **Score 2**: Ad hoc or limited supplier risk assessment (<50% coverage)
- **Score 3**: Risk assessment covering 50-79% of suppliers by spend
- **Score 4**: Comprehensive assessment (80-94%) with geographic mapping and multi-tier analysis
- **Score 5**: Detailed supply chain risk analysis with quantified vulnerabilities and mitigation plans

**Coverage Metric**: % of supplier spend or % of critical suppliers assessed.

---

#### M14 - Third-Party Validation & External Review

**Definition**: Company's physical risk assessment has been reviewed, validated, or assured by external parties (consultants, academics, auditors).

**What Constitutes Evidence**:
- External review by climate risk consultants or engineering firms
- Academic partnerships or peer review of methodology
- Certification or accreditation of risk assessment (e.g., ISO standards)
- Independent assurance of climate disclosures by auditors
- Public disclosure of external validation reports

**What Does NOT Constitute Evidence**:
- Use of third-party tools/data without validation of company's own assessment
- General sustainability report assurance that doesn't cover climate risk assessment
- Membership in industry groups without specific external review

**Scoring Guidance**:
- **Score 0**: No external validation
- **Score 2**: Informal external consultation without formal review
- **Score 3**: Third-party review of risk assessment methodology
- **Score 4**: External validation of risk quantification and findings with report
- **Score 5**: Independent limited or reasonable assurance with public disclosure

**Note**: This is rare and typically only seen in leading companies. Score 0 is very common.

---

#### M15 - Regulatory Compliance & Disclosure

**Definition**: Company complies with relevant regulatory requirements for physical climate risk disclosure.

**What Constitutes Evidence**:
- TCFD-aligned disclosure with physical risk specifics
- SEC climate disclosure compliance (if US-listed or SEC registrant)
- EU CSRD/ESRS compliance (if EU operations or listing)
- Other regional disclosure frameworks (e.g., UK TCFD requirements, Singapore)
- Explicit statement of compliance with framework(s)

**What Does NOT Constitute Evidence**:
- Generic sustainability reporting without framework compliance
- Partial or incomplete TCFD disclosure missing physical risk elements
- Statement of "support for TCFD" without implementation

**Scoring Guidance**:
- **Score 1**: Minimal disclosure, non-compliant with any framework
- **Score 2**: Partial disclosure, some alignment with framework but gaps
- **Score 3**: Full compliance with ≥1 major disclosure framework (TCFD, SEC, or CSRD)
- **Score 4**: Comprehensive compliance with 2+ frameworks
- **Score 5**: Leading disclosure exceeding regulatory requirements with additional voluntary detail

**Key Frameworks to Check**:
- TCFD: Look for disclosure under all 11 recommendations, especially Strategy (b) on physical risks
- SEC: Look for climate risk in 10-K Item 1A Risk Factors
- CSRD: Look for ESRS E1 disclosures on adaptation and physical risks

---

#### M16 - Disclosure Quality & Transparency

**Definition**: Beyond compliance, company provides high-quality, detailed, transparent disclosure of physical climate risks.

**What Constitutes Evidence**:
- Detailed disclosure of risk assessment methodology with references
- Quantitative disclosure of impacts, not just qualitative
- Geographic and asset-specific disclosure (not just generic statements)
- Regular updates (annual or more frequent) with progress reporting
- Use of standardized metrics for comparability
- Accessible disclosure (not buried in hundreds of pages)

**What Does NOT Constitute Evidence**:
- Compliance-focused disclosure with minimal detail
- Generic or boilerplate language
- Disclosure scattered across multiple documents without integration

**Scoring Guidance**:
- **Score 1**: Minimal, generic, qualitative disclosure
- **Score 2**: Compliance-level disclosure with some specifics but limited detail
- **Score 3**: Detailed methodology and priority risks disclosed with some quantification
- **Score 4**: Quantitative disclosure with geographic specificity and regular updates
- **Score 5**: Best-in-class transparency: detailed quantitative disclosure, asset-level specifics, trends over time

**Assessment Approach**: Compare disclosure quality to industry peers and best practice examples.

---

### CATEGORY 3: Asset Design & Resilience (M17-M21)

**Category Purpose**: Assess physical adaptation measures implemented to increase resilience of company assets and infrastructure.

**Climate-Specificity**: HIGH - Requires climate-specific design standards and adaptation investments, not generic maintenance

---

#### M17 - Climate-Resilient Design Standards

**Definition**: Company uses design standards for new assets that explicitly incorporate climate change projections and resilience requirements.

**What Constitutes Evidence**:
- Engineering or design standards referencing climate projections (e.g., "design for 100-year flood + 20% for climate change")
- Building codes or specifications exceeding baseline requirements for climate resilience
- Design guidelines for specific hazards (flood-resistant, wind-resistant, heat-resistant)
- Examples of projects using climate-resilient design
- Coverage: % of new construction using these standards

**What Does NOT Constitute Evidence**:
- Standard building codes without climate enhancement
- Energy efficiency or sustainability design (LEED, etc.) without climate resilience focus
- Aspirational statements without implemented standards

**Scoring Guidance**:
- **Score 1**: Standard building codes without climate considerations
- **Score 2**: Some enhanced design for specific projects but no systematic standards
- **Score 3**: Climate-resilient standards for 50-79% of new assets
- **Score 4**: Comprehensive standards (80-94%) incorporating future climate projections
- **Score 5**: Group-wide mandatory standards with specific hazard criteria and validation

**Key Question**: Do design standards use future climate projections or just historical climate data?

---

#### M18 - Retrofitting & Hardening Programs

**Definition**: Company has active programs to retrofit or harden existing assets to improve climate resilience.

**What Constitutes Evidence**:
- Documented retrofitting program with investment amounts
- Specific adaptation measures implemented (flood barriers, roof reinforcement, cooling systems, etc.)
- Asset hardening initiatives (protective coatings, storm shutters, backup power, etc.)
- Number or % of facilities retrofitted
- Outcomes tracked (e.g., reduced damage in subsequent events)

**What Does NOT Constitute Evidence**:
- Standard facility maintenance without climate focus
- Energy efficiency upgrades without resilience component
- Aspirations to retrofit without actual implementation

**Scoring Guidance**:
- **Score 1**: Standard maintenance without adaptation focus
- **Score 2**: Ad hoc retrofitting of individual assets without program
- **Score 3**: Formal retrofitting program covering 25-49% of vulnerable assets
- **Score 4**: Comprehensive program (50-79%) with quantified investment ($X invested)
- **Score 5**: Extensive program (≥80%) with outcomes tracking and continuous improvement

**Coverage Metric**: % of vulnerable assets retrofitted or % of total assets by value.

---

#### M19 - Nature-Based Solutions

**Definition**: Company uses nature-based solutions (green infrastructure, ecosystem restoration) for climate adaptation.

**What Constitutes Evidence**:
- Green infrastructure projects: wetlands, mangroves, green roofs, bioswales, rain gardens
- Natural flood defenses: restored floodplains, living shorelines
- Urban forestry or vegetation for heat mitigation
- Ecosystem restoration for resilience (coral reefs, forests, grasslands)
- Specific examples with locations and outcomes

**What Does NOT Constitute Evidence**:
- Biodiversity projects without adaptation rationale
- Tree planting for carbon offsets (mitigation, not adaptation)
- Landscaping without climate resilience function

**Scoring Guidance**:
- **Score 0**: No nature-based solutions implemented
- **Score 2**: Pilot nature-based project at 1 site
- **Score 3**: Implementation at 2-3 sites with documented resilience benefits
- **Score 4**: Systematic deployment across ≥4 sites with monitoring
- **Score 5**: Comprehensive nature-based adaptation strategy with quantified outcomes

**Note**: Nature-based solutions are relatively rare in corporate adaptation, so any score >0 is noteworthy.

---

#### M20 - Critical Infrastructure Protection

**Definition**: Company has specific measures to protect critical infrastructure from climate hazards.

**What Constitutes Evidence**:
- Protection of critical systems: power, water, IT, communications, transportation
- Backup systems and redundancy (backup power, dual water supplies, etc.)
- Physical barriers (flood walls, storm shutters, fire breaks)
- Critical infrastructure resilience plans with testing
- Coverage: % of critical infrastructure with protection measures

**What Does NOT Constitute Evidence**:
- Standard IT backup procedures without climate resilience focus
- Emergency generators required by code without climate-specific deployment
- General infrastructure maintenance

**Scoring Guidance**:
- **Score 1**: Standard infrastructure without climate-specific protection
- **Score 2**: Some protection measures but limited coverage (<50%)
- **Score 3**: Protection measures for 50-79% of critical infrastructure
- **Score 4**: Comprehensive protection (80-94%) with backup systems and testing
- **Score 5**: Best practice protection (≥95%) with regular testing and continuous improvement

**Key Infrastructure**: Power/backup power, water supply, IT/data centers, access roads, communications.

---

#### M21 - Relocation & Strategic Divestment

**Definition**: Company has relocated or divested assets specifically due to physical climate risk exposure.

**What Constitutes Evidence**:
- Documented relocation of facilities from high-risk to lower-risk areas
- Strategic divestment of climate-vulnerable assets with climate risk cited as rationale
- Managed retreat from climate-exposed geographies
- Climate risk integration into capital allocation or site selection decisions
- Specific examples with before/after locations and financial details

**What Does NOT Constitute Evidence**:
- Standard real estate rationalization without climate rationale
- Future plans to consider climate in site selection without implementation
- Divestment for other business reasons (not climate risk)

**Scoring Guidance**:
- **Score 0**: No evidence of climate-driven relocation or divestment
- **Score 2**: Climate risk considered in site selection but no actual relocations yet
- **Score 3**: Relocation or divestment of ≥1 asset with climate risk as stated factor
- **Score 4**: Systematic relocation program or portfolio reshaping with climate criteria
- **Score 5**: Comprehensive climate-informed capital allocation with multiple examples

**Note**: This is rare (most companies haven't yet relocated assets for climate). Score 0 is very common.

---

### CATEGORY 4: Crisis Management (M22-M26)

**Category Purpose**: Assess preparedness for climate-related disruptions through business continuity and emergency response capabilities.

**Climate-Specificity**: LOW - These are HAZARD-AGNOSTIC measures. Accept evidence for ANY major disruption (not just climate-specific).

**Important**: These measures assess general operational resilience capabilities that would be useful for climate events but do not require climate-specific evidence. A company with excellent BCPs for any type of disruption should score well here, even if they don't mention climate.

---

#### M22 - Business Continuity Plans (BCPs)

**Definition**: Company has documented business continuity plans to maintain critical operations during any major disruption.

**What Constitutes Evidence** (ANY disruption type):
- Documented business continuity plans (BCPs)
- Disaster recovery plans (DRPs)
- Emergency preparedness programs
- Operational resilience frameworks
- ISO 22301 (Business Continuity Management) certification
- Evidence of testing/exercising BCPs
- Recovery strategies documented

**What Does NOT Constitute Evidence**:
- Generic mention of "being prepared" without documented plans
- Informal or undocumented arrangements
- Plans that only cover IT/data (need operational continuity)

**Scoring Guidance**:
- **Score 1**: Awareness of continuity needs but no documented plans
- **Score 2**: BCPs exist for some operations but limited coverage (<50%)
- **Score 3**: Documented BCPs covering 50-79% of critical operations
- **Score 4**: Comprehensive BCPs (80-94%) with regular testing
- **Score 5**: Group-wide BCPs (≥95%) with ISO 22301 or similar, regular testing and continuous improvement

**Coverage Metric**: % of critical operations or facilities with documented BCPs.

**Clarification**: Climate can be mentioned but is NOT required. Evidence of BCPs for cyber attacks, supply chain disruptions, pandemics, etc. all count.

---

#### M23 - Emergency Response Protocols

**Definition**: Company has emergency response protocols for any type of emergency event (not just climate).

**What Constitutes Evidence** (ANY emergency type):
- Emergency response plans (ERPs)
- Incident command systems (ICS)
- Emergency response teams and training
- Coordination procedures with emergency services
- Employee evacuation procedures
- Emergency communication systems
- Evidence of drills or exercises

**What Does NOT Constitute Evidence**:
- Occupational safety programs without emergency protocols
- Generic health and safety statements
- Fire alarms without broader emergency response

**Scoring Guidance**:
- **Score 1**: Basic safety programs without emergency response protocols
- **Score 2**: Some emergency protocols but limited scope (1-2 hazard types)
- **Score 3**: Documented protocols covering ≥3 hazard types with trained teams
- **Score 4**: Comprehensive protocols with regular drills and multi-hazard coverage
- **Score 5**: Best practice emergency response with continuous improvement and outcomes tracking

**Hazard Types**: Fire, chemical spill, workplace injury, severe weather, earthquake, flood, etc.

---

#### M24 - Crisis Communication Systems

**Definition**: Company has systems to communicate with stakeholders during any type of crisis.

**What Constitutes Evidence** (ANY crisis type):
- Crisis communication systems and protocols
- Emergency notification systems (text, email, app alerts)
- Stakeholder communication plans (employees, customers, suppliers, investors, media)
- Employee alert systems or mass notification
- Public communication protocols
- Evidence of testing/exercising communication systems

**What Does NOT Constitute Evidence**:
- Standard business communications without crisis protocols
- Marketing or PR teams without crisis communication training
- Generic statements about "keeping stakeholders informed"

**Scoring Guidance**:
- **Score 1**: No documented crisis communication system
- **Score 2**: Basic communication capability but limited stakeholder groups (1-2 groups)
- **Score 3**: Documented system covering ≥3 stakeholder groups
- **Score 4**: Comprehensive system (≥5 groups) with testing and multiple channels
- **Score 5**: Group-wide system with performance tracking and continuous improvement

**Stakeholder Groups**: Employees, customers, suppliers, investors, regulators, media, communities.

---

#### M25 - Recovery Time Objectives (RTOs)

**Definition**: Company has defined recovery time objectives for critical operations (how quickly operations must be restored after any disruption).

**What Constitutes Evidence** (ANY disruption type):
- Recovery time objectives (RTOs) defined for critical systems/operations
- Maximum acceptable outage (MAO) or maximum tolerable downtime (MTD)
- Restoration time targets
- Business continuity metrics
- Evidence of tracking achievement against RTOs

**What Does NOT Constitute Evidence**:
- General goal to "recover quickly" without specific timeframes
- IT recovery times without operational RTOs
- Service level agreements (SLAs) without internal RTOs

**Scoring Guidance**:
- **Score 1**: Generic recovery expectations without defined RTOs
- **Score 2**: RTOs defined for some critical systems but limited coverage (<50%)
- **Score 3**: RTOs defined for 50-79% of critical operations
- **Score 4**: Comprehensive RTOs (80-94%) with achievement tracking
- **Score 5**: Group-wide RTOs (≥95%) with performance monitoring and continuous improvement

**Coverage Metric**: % of critical operations or systems with defined RTOs.

**Example RTO**: "Customer order system must be restored within 4 hours of any outage."

---

#### M26 - Post-Event Review & Continuous Improvement

**Definition**: Company conducts post-event reviews after any significant disruption to identify lessons learned and improve resilience.

**What Constitutes Evidence** (ANY event type):
- Post-event review processes or procedures
- Lessons learned programs
- After-action reviews (AARs)
- Root cause analysis of disruptions
- Implementation of improvements based on lessons learned
- Evidence of organizational learning
- Metrics tracking improvement over time

**What Does NOT Constitute Evidence**:
- Standard incident reports without learning or improvement process
- Reactive problem-solving without systematic review
- Reviews conducted but no evidence of improvements implemented

**Scoring Guidance**:
- **Score 1**: No systematic post-event review process
- **Score 2**: Ad hoc reviews of some events without formal process
- **Score 3**: Documented process reviewing 50-79% of significant events
- **Score 4**: Comprehensive process (80-94%) with tracked improvements
- **Score 5**: Group-wide process with organizational learning culture and accountability

**Coverage Metric**: % of significant disruption events with formal post-event review.

---

### CATEGORY 5: Supply Chain Management (M27-M31)

**Category Purpose**: Assess supply chain resilience to physical climate risks through risk assessment, diversification, and contractual protections.

**Climate-Specificity**: MEDIUM - Supply chain resilience measures can accept evidence for climate OR general disruption resilience

---

#### M27 - Supplier Risk Assessment & Mapping

**Definition**: Company assesses physical climate risks in its supplier base, including supplier exposure mapping.

**What Constitutes Evidence**:
- Supplier risk assessments (climate-specific or general business continuity)
- Supply chain risk mapping or heat maps
- Geographic supplier mapping with hazard overlays
- Supplier climate risk analysis or surveys
- Identification of vulnerable suppliers

**What Does NOT Constitute Evidence**:
- Supplier list without risk assessment
- General supplier management without risk focus
- Third-party supply chain data not applied to company's suppliers

**Scoring Guidance**:
- **Score 1**: Supplier lists maintained but no risk assessment
- **Score 2**: Ad hoc supplier risk checks without systematic assessment
- **Score 3**: Risk assessment covering 50-79% of suppliers by spend
- **Score 4**: Comprehensive assessment (80-94%) with geographic mapping
- **Score 5**: Detailed risk analysis with climate hazard mapping and mitigation plans

**Coverage Metric**: % of supplier spend or % of critical suppliers assessed.

**Note**: Can credit general supplier risk assessment programs even without climate specificity.

---

#### M28 - Supplier Diversification & Redundancy

**Definition**: Company has diversified supplier base or built redundancy to reduce supply chain risk concentration.

**What Constitutes Evidence**:
- Multiple suppliers (dual/multi-sourcing) for critical inputs
- Geographic diversification of supplier base
- Backup suppliers or alternate sourcing strategies documented
- Supply chain redundancy strategy
- Examples of switching suppliers during disruptions

**What Does NOT Constitute Evidence**:
- Single-source suppliers for critical inputs
- Awareness of diversification without implementation
- Plans to diversify without actual alternative suppliers secured

**Scoring Guidance**:
- **Score 0**: Single-source suppliers for most critical inputs
- **Score 2**: Some diversification but limited coverage (<50% of critical inputs)
- **Score 3**: Diversification for 50-79% of critical inputs
- **Score 4**: Comprehensive diversification (80-94%) with geographic spread
- **Score 5**: Strategic redundancy with climate risk criteria and demonstrated resilience

**Coverage Metric**: % of critical inputs with multiple suppliers.

---

#### M29 - Contractual Protections & SLAs

**Definition**: Company has contractual provisions addressing supply chain disruptions, including force majeure, service level agreements, and resilience requirements.

**What Constitutes Evidence**:
- Force majeure clauses in supplier contracts (any disruption type, not just climate)
- Service level agreements (SLAs) with resilience or business continuity requirements
- Supplier obligations to maintain BCPs or disaster recovery capabilities
- Contract provisions for alternative sourcing during disruptions
- Liquidated damages for supply failures

**What Does NOT Constitute Evidence**:
- Standard purchase agreements without business continuity provisions
- Generic terms and conditions without resilience requirements
- Verbal agreements without contractual documentation

**Scoring Guidance**:
- **Score 1**: Standard contracts without disruption provisions
- **Score 2**: Some disruption provisions in limited contracts (<50%)
- **Score 3**: Resilience provisions in 50-79% of critical supplier contracts
- **Score 4**: Comprehensive provisions (80-94%) with SLAs
- **Score 5**: Best practice contractual protections with enforcement mechanisms

**Coverage Metric**: % of critical supplier contracts (by value) with resilience provisions.

---

#### M30 - Inventory Management & Buffer Stocks

**Definition**: Company maintains strategic inventory buffers to absorb supply chain disruptions.

**What Constitutes Evidence**:
- Strategic inventory buffers or safety stock for critical inputs
- Safety stock policies documented
- Inventory positioning strategy for resilience (not just cost efficiency)
- Increased inventory levels in response to disruption risks
- Dynamic inventory management based on risk levels

**What Does NOT Constitute Evidence**:
- Pure just-in-time (JIT) inventory without buffers
- Standard inventory management focused only on cost/cash flow
- Emergency stock for very short-term needs only (<1 week)

**Scoring Guidance**:
- **Score 0**: JIT inventory without buffers
- **Score 2**: Some buffer stocks for specific inputs (<50% of critical inputs)
- **Score 3**: Buffer stocks for 50-79% of critical inputs
- **Score 4**: Comprehensive buffering (80-94%) with climate risk criteria
- **Score 5**: Dynamic inventory management optimized for resilience with quantified approach

**Coverage Metric**: % of critical inputs with buffer inventory maintained.

**Note**: Can credit general resilience buffering even without climate specificity.

---

#### M31 - Logistics & Transportation Resilience

**Definition**: Company has resilient logistics and transportation networks with multiple routes or modes available.

**What Constitutes Evidence**:
- Multiple transportation routes or modes for critical shipments
- Logistics network redundancy (backup distribution centers, ports, etc.)
- Alternative distribution channels documented
- Transportation risk monitoring systems
- Examples of re-routing during disruptions

**What Does NOT Constitute Evidence**:
- Single transportation route without alternatives
- Cost-optimized logistics without resilience consideration
- Use of freight forwarders without assessment of their redundancy

**Scoring Guidance**:
- **Score 1**: Single-route logistics without alternatives
- **Score 2**: Some alternative routes but limited coverage (<50% of critical flows)
- **Score 3**: Alternative routes for 50-79% of critical shipments
- **Score 4**: Comprehensive network redundancy (80-94%) with multiple modes
- **Score 5**: Resilient logistics with real-time monitoring and dynamic rerouting capabilities

**Coverage Metric**: % of critical shipment lanes with alternative routes.

---

### CATEGORY 6: Insurance & Risk Transfer (M32-M35)

**Category Purpose**: Assess use of insurance and risk transfer mechanisms to manage financial impacts of physical climate risks.

**Climate-Specificity**: MEDIUM - Focus on climate hazard coverage but traditional insurance approaches count

---

#### M32 - Insurance Coverage Adequacy

**Definition**: Company has adequate insurance coverage for physical climate risks, regularly reviews coverage, and understands protection gaps.

**What Constitutes Evidence**:
- Property insurance covering climate hazards (flood, windstorm, earthquake, etc.)
- Business interruption (BI) or contingent business interruption (CBI) insurance
- Coverage amounts disclosed or characterized as adequate
- Regular review of coverage adequacy (annual reviews documented)
- Quantification of insured vs. uninsured risks
- Discussion of insurance market challenges (cost, availability)

**What Does NOT Constitute Evidence**:
- Generic statement "we maintain insurance" without specifics
- Only liability or professional indemnity insurance (not property/BI)
- Insurance mentioned only in boilerplate risk factors

**Scoring Guidance**:
- **Score 1**: Generic insurance without climate hazard assessment
- **Score 2**: Some climate hazard coverage but limited scope or large gaps
- **Score 3**: Climate-specific coverage for 50-79% of high-risk assets
- **Score 4**: Comprehensive coverage (80-94%) with gap analysis
- **Score 5**: Optimal insurance strategy with regular reviews and quantified coverage adequacy

**Coverage Metric**: % of asset value covered for key climate hazards.

**Note**: Disclosure of insurance strategy is rare. Even basic evidence deserves credit.

---

#### M33 - Parametric Insurance & Innovative Products

**Definition**: Company uses parametric (index-based) or other innovative insurance products for climate risks.

**What Constitutes Evidence**:
- Parametric insurance policies (trigger-based payouts)
- Weather derivatives or index insurance
- Catastrophe bonds issued by company
- Pilot programs for new insurance solutions
- Use of specialized climate risk insurance products

**What Does NOT Constitute Evidence**:
- Awareness of parametric insurance without purchase
- Standard property/casualty insurance (covered in M32)
- Investment in cat bonds (need company to issue or purchase protection)

**Scoring Guidance**:
- **Score 0**: No innovative insurance products used
- **Score 2**: Pilot or small-scale use of innovative products
- **Score 3**: Parametric or innovative products for ≥1 hazard or geography
- **Score 4**: Systematic use across multiple hazards or geographies
- **Score 5**: Leading adoption with portfolio optimization and outcomes tracking

**Note**: This is rare. Score 0 is very common, and any evidence deserves credit.

---

#### M34 - Captives & Alternative Risk Transfer

**Definition**: Company uses captive insurance companies or other alternative risk transfer mechanisms.

**What Constitutes Evidence**:
- Captive insurance company owned by company
- Self-insurance programs or pools
- Risk pooling arrangements or mutual insurance
- Alternative risk transfer (ART) mechanisms
- Disclosure of retained vs. transferred risks

**What Does NOT Constitute Evidence**:
- Standard commercial insurance (covered in M32)
- Self-retention within standard deductibles
- Informal risk retention without structured program

**Scoring Guidance**:
- **Score 0**: No alternative risk transfer mechanisms
- **Score 2**: Captive or self-insurance for limited risks
- **Score 3**: Captive or self-insurance for ≥1 major risk category
- **Score 4**: Comprehensive ART strategy with multiple mechanisms
- **Score 5**: Optimized risk financing with quantified cost/benefit analysis

**Note**: Captives are common in some industries (e.g., utilities, large manufacturers). Disclosure is limited.

---

#### M35 - Claims Management & Recovery

**Definition**: Company has effective claims management and recovery processes following insured events.

**What Constitutes Evidence**:
- Claims management procedures documented
- Recovery process following insured losses
- Historical claims data disclosed (number, amounts recovered)
- Lessons learned from claims process
- Claims success rate or recovery rates
- Continuous improvement of claims handling

**What Does NOT Constitute Evidence**:
- Generic statement about filing claims when needed
- Insurance policy details without claims experience
- No historical claims (not their fault, but can't score without evidence)

**Scoring Guidance**:
- **Score 0**: No evidence of claims management process
- **Score 2**: Basic claims handling but no documented process
- **Score 3**: Documented claims process with historical data
- **Score 4**: Comprehensive process with recovery optimization
- **Score 5**: Best practice claims management with continuous improvement and lessons learned

**Note**: Very rare to find disclosure on this. Score 0 or 1 is typical.

---

### CATEGORY 7: Data Quality & Assurance (M36-M37)

**Category Purpose**: Assess quality of climate risk data and external assurance of disclosures.

**Climate-Specificity**: HIGH - Requires climate data governance and assurance

---

#### M36 - Data Governance & Quality

**Definition**: Company has governance processes to ensure quality of climate risk data used in assessments and disclosures.

**What Constitutes Evidence**:
- Data governance framework for climate data
- Data quality standards or validation procedures
- Climate data management systems or platforms
- Regular data quality audits
- Documentation of data sources and assumptions
- Data lineage or traceability

**What Does NOT Constitute Evidence**:
- Use of third-party data without validation
- Generic data governance without climate-specific application
- Ad hoc data collection without quality assurance

**Scoring Guidance**:
- **Score 1**: Ad hoc data management without governance
- **Score 2**: Some data quality procedures but limited formalization
- **Score 3**: Data governance framework with quality standards
- **Score 4**: Comprehensive governance with validation procedures and audits
- **Score 5**: Best practice data management with continuous improvement and traceability

**Note**: This is rare. Even score 2-3 indicates relatively mature approach.

---

#### M37 - External Assurance & Verification

**Definition**: Company obtains external assurance or verification of climate risk disclosures or assessments.

**What Constitutes Evidence**:
- Third-party assurance of climate disclosures (limited or reasonable assurance)
- Assurance by Big 4 accounting firms or specialist sustainability assurance providers
- Independent verification of climate risk assessments
- Public disclosure of assurance reports or statements
- Scope of assurance (what's covered, what's not)

**What Does NOT Constitute Evidence**:
- General financial audit that doesn't cover climate disclosures
- Participation in CDP or other disclosure platforms (these don't provide assurance)
- Internal audit without external party involvement

**Scoring Guidance**:
- **Score 0**: No external assurance of climate disclosures
- **Score 2**: External review or consultation but not formal assurance
- **Score 3**: Limited assurance of selected climate disclosures
- **Score 4**: Reasonable assurance of key climate disclosures including physical risks
- **Score 5**: Comprehensive reasonable assurance with public reporting and continuous expansion of scope

**Assurance Levels**:
- Limited assurance: Lower level, often called "review" (similar to review vs. audit)
- Reasonable assurance: Higher level, provides more confidence (similar to financial audit)

**Note**: External assurance is rare and expensive. Score 0 is very common.

---

### CATEGORY 8: Social & Community Resilience (M38-M39)

**Category Purpose**: Assess consideration of social impacts and support for community resilience.

**Climate-Specificity**: MEDIUM - Can credit general employee safety and community programs with some resilience relevance

---

#### M38 - Employee Safety & Well-being

**Definition**: Company has programs to protect employee safety and well-being during climate events or extreme weather.

**What Constitutes Evidence**:
- Employee safety programs for extreme weather (heat, cold, storms, flooding)
- Heat stress management programs for outdoor workers
- Emergency evacuation procedures and drills
- Employee support during climate events (emergency leave, relocation assistance, financial support)
- Occupational health programs addressing climate hazards
- Employee training on extreme weather safety

**What Does NOT Constitute Evidence**:
- Generic occupational health and safety programs without weather/climate component
- Office climate control without consideration of extreme events
- Standard emergency procedures without weather specificity

**Scoring Guidance**:
- **Score 1**: Generic safety programs without climate/weather focus
- **Score 2**: Some climate safety programs but limited coverage (<50% of exposed employees)
- **Score 3**: Climate-specific safety programs for 50-79% of exposed employees
- **Score 4**: Comprehensive programs (80-94%) with training and support
- **Score 5**: Best practice employee protection with well-being support and outcomes tracking

**Coverage Metric**: % of employees in climate-exposed roles with specific safety programs.

**Note**: Heat stress programs are common in some industries (outdoor work, agriculture, construction).

---

#### M39 - Community Engagement & Support

**Definition**: Company engages with and supports communities on climate resilience, especially in areas where company operates.

**What Constitutes Evidence**:
- Community engagement on local climate risks
- Support for community adaptation projects (funding, technical assistance, volunteering)
- Collaboration with local governments on resilience planning
- Community disaster response support or emergency assistance
- Vulnerable population support during climate events
- Community resilience partnerships or programs

**What Does NOT Constitute Evidence**:
- Generic corporate philanthropy without climate/resilience focus
- Community engagement on other sustainability topics (e.g., conservation without resilience link)
- One-off emergency responses without ongoing engagement

**Scoring Guidance**:
- **Score 0**: Minimal community engagement on climate resilience
- **Score 2**: Limited community engagement (<3 communities)
- **Score 3**: Engagement and support in ≥3 major operating locations
- **Score 4**: Systematic engagement with documented programs and outcomes
- **Score 5**: Leading community resilience partnerships with measurable community benefits

**Note**: This is relatively rare unless company operates in highly vulnerable areas or has strong community engagement culture.

---

### CATEGORY 9: Performance Metrics & Continuous Improvement (M40-M44)

**Category Purpose**: Assess tracking of climate adaptation performance metrics and continuous improvement.

**Climate-Specificity**: HIGH for M40-M44 - Requires climate-specific metrics (exception: M41 can include non-climate downtime if tracked)

---

#### M40 - Just Transition & Equity Considerations

**Definition**: Company considers equity, vulnerable populations, and just transition principles in climate adaptation planning and implementation.

**What Constitutes Evidence**:
- Assessment of adaptation impacts on vulnerable populations (workers, communities)
- Just transition principles in adaptation planning
- Equity considerations in resource allocation for adaptation
- Stakeholder engagement with vulnerable groups on adaptation
- Support for workers affected by facility closures or relocations due to climate risk
- Community support in adaptation implementation

**What Does NOT Constitute Evidence**:
- Just transition considerations only for emissions reduction (mitigation)
- Generic DEI programs without climate adaptation connection
- Community benefits without focus on vulnerable populations

**Scoring Guidance**:
- **Score 0**: No equity considerations in adaptation
- **Score 2**: Awareness of equity issues but limited action
- **Score 3**: Equity assessment for ≥1 major adaptation initiative
- **Score 4**: Systematic equity integration across adaptation planning
- **Score 5**: Leading just transition approach with stakeholder validation and measurable equity outcomes

**Note**: This is very rare. Most companies haven't considered equity dimensions of adaptation. Score 0 is most common.

---

#### M41 - Downtime & Disruption Metrics

**Definition**: Company tracks operational downtime and disruptions from climate events or other causes.

**What Constitutes Evidence**:
- Tracking of climate-related downtime (days, hours)
- Disruption metrics for extreme weather events
- Historical trend analysis of climate-related disruptions
- Performance against downtime targets or benchmarks
- NOTE: Can also credit general downtime tracking even if not climate-specific (useful for climate resilience)

**What Does NOT Constitute Evidence**:
- Qualitative descriptions of disruptions without metrics
- Planned maintenance downtime (not disruptions)
- Financial impacts without operational metrics (see M42)

**Scoring Guidance**:
- **Score 0**: No systematic downtime tracking
- **Score 2**: Ad hoc tracking of major events only
- **Score 3**: Systematic tracking for 50-79% of facilities
- **Score 4**: Comprehensive tracking (80-94%) with trend analysis
- **Score 5**: Best practice metrics with targets and continuous improvement

**Coverage Metric**: % of facilities with downtime tracking systems.

**Metrics Examples**: Hours of unplanned downtime per facility per year, number of climate-related shutdowns, days of reduced operations.

---

#### M42 - Financial Impact Tracking

**Definition**: Company tracks financial impacts of climate events, including losses, recovery costs, and insurance claims.

**What Constitutes Evidence**:
- Tracking of climate-related financial losses by event or cumulative
- Revenue, EBITDA, or profit impacts from climate disruptions
- Capital expenditure on recovery or repairs
- Insurance claims and recoveries tracked
- Historical trend analysis of financial impacts
- Comparison to budgets or forecasts

**What Does NOT Constitute Evidence**:
- One-time disclosure of major event impact without systematic tracking
- Future projections without historical tracking
- Operational impacts without financial translation

**Scoring Guidance**:
- **Score 0**: No systematic financial impact tracking
- **Score 2**: Ad hoc tracking of major events without systematic process
- **Score 3**: Systematic tracking for ≥1 major impact category (revenue, costs, capex, claims)
- **Score 4**: Comprehensive tracking across multiple categories with trend analysis
- **Score 5**: Detailed financial tracking with forecasting and risk-adjusted planning

**Impact Categories**: Lost revenue, increased costs, capital repairs, insurance claims, business interruption payments.

---

#### M43 - Supplier Disruption Metrics

**Definition**: Company tracks supply chain disruptions from climate events, including supplier downtime and performance during events.

**What Constitutes Evidence**:
- Tracking of supplier disruptions from climate events
- Supply chain downtime or delays due to weather/climate
- Supplier performance metrics during climate events
- Historical trend analysis of supply chain climate impacts
- Correlation of disruptions to specific climate events

**What Does NOT Constitute Evidence**:
- Generic supply chain KPIs without climate event tracking
- Supplier quality metrics without disruption focus
- Awareness of supply chain risks without measurement

**Scoring Guidance**:
- **Score 0**: No systematic supplier disruption tracking
- **Score 2**: Ad hoc tracking of major supply chain disruptions
- **Score 3**: Systematic tracking for 50-79% of critical suppliers
- **Score 4**: Comprehensive tracking (80-94%) with trend analysis
- **Score 5**: Best practice supply chain metrics with predictive capabilities

**Coverage Metric**: % of critical suppliers with disruption monitoring.

**Note**: This is rare. Most companies don't have visibility into supplier disruptions, let alone track them systematically.

---

#### M44 - Adaptation Spend & Outcomes

**Definition**: Company tracks investment in climate adaptation and quantifies outcomes achieved (e.g., reduced downtime, avoided losses, return on investment).

**What Constitutes Evidence**:
- Tracking of adaptation capital expenditures (capex)
- Tracking of adaptation operating expenses (opex)
- Quantification of adaptation outcomes (reduced downtime, avoided losses, lower insurance costs)
- Return on investment (ROI) analysis for adaptation investments
- Comparison of costs vs. benefits
- Continuous improvement based on outcomes

**What Does NOT Constitute Evidence**:
- Capex mentioned without tracking over time
- Outcomes described qualitatively without quantification
- Investment in general maintenance or sustainability (must be adaptation-specific)

**Scoring Guidance**:
- **Score 0**: No tracking of adaptation spend
- **Score 2**: Ad hoc reporting of major adaptation investments without outcomes
- **Score 3**: Systematic tracking of spend for ≥1 major adaptation program
- **Score 4**: Comprehensive tracking of spend and outcomes with ROI analysis
- **Score 5**: Best practice ROI analysis with continuous improvement and investment optimization

**Outcome Metrics**: Days of downtime avoided, value of losses prevented, reduction in insurance premiums, improved reliability.

**Note**: This is the holy grail of adaptation metrics and very rare. Even score 2 is good performance.

---

## PART 3: ASSESSMENT PROCESS & QUALITY ASSURANCE

### 3.1 Step-by-Step Assessment Process

**For Each Company**:

1. **Document Discovery** (30-60 minutes)
   - Search company website for climate, sustainability, TCFD documents
   - Identify and download 5-10 most relevant documents
   - Prioritize: CDP response, TCFD report, sustainability report, annual report

2. **Evidence Extraction** (60-90 minutes)
   - Search documents for physical climate risk keywords
   - Extract relevant passages with context (3-5 sentences)
   - Tag each passage with document, page, section
   - Organize evidence by potential measure relevance

3. **Measure-by-Measure Scoring** (2-4 hours)
   - For each of 44 measures:
     - Review all potentially relevant evidence
     - Apply scoring criteria systematically
     - Document score with verbatim quotes and justification
     - Assess coverage and confidence level
   - Time per measure: 3-5 minutes average
   - Some measures (M08-M13) require more time; others (M21, M33, M34) very quick if no evidence

4. **Quality Assurance** (30-60 minutes)
   - Review all scores for internal consistency
   - Check that high scores (4-5) have strong quantitative evidence
   - Verify all quotes are accurate and properly cited
   - Ensure coverage assessments are reasonable
   - Flag any uncertain scores for review

5. **Report Generation** (30 minutes)
   - Calculate total score and category scores
   - Identify top strengths (highest scores)
   - Identify key gaps (lowest scores)
   - Note confidence levels and data quality issues

**Total Time per Company**: 4-8 hours depending on documentation quality and company size

### 3.2 Common Scoring Pitfalls to Avoid

**Pitfall 1: Inferring Beyond Evidence**
- ❌ "Company likely has BCPs" → Score 2
- ✅ "No evidence of BCPs found" → Score 0

**Pitfall 2: Crediting Mitigation for Adaptation**
- ❌ Company has net zero target → Credit for M04 (adaptation commitments)
- ✅ Company has net zero target → No credit; different from adaptation

**Pitfall 3: Crediting Awareness as Action**
- ❌ "We are aware of flood risks" → Score 2
- ✅ "We are aware of flood risks" → Score 1 (awareness only)

**Pitfall 4: Ignoring Coverage Requirements**
- ❌ "Flood barriers at HQ" → Score 4 (assuming comprehensive)
- ✅ "Flood barriers at HQ" → Score 2 (only 1 of 50 facilities)

**Pitfall 5: Accepting Generic Processes for Climate-Specific Measures**
- ❌ "Enterprise risk management framework" → Score 3 for M03
- ✅ "Enterprise risk management framework" → Score 1 unless physical climate risks explicitly included

**Pitfall 6: Over-Crediting Future Plans**
- ❌ "We plan to assess physical risks in 2025" → Score 2
- ✅ "We plan to assess physical risks in 2025" → Score 0 (no action yet)

**Pitfall 7: Hallucinating Evidence**
- ❌ Rephrasing company statements without quotes
- ✅ Exact quotes with page references, or no credit given

### 3.3 Calibration Guidance

**Score Distribution Expectations**:

Based on assessment of leading companies, expect:
- **Score 0**: 10-20% of measures (many companies haven't acted in these areas)
- **Score 1-2**: 30-40% of measures (most common - awareness or limited action)
- **Score 3**: 20-30% of measures (solid performers)
- **Score 4**: 10-15% of measures (strong performance)
- **Score 5**: 0-5% of measures (best practice, very rare)

**Typical Score Ranges by Company Type**:
- **Leaders** (e.g., utilities, infrastructure, agriculture): 100-140 total (45-64%)
- **Good Performers** (e.g., banks, insurers with physical risk focus): 70-100 total (32-45%)
- **Average** (e.g., most industrial companies): 50-70 total (23-32%)
- **Laggards** (e.g., companies ignoring physical risks): 20-50 total (9-23%)
- **No Action** (e.g., no climate disclosure): 0-20 total (0-9%)

**Category Score Variations**:
- Category 1 (Governance): Often higher scores (easier to demonstrate)
- Category 2 (Risk Assessment): Moderate scores (many companies assess but don't quantify)
- Category 3 (Asset Resilience): Lower scores (requires capital investment)
- Category 4 (Crisis Management): Higher scores (many companies have BCPs/ERPs)
- Category 5 (Supply Chain): Lower scores (hard to assess supply chain)
- Category 6 (Insurance): Lower scores (limited disclosure)
- Category 7 (Data Quality): Low scores (rare)
- Category 8 (Social): Very low scores (rarely considered)
- Category 9 (Performance): Very low scores (metrics rare)

### 3.4 Documentation Template

**Company Assessment Report Template**:

```
COMPANY: [Name]
ASSESSMENT DATE: [Date]
ASSESSOR: [Name]
TOTAL SCORE: X/220 (XX%)

CATEGORY SCORES:
1. Governance & Strategic Oversight: X/35 (XX%)
2. Risk Identification & Assessment: X/45 (XX%)
3. Asset Design & Resilience: X/25 (XX%)
4. Crisis Management: X/25 (XX%)
5. Supply Chain Management: X/25 (XX%)
6. Insurance & Risk Transfer: X/20 (XX%)
7. Data Quality & Assurance: X/10 (XX%)
8. Social & Community Resilience: X/10 (XX%)
9. Performance Metrics & Improvement: X/25 (XX%)

TOP 5 STRENGTHS:
[List measures with scores 4-5]

TOP 5 GAPS:
[List measures with scores 0-1]

KEY DOCUMENTS REVIEWED:
1. [Document name, date]
2. [Document name, date]
...

DETAILED MEASURE SCORES:
[44 measures with evidence, quotes, and justification]

OVERALL ASSESSMENT:
[2-3 paragraph summary of physical climate risk management maturity]

DATA QUALITY NOTES:
[Any issues with evidence quality, documentation gaps, or assessment uncertainty]
```

---

## PART 4: USING THIS FRAMEWORK WITH AI ASSISTANTS

### 4.1 Recommended AI Prompting Approach

**Phase 1: Document Discovery**
```
Please search for and identify all relevant climate disclosure documents for [Company Name], including:
- CDP Climate Change response (most recent)
- TCFD report or TCFD-aligned disclosure
- Sustainability/ESG report (most recent)
- Annual report (10-K or 20-F) with climate risk section
- Any dedicated climate strategy or adaptation documents

Provide URLs and publication dates for all documents found.
```

**Phase 2: Evidence Extraction**
```
Please review [Document Name] and extract all passages that mention physical climate hazards, risks, or adaptation measures. For each passage:
1. Provide the exact quote
2. Note the page number and section heading
3. Tag which of the 44 measures this passage might be relevant for

Focus on finding evidence related to: flood, storm, wildfire, drought, heat, sea level rise, water stress, and other physical climate hazards.
```

**Phase 3: Measure-by-Measure Assessment**
```
Using the Physical Climate Risk Assessment Framework v3.0, please assess [Company Name]'s performance on Measures M01-M07 (Governance & Strategic Oversight).

For each measure:
1. Review all relevant evidence from the documents
2. Provide the exact verbatim quote(s) supporting the assessment
3. Assign a score (0-5) based on the framework's scoring criteria
4. Justify the score with reference to the evidence
5. Estimate the coverage percentage where applicable
6. Note the confidence level (High/Medium/Low)

Be rigorous: only credit what is explicitly stated, do not infer or assume.
```

**Phase 4: Quality Review**
```
Please review the assessments for [Company Name] and check for:
1. Internal consistency (do similar measures have similar scores?)
2. Evidence quality (are high scores supported by strong quantitative evidence?)
3. Proper citations (are all quotes accurate with page references?)
4. Coverage assessments (are percentages reasonable given the evidence?)
5. Any potential scoring errors or inconsistencies

Flag any scores that should be reviewed or adjusted.
```

### 4.2 Handling AI Limitations

**Challenge**: AI may infer beyond evidence
**Solution**: Explicitly instruct "only credit what is explicitly stated, do not infer"

**Challenge**: AI may not find all relevant evidence in long documents
**Solution**: Use keyword-based extraction first, then targeted measure-by-measure review

**Challenge**: AI may struggle with coverage calculations
**Solution**: Ask for explicit basis of coverage estimates and verify reasonableness

**Challenge**: AI may be inconsistent across measures
**Solution**: Batch assess related measures together and use calibration prompts

**Challenge**: AI may hallucinate quotes
**Solution**: Always verify quotes against source documents for high-impact assessments

### 4.3 Batch Assessment Strategy

**For assessing multiple companies efficiently**:

1. **Standardize Document Collection**
   - Create consistent document repository structure
   - Use same search queries for all companies
   - Document any company-specific search issues

2. **Use Consistent Prompts**
   - Template the AI prompts with company name as variable
   - Apply identical assessment criteria for all companies
   - Maintain scoring discipline across all assessments

3. **Calibrate Across Companies**
   - After assessing 3-5 companies, review scores for calibration
   - Ensure similar evidence yields similar scores across companies
   - Adjust any outlier scores with justification

4. **Prioritize Measures for Deep-Dive**
   - Focus manual review on high-variation measures (M12, M18, M21, M42, M44)
   - Spot-check AI assessments on random measures
   - Verify all scores 4-5 with actual document review

---

## PART 5: INTERPRETATION & ANALYSIS

### 5.1 Score Interpretation

**Individual Measure Interpretation**:
- **Score 0**: No action or disclosure on this measure (gap to address)
- **Score 1-2**: Awareness or early-stage action (developing practice)
- **Score 3**: Solid practice with moderate coverage (good performance)
- **Score 4**: Strong practice with high coverage (advanced performance)
- **Score 5**: Best-in-class practice (benchmark for others)

**Category Score Interpretation** (as % of maximum):
- **<30%**: Significant gaps in this area, major improvement needed
- **30-50%**: Developing capabilities, progressing but more work needed
- **50-70%**: Good performance, solid foundation with some gaps
- **70-85%**: Strong performance, advanced capabilities
- **>85%**: Leading performance, best practice

**Total Score Interpretation** (out of 220):
- **<50 (0-23%)**: Limited physical risk management, early stage
- **50-90 (23-41%)**: Developing physical risk management, awareness but limited action
- **90-130 (41-59%)**: Moderate physical risk management, solid foundation
- **130-170 (59-77%)**: Strong physical risk management, advanced capabilities
- **>170 (>77%)**: Leading physical risk management, best-in-class

### 5.2 Benchmarking & Peer Comparison

**For meaningful peer comparisons**:

1. **Adjust for Industry Context**
   - High exposure industries (e.g., agriculture, utilities, real estate) should score higher
   - Low exposure industries (e.g., software, professional services) may have legitimately lower scores
   - Compare companies within similar industries for fairness

2. **Adjust for Company Size**
   - Larger companies typically have more resources for risk management
   - Smaller companies may have lower absolute scores but good performance relative to resources
   - Consider score per $ market cap or per employee for size-adjustment

3. **Adjust for Geographic Exposure**
   - Companies in high-risk geographies (e.g., coastal, water-stressed, wildfire-prone) should score higher
   - Companies in lower-risk geographies may have legitimately lower scores
   - Weight scores by exposure when comparing peers

4. **Trend Analysis Over Time**
   - Year-over-year score changes indicate improving or declining performance
   - Look for expansion of disclosure and action, not just refinement of existing practices
   - Note changes in assessment methodology if comparing across years

### 5.3 Red Flags & Warning Signs

**Indicators of poor physical risk management** (even if overall score isn't lowest):

1. **Zero scores on fundamental measures**: M01 (Board oversight), M03 (ERM integration), M08 (Hazard ID)
2. **High exposure with low adaptation**: Operating in vulnerable areas but no evidence of adaptation measures (M17-M21)
3. **Risk assessment without action**: Reasonable scores on M08-M13 but very low on M17-M26, M32
4. **No financial quantification**: Score 0-1 on M12, M42 suggests limited understanding of financial materiality
5. **No supply chain assessment**: Score 0 on M13, M27-M31 despite global supply chain
6. **Disclosure gaps**: Low scores on M15-M16 suggests lack of transparency (or lack of action to disclose)

### 5.4 Strengths & Best Practices

**Indicators of strong physical risk management**:

1. **Governance integration**: High scores on M01-M03, M05 indicate strategic-level attention
2. **Quantified assessment**: Score 4-5 on M11-M12 shows sophisticated risk analysis
3. **Action orientation**: High scores on M17-M21 show investment in physical adaptation
4. **Supply chain focus**: Score 3+ on M27-M31 demonstrates extended risk management
5. **Metrics & improvement**: Any scores >0 on M41-M44 shows performance tracking and learning
6. **Transparency**: High scores on M15-M16 enable stakeholder engagement and accountability

---

## APPENDIX A: QUICK REFERENCE

### Measure List by Category

**Category 1 - Governance (M01-M07)**: Board oversight, Management responsibility, ERM integration, Public commitments, Scenario analysis, Stakeholder engagement, Policy advocacy

**Category 2 - Risk Assessment (M08-M16)**: Hazard ID, Asset mapping, Vulnerability, Modeling, Financial quantification, Supply chain risk, Third-party validation, Regulatory compliance, Disclosure quality

**Category 3 - Asset Resilience (M17-M21)**: Design standards, Retrofitting, Nature-based solutions, Critical infrastructure, Relocation

**Category 4 - Crisis Management (M22-M26)**: BCPs, Emergency response, Crisis communication, RTOs, Post-event review

**Category 5 - Supply Chain (M27-M31)**: Supplier assessment, Diversification, Contracts, Inventory, Logistics

**Category 6 - Insurance (M32-M35)**: Coverage adequacy, Parametric insurance, Captives, Claims management

**Category 7 - Data Quality (M36-M37)**: Data governance, External assurance

**Category 8 - Social (M38-M39)**: Employee safety, Community engagement

**Category 9 - Performance (M40-M44)**: Just transition, Downtime metrics, Financial impacts, Supplier disruption, Adaptation ROI

### Climate-Specificity by Measure

**High Climate-Specificity** (require explicit physical climate risk evidence):
- M01-M07 (Governance)
- M08-M16 (Risk Assessment)
- M17-M21 (Asset Resilience)
- M36-M37 (Data Quality)
- M40, M42, M44 (some Performance Metrics)

**Hazard-Agnostic** (accept any disruption evidence):
- M22-M26 (Crisis Management)
- M41, M43 (some Performance Metrics)

**Moderate** (climate-preferred but general resilience accepted):
- M27-M31 (Supply Chain)
- M32-M35 (Insurance)
- M38-M39 (Social)

### Keyword Search Terms by Hazard

**Acute Hazards**:
- Flooding: flood, flooding, inundation, deluge, flash flood, riverine flood, coastal flood
- Storms: hurricane, cyclone, typhoon, tropical storm, windstorm, tornado, severe weather
- Wildfires: wildfire, bushfire, forest fire, fire risk, fire season
- Extreme Heat: heatwave, extreme heat, high temperature, heat stress
- Extreme Cold: cold snap, freeze, extreme cold, ice storm
- Drought: drought, water shortage, dry conditions

**Chronic Hazards**:
- Sea Level Rise: sea level rise, coastal erosion, coastal flooding, storm surge
- Temperature: warming, temperature increase, temperature rise, chronic heat
- Precipitation: precipitation change, rainfall pattern, wet-dry cycle, water stress
- Water Availability: water scarcity, water stress, groundwater depletion

**General Terms**:
- Physical risk, physical climate risk, climate hazard, climate impact
- Adaptation, resilience, climate-proofing, hardening
- TCFD, CDP, climate disclosure, climate strategy

---

## APPENDIX B: EXAMPLE ASSESSMENTS

### Example 1: Utility Company (Strong Performance)

**Total Score**: 142/220 (65%)

**Category Breakdown**:
- Governance (M01-M07): 28/35 (80%) - Strong board oversight, scenario analysis
- Risk Assessment (M08-M16): 32/45 (71%) - Comprehensive hazard mapping and quantification
- Asset Resilience (M17-M21): 18/25 (72%) - Significant infrastructure hardening program
- Crisis Management (M22-M26): 22/25 (88%) - Excellent emergency response
- Supply Chain (M27-M31): 14/25 (56%) - Moderate supplier risk management
- Insurance (M32-M35): 11/20 (55%) - Adequate coverage but limited innovation
- Data Quality (M36-M37): 5/10 (50%) - Data governance but no external assurance
- Social (M38-M39): 7/10 (70%) - Strong employee safety, some community engagement
- Performance (M40-M44): 5/25 (20%) - Limited performance tracking

**Key Strengths**: Infrastructure adaptation, emergency preparedness, transparent disclosure

**Key Gaps**: Performance metrics, insurance innovation, supply chain resilience

### Example 2: Technology Company (Weak Performance)

**Total Score**: 35/220 (16%)

**Category Breakdown**:
- Governance (M01-M07): 8/35 (23%) - Generic board oversight, no adaptation strategy
- Risk Assessment (M08-M16): 12/45 (27%) - Basic TCFD disclosure, no quantification
- Asset Resilience (M17-M21): 2/25 (8%) - Minimal physical adaptation
- Crisis Management (M22-M26): 11/25 (44%) - Basic BCPs and IT disaster recovery
- Supply Chain (M27-M31): 2/25 (8%) - No supply chain climate risk assessment
- Insurance (M32-M35): 0/20 (0%) - No climate insurance disclosure
- Data Quality (M36-M37): 0/10 (0%) - No data governance or assurance
- Social (M38-M39): 0/10 (0%) - No climate-specific employee or community programs
- Performance (M40-M44): 0/25 (0%) - No climate performance tracking

**Key Strengths**: Basic crisis management capabilities

**Key Gaps**: Limited physical risk understanding, no adaptation investments, no performance tracking

**Context**: Low physical exposure (data centers in temperate climates) may partly explain low scores, but still significant gaps relative to risk.

---

## APPENDIX C: FRAMEWORK CHANGE LOG

**Version 3.0 (December 2025)**:
- Major enhancement of assessment methodology and scoring guidance
- Added detailed evidence requirements and examples for each measure
- Expanded handling of ambiguous cases and common pitfalls
- Added AI prompting guidance and batch assessment strategy
- Enhanced interpretation and benchmarking guidance
- Improved documentation requirements with templates

**Version 2.0**:
- Expanded from original framework
- Added detailed "What We Look For" and scoring criteria for each measure
- Introduced 0-5 scoring scale (replacing binary or 3-point scales)
- Added category purposes and climate-specificity indicators

**Version 1.0**:
- Initial framework development
- 44 measures across 9 categories defined
- Basic scoring approach established

---

## APPENDIX D: FURTHER RESOURCES

**Climate Risk Assessment Tools**:
- Jupiter Intelligence (climate risk analytics platform)
- Climate X (physical climate risk data)
- Four Twenty Seven (physical climate risk analytics, now part of Moody's)
- XDI (The Cross Dependency Initiative - climate risk assessments)
- WTW Climate Diagnostic (Aon, WTW, Marsh climate risk tools)

**Disclosure Frameworks**:
- TCFD: https://www.fsb-tcfd.org/
- CDP: https://www.cdp.net/
- ESRS E1 (Climate Change): https://www.efrag.org/lab6
- SEC Climate Disclosure Rules: https://www.sec.gov/
- GRI Standards: https://www.globalreporting.org/

**Climate Data Sources**:
- IPCC Reports: https://www.ipcc.ch/
- Copernicus Climate Change Service: https://climate.copernicus.eu/
- NOAA Climate Data: https://www.ncdc.noaa.gov/
- World Bank Climate Change Knowledge Portal: https://climateknowledgeportal.worldbank.org/

**Industry Resources**:
- UNEP FI TCFD for Banks: https://www.unepfi.org/
- ClimateWise Physical Risk Framework: https://www.cisl.cam.ac.uk/
- GFDRR (Global Facility for Disaster Reduction and Recovery): https://www.gfdrr.org/

---

**END OF FRAMEWORK DOCUMENT**

**Document Information**:
- Framework Version: 3.0
- Last Updated: December 2025
- Total Length: ~20,000 words
- Designed for: Systematic AI-driven assessment of corporate physical climate risk management
- Contact: [Your organization contact information]
