import { Express } from "express";
import { db } from "./db";
import { companies, analysisJobs, batchRuns } from "@shared/schema";
import { eq, sql, or, and } from "drizzle-orm";

export function registerHerokuRoutes(app: Express) {
  app.post("/api/heroku/batch/start", async (req, res) => {
    const { parallelWorkers = 3, companyIds } = req.body;

    const existingBatch = await db
      .select()
      .from(batchRuns)
      .where(eq(batchRuns.status, "running"))
      .limit(1);

    if (existingBatch.length > 0) {
      return res.status(409).json({ 
        error: "A batch is already running", 
        batchId: existingBatch[0].id 
      });
    }

    let companiesToProcess;
    if (companyIds && companyIds.length > 0) {
      companiesToProcess = await db
        .select()
        .from(companies)
        .where(
          and(
            sql`${companies.id} = ANY(${companyIds})`,
            or(eq(companies.analysisStatus, "idle"), eq(companies.analysisStatus, "failed"))
          )
        );
    } else {
      companiesToProcess = await db
        .select()
        .from(companies)
        .where(or(eq(companies.analysisStatus, "idle"), eq(companies.analysisStatus, "failed")));
    }

    if (companiesToProcess.length === 0) {
      return res.status(400).json({ error: "No companies available for analysis" });
    }

    const [batch] = await db
      .insert(batchRuns)
      .values({
        status: "running",
        totalJobs: companiesToProcess.length,
        parallelWorkers,
      })
      .returning();

    const jobs = companiesToProcess.map((company, index) => ({
      companyId: company.id,
      companyName: company.name,
      priority: companiesToProcess.length - index,
    }));

    await db.insert(analysisJobs).values(jobs);

    res.json({
      batchId: batch.id,
      totalJobs: companiesToProcess.length,
      parallelWorkers,
      message: "Batch started. Workers will pick up jobs automatically.",
    });
  });

  app.get("/api/heroku/batch/status", async (req, res) => {
    const runningBatch = await db
      .select()
      .from(batchRuns)
      .where(eq(batchRuns.status, "running"))
      .limit(1);

    if (runningBatch.length === 0) {
      const lastBatch = await db
        .select()
        .from(batchRuns)
        .orderBy(sql`${batchRuns.createdAt} DESC`)
        .limit(1);

      if (lastBatch.length === 0) {
        return res.json({ status: "no_batches", message: "No batch runs found" });
      }

      return res.json({
        batchId: lastBatch[0].id,
        status: lastBatch[0].status,
        totalJobs: lastBatch[0].totalJobs,
        completedJobs: lastBatch[0].completedJobs,
        failedJobs: lastBatch[0].failedJobs,
        completedAt: lastBatch[0].completedAt,
      });
    }

    const batch = runningBatch[0];

    const processingJobs = await db
      .select({ 
        count: sql<number>`count(*)`,
        companies: sql<string>`string_agg(${analysisJobs.companyName}, ', ')` 
      })
      .from(analysisJobs)
      .where(eq(analysisJobs.status, "processing"));

    res.json({
      batchId: batch.id,
      status: "running",
      totalJobs: batch.totalJobs,
      completedJobs: batch.completedJobs,
      failedJobs: batch.failedJobs,
      pendingJobs: batch.totalJobs - batch.completedJobs - batch.failedJobs,
      currentlyProcessing: processingJobs[0]?.companies || "None",
      parallelWorkers: batch.parallelWorkers,
      progressPercent: Math.round((batch.completedJobs / batch.totalJobs) * 100),
    });
  });

  app.post("/api/heroku/batch/cancel", async (req, res) => {
    await db
      .update(batchRuns)
      .set({ status: "cancelled", completedAt: new Date() })
      .where(eq(batchRuns.status, "running"));

    await db
      .update(analysisJobs)
      .set({ status: "failed", errorMessage: "Batch cancelled by user" })
      .where(or(eq(analysisJobs.status, "pending"), eq(analysisJobs.status, "processing")));

    res.json({ message: "Batch cancelled" });
  });

  app.post("/api/heroku/batch/retry-failed", async (req, res) => {
    const failedJobs = await db
      .update(analysisJobs)
      .set({ 
        status: "pending", 
        attempts: 0, 
        errorMessage: null, 
        workerId: null,
        updatedAt: new Date() 
      })
      .where(eq(analysisJobs.status, "failed"))
      .returning();

    if (failedJobs.length === 0) {
      return res.json({ message: "No failed jobs to retry" });
    }

    const runningBatch = await db
      .select()
      .from(batchRuns)
      .where(eq(batchRuns.status, "running"))
      .limit(1);

    if (runningBatch.length === 0) {
      await db.insert(batchRuns).values({
        status: "running",
        totalJobs: failedJobs.length,
        parallelWorkers: 3,
      });
    } else {
      await db
        .update(batchRuns)
        .set({ 
          totalJobs: sql`${batchRuns.totalJobs} + ${failedJobs.length}`,
          failedJobs: sql`${batchRuns.failedJobs} - ${failedJobs.length}` 
        })
        .where(eq(batchRuns.id, runningBatch[0].id));
    }

    res.json({ 
      message: `Retrying ${failedJobs.length} failed jobs`,
      jobsRetried: failedJobs.length 
    });
  });

  app.get("/api/heroku/jobs", async (req, res) => {
    const status = req.query.status as string;
    const limit = parseInt(req.query.limit as string) || 50;

    let query = db.select().from(analysisJobs).limit(limit);
    
    if (status) {
      query = query.where(eq(analysisJobs.status, status)) as any;
    }

    const jobs = await query.orderBy(sql`${analysisJobs.createdAt} DESC`);
    res.json(jobs);
  });
}
