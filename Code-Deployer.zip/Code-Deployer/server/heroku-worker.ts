import "dotenv/config";
import { db } from "./db";
import { companies, documents, measureScores, analysisJobs, batchRuns } from "@shared/schema";
import { eq, and, sql, isNull, or } from "drizzle-orm";
import { searchCompanyDocuments } from "./lib/discovery";
import { processDocument } from "./lib/processor";
import { analyzeCompanyMeasures, convertToMeasureScores } from "./lib/analyzer";

const WORKER_ID = `worker-${process.env.DYNO || process.pid}-${Date.now()}`;
const PARALLEL_JOBS = parseInt(process.env.PARALLEL_JOBS || "3", 10);
const POLL_INTERVAL = parseInt(process.env.POLL_INTERVAL || "5000", 10);
const JOB_TIMEOUT = parseInt(process.env.JOB_TIMEOUT || "300000", 10); // 5 minutes

console.log(`[${WORKER_ID}] Starting Heroku worker with ${PARALLEL_JOBS} parallel jobs`);

async function claimJob(): Promise<typeof analysisJobs.$inferSelect | null> {
  const now = new Date();
  const staleThreshold = new Date(now.getTime() - JOB_TIMEOUT);

  // Use a subquery to find ONE eligible job, then update only that row
  // This prevents multiple workers from claiming the same job
  const result = await db.execute(sql`
    UPDATE analysis_jobs 
    SET 
      status = 'processing',
      worker_id = ${WORKER_ID},
      started_at = ${now},
      attempts = attempts + 1,
      updated_at = ${now}
    WHERE id = (
      SELECT id FROM analysis_jobs
      WHERE (
        status = 'pending' 
        OR (status = 'processing' AND started_at < ${staleThreshold})
      )
      AND attempts < max_attempts
      ORDER BY priority DESC, created_at ASC
      LIMIT 1
      FOR UPDATE SKIP LOCKED
    )
    RETURNING *
  `);

  const rows = result.rows as any[];
  if (!rows || rows.length === 0) return null;
  
  // Convert snake_case to camelCase for the returned row
  const row = rows[0];
  return {
    id: row.id,
    companyId: row.company_id,
    companyName: row.company_name,
    status: row.status,
    priority: row.priority,
    workerId: row.worker_id,
    attempts: row.attempts,
    maxAttempts: row.max_attempts,
    errorMessage: row.error_message,
    startedAt: row.started_at,
    completedAt: row.completed_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  } as typeof analysisJobs.$inferSelect;
}

async function processJob(job: typeof analysisJobs.$inferSelect): Promise<void> {
  const startTime = Date.now();
  console.log(`[${WORKER_ID}] Processing job ${job.id}: ${job.companyName}`);

  try {
    await db
      .update(companies)
      .set({ analysisStatus: "searching" })
      .where(eq(companies.id, job.companyId));

    const docs = await searchCompanyDocuments(job.companyName);
    console.log(`[${WORKER_ID}] Found ${docs.length} documents for ${job.companyName}`);

    await db
      .update(companies)
      .set({ analysisStatus: "analyzing" })
      .where(eq(companies.id, job.companyId));

    const docTexts: string[] = [];
    for (const doc of docs.slice(0, 8)) {
      try {
        const text = await processDocument(doc.url, doc.type as "pdf" | "html");
        if (text && text.length > 100) {
          await db.insert(documents).values({
            companyId: job.companyId,
            url: doc.url,
            title: doc.title,
            type: doc.type,
            publicationYear: new Date().getFullYear(),
          });
          docTexts.push(text);
        }
      } catch (docError) {
        console.log(`[${WORKER_ID}] Skipping failed document: ${doc.url}`);
      }
    }

    if (docTexts.length === 0) {
      throw new Error("No documents could be processed");
    }

    const analysis = await analyzeCompanyMeasures(job.companyName, docTexts);

    if (!analysis || analysis.totalScore === 0) {
      throw new Error("Analysis returned no results");
    }

    await db.delete(measureScores).where(eq(measureScores.companyId, job.companyId));
    const scores = convertToMeasureScores(job.companyId, analysis);
    if (scores.length > 0) {
      await db.insert(measureScores).values(scores as any);
    }

    await db
      .update(companies)
      .set({
        totalScore: analysis.scorePercentage,
        summary: analysis.summary,
        analysisStatus: "completed",
      })
      .where(eq(companies.id, job.companyId));

    await db
      .update(analysisJobs)
      .set({
        status: "completed",
        completedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(analysisJobs.id, job.id));

    await db
      .update(batchRuns)
      .set({ completedJobs: sql`${batchRuns.completedJobs} + 1` })
      .where(eq(batchRuns.status, "running"));

    const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`[${WORKER_ID}] Completed job ${job.id}: ${job.companyName} (${analysis.scorePercentage}%) in ${elapsed}s`);

  } catch (error: any) {
    console.error(`[${WORKER_ID}] Job ${job.id} failed:`, error?.message || error);

    const job_data = await db.select().from(analysisJobs).where(eq(analysisJobs.id, job.id));
    const currentJob = job_data[0];
    const isFinalAttempt = currentJob && currentJob.attempts >= currentJob.maxAttempts;

    await db
      .update(analysisJobs)
      .set({
        status: isFinalAttempt ? "failed" : "pending",
        errorMessage: error?.message || "Unknown error",
        workerId: null,
        updatedAt: new Date(),
      })
      .where(eq(analysisJobs.id, job.id));

    if (isFinalAttempt) {
      await db
        .update(companies)
        .set({
          analysisStatus: "failed",
          summary: `Error: ${error?.message || "Unknown error"}`,
        })
        .where(eq(companies.id, job.companyId));

      await db
        .update(batchRuns)
        .set({ failedJobs: sql`${batchRuns.failedJobs} + 1` })
        .where(eq(batchRuns.status, "running"));
    } else {
      // Reset company status to idle for retry
      await db
        .update(companies)
        .set({ analysisStatus: "idle" })
        .where(eq(companies.id, job.companyId));
    }
  }
}

async function runWorkerLoop(): Promise<void> {
  const activeJobs: Promise<void>[] = [];

  while (true) {
    const runningCount = activeJobs.filter(p => p).length;

    if (runningCount < PARALLEL_JOBS) {
      const job = await claimJob();
      if (job) {
        const jobPromise = processJob(job).finally(() => {
          const index = activeJobs.indexOf(jobPromise);
          if (index > -1) activeJobs.splice(index, 1);
        });
        activeJobs.push(jobPromise);
      }
    }

    const activeBatch = await db
      .select()
      .from(batchRuns)
      .where(eq(batchRuns.status, "running"))
      .limit(1);

    if (activeBatch.length > 0) {
      const batch = activeBatch[0];
      const pendingJobs = await db
        .select({ count: sql<number>`count(*)` })
        .from(analysisJobs)
        .where(or(eq(analysisJobs.status, "pending"), eq(analysisJobs.status, "processing")));

      if (pendingJobs[0].count === 0 && activeJobs.length === 0) {
        await db
          .update(batchRuns)
          .set({ status: "completed", completedAt: new Date() })
          .where(eq(batchRuns.id, batch.id));
        console.log(`[${WORKER_ID}] Batch ${batch.id} completed`);
      }
    }

    await new Promise((r) => setTimeout(r, POLL_INTERVAL));
  }
}

runWorkerLoop().catch((error) => {
  console.error(`[${WORKER_ID}] Worker crashed:`, error);
  process.exit(1);
});
