import { db } from "./db";
import {
  companies, documents, analysisResults, measureScores,
  type Company, type InsertCompany,
  type Document, type InsertDocument,
  type AnalysisResult,
  type MeasureScore, type InsertMeasureScore
} from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  // Companies
  getCompanies(): Promise<Company[]>;
  getCompany(id: number): Promise<Company | undefined>;
  getCompanyByName(name: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompany(id: number, updates: Partial<InsertCompany>): Promise<Company>;
  
  // Documents
  getDocuments(companyId: number): Promise<Document[]>;
  createDocument(doc: InsertDocument): Promise<Document>;
  
  // Analysis Results
  getAnalysisResults(companyId: number): Promise<AnalysisResult[]>;
  createAnalysisResult(result: Partial<AnalysisResult> & { companyId: number }): Promise<AnalysisResult>;
  clearAnalysisResults(companyId: number): Promise<void>;
  
  // Measure Scores
  getMeasureScores(companyId: number): Promise<MeasureScore[]>;
  createMeasureScore(score: InsertMeasureScore): Promise<MeasureScore>;
  createMeasureScores(scores: InsertMeasureScore[]): Promise<MeasureScore[]>;
  clearMeasureScores(companyId: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getCompanies(): Promise<Company[]> {
    return await db.select().from(companies).orderBy(desc(companies.updatedAt));
  }

  async getCompany(id: number): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.id, id));
    return company;
  }

  async getCompanyByName(name: string): Promise<Company | undefined> {
    const [company] = await db.select().from(companies).where(eq(companies.name, name));
    return company;
  }

  async createCompany(company: InsertCompany): Promise<Company> {
    const [newCompany] = await db.insert(companies).values(company).returning();
    return newCompany;
  }

  async updateCompany(id: number, updates: Partial<InsertCompany>): Promise<Company> {
    const [updated] = await db.update(companies)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(companies.id, id))
      .returning();
    return updated;
  }

  async getDocuments(companyId: number): Promise<Document[]> {
    return await db.select().from(documents)
      .where(eq(documents.companyId, companyId))
      .orderBy(desc(documents.publicationYear));
  }

  async createDocument(doc: InsertDocument): Promise<Document> {
    const [newDoc] = await db.insert(documents).values(doc).returning();
    return newDoc;
  }

  async getAnalysisResults(companyId: number): Promise<AnalysisResult[]> {
    return await db.select().from(analysisResults)
      .where(eq(analysisResults.companyId, companyId));
  }

  async createAnalysisResult(result: Partial<AnalysisResult> & { companyId: number }): Promise<AnalysisResult> {
    const [newResult] = await db.insert(analysisResults).values(result as any).returning();
    return newResult;
  }

  async clearAnalysisResults(companyId: number): Promise<void> {
    await db.delete(analysisResults).where(eq(analysisResults.companyId, companyId));
  }

  async getMeasureScores(companyId: number): Promise<MeasureScore[]> {
    return await db.select().from(measureScores)
      .where(eq(measureScores.companyId, companyId))
      .orderBy(measureScores.measureId);
  }

  async createMeasureScore(score: InsertMeasureScore): Promise<MeasureScore> {
    const [newScore] = await db.insert(measureScores).values(score).returning();
    return newScore;
  }

  async createMeasureScores(scores: InsertMeasureScore[]): Promise<MeasureScore[]> {
    if (scores.length === 0) return [];
    const results = await db.insert(measureScores).values(scores).returning();
    return results;
  }

  async clearMeasureScores(companyId: number): Promise<void> {
    await db.delete(measureScores).where(eq(measureScores.companyId, companyId));
  }
}

export const storage = new DatabaseStorage();
