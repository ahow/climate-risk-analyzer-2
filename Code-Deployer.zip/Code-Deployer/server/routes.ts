import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { fetchCompanyList } from "./lib/importer";
import { searchCompanyDocuments } from "./lib/discovery";
import { processDocument } from "./lib/processor";
import { analyzeCompanyMeasures, convertToMeasureScores } from "./lib/analyzer";
import * as XLSX from "xlsx";
import { MEASURES } from "@shared/measures";

let batchState = {
  isRunning: false,
  currentCompany: '',
  completed: 0,
  total: 0,
  failed: 0,
  retryRound: 0,
};

// Track retry attempts per company (persists across batch runs)
const companyRetryAttempts: Map<number, number> = new Map();
const MAX_RETRY_ATTEMPTS = 3;

// Reusable batch processing function with auto-retry for failed companies
async function runBatch(toAnalyze: any[]) {
  for (const company of toAnalyze) {
    const attempts = companyRetryAttempts.get(company.id) || 0;
    
    try {
      batchState.currentCompany = company.name;
      const attemptInfo = attempts > 0 ? ` (attempt ${attempts + 1}/${MAX_RETRY_ATTEMPTS})` : '';
      console.log(`\n=== Batch: Processing ${company.name}${attemptInfo} (${batchState.completed + 1}/${batchState.total}) ===`);
      
      await storage.updateCompany(company.id, { analysisStatus: 'searching' });
      const docs = await searchCompanyDocuments(company.name);
      
      await storage.updateCompany(company.id, { analysisStatus: 'analyzing' });
      const docTexts: string[] = [];
      
      // Process fewer docs (8 instead of 15) for faster processing
      for (const doc of docs.slice(0, 8)) {
        try {
          const text = await processDocument(doc.url, doc.type as 'pdf'|'html');
          if (text && text.length > 100) {
            await storage.createDocument({
              companyId: company.id,
              url: doc.url,
              title: doc.title,
              type: doc.type,
              publicationYear: new Date().getFullYear(),
            });
            docTexts.push(text);
          }
        } catch (docError) {
          console.log(`  Skipping failed document: ${doc.url}`);
        }
      }

      if (docTexts.length > 0) {
        const analysis = await analyzeCompanyMeasures(company.name, docTexts);
        
        if (analysis && analysis.totalScore > 0) {
          await storage.clearMeasureScores(company.id);
          const measureScores = convertToMeasureScores(company.id, analysis);
          await storage.createMeasureScores(measureScores);
          
          await storage.updateCompany(company.id, {
            totalScore: analysis.scorePercentage,
            summary: analysis.summary,
            analysisStatus: 'completed'
          });
          batchState.completed++;
          companyRetryAttempts.delete(company.id); // Clear retry count on success
          console.log(`  Completed: ${company.name} - Score: ${analysis.scorePercentage}%`);
        } else {
          companyRetryAttempts.set(company.id, attempts + 1);
          await storage.updateCompany(company.id, { 
            analysisStatus: 'failed', 
            summary: 'Analysis returned no results.' 
          });
          batchState.failed++;
        }
      } else {
        companyRetryAttempts.set(company.id, attempts + 1);
        await storage.updateCompany(company.id, { 
          analysisStatus: 'failed', 
          summary: 'No documents could be processed.' 
        });
        batchState.failed++;
      }
      
      // Shorter delay between companies (2 seconds instead of 5)
      await new Promise(r => setTimeout(r, 2000));
    } catch (error: any) {
      console.error(`Batch failed for ${company.name}:`, error?.message || error);
      companyRetryAttempts.set(company.id, attempts + 1);
      await storage.updateCompany(company.id, { 
        analysisStatus: 'failed',
        summary: `Error: ${error?.message || 'Unknown error'}`
      });
      batchState.failed++;
    }
  }
  
  console.log(`\n=== Batch Round Complete: ${batchState.completed} succeeded, ${batchState.failed} failed ===`);
  
  // Auto-retry failed companies that haven't exceeded max attempts
  const allCompanies = await storage.getCompanies();
  const failedToRetry = allCompanies.filter(c => {
    if (c.analysisStatus !== 'failed') return false;
    const attempts = companyRetryAttempts.get(c.id) || 0;
    return attempts < MAX_RETRY_ATTEMPTS;
  });
  
  if (failedToRetry.length > 0) {
    batchState.retryRound++;
    console.log(`\n=== Auto-Retry Round ${batchState.retryRound}: Retrying ${failedToRetry.length} failed companies ===`);
    
    // Reset failed companies to idle for retry
    for (const c of failedToRetry) {
      await storage.updateCompany(c.id, { analysisStatus: 'idle' });
    }
    
    // Update batch state for retry round
    batchState.total = failedToRetry.length;
    batchState.completed = 0;
    batchState.failed = 0;
    
    // Wait a bit before retrying (allows API rate limits to reset)
    await new Promise(r => setTimeout(r, 5000));
    
    // Recursively run batch on failed companies
    await runBatch(failedToRetry);
  } else {
    // All done - report final stats
    const finalCompanies = await storage.getCompanies();
    const totalCompleted = finalCompanies.filter(c => c.analysisStatus === 'completed').length;
    const totalFailed = finalCompanies.filter(c => c.analysisStatus === 'failed').length;
    const permanentlyFailed = Array.from(companyRetryAttempts.entries()).filter(([_, attempts]) => attempts >= MAX_RETRY_ATTEMPTS);
    
    console.log(`\n=== BATCH FINISHED ===`);
    console.log(`  Total Completed: ${totalCompleted}`);
    console.log(`  Total Failed (after ${MAX_RETRY_ATTEMPTS} attempts): ${totalFailed}`);
    if (permanentlyFailed.length > 0) {
      console.log(`  Companies that failed all retries: ${permanentlyFailed.length}`);
    }
    
    batchState.isRunning = false;
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // Companies List
  app.get(api.companies.list.path, async (req, res) => {
    const companies = await storage.getCompanies();
    res.json(companies);
  });

  // Company Details
  app.get(api.companies.get.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const company = await storage.getCompany(id);
    if (!company) return res.status(404).json({ message: "Company not found" });
    
    const docs = await storage.getDocuments(id);
    const results = await storage.getAnalysisResults(id);
    const measureScores = await storage.getMeasureScores(id);
    
    res.json({ ...company, documents: docs, analysisResults: results, measureScores });
  });

  // Import Companies
  app.post(api.companies.import.path, async (req, res) => {
    try {
      const { url } = api.companies.import.input.parse(req.body);
      
      // Async import to avoid timeout? For now sync is fine if file isn't huge.
      // But let's assume it's fast enough.
      const data = await fetchCompanyList(url);
      
      let count = 0;
      for (const row of data) {
        // Case-insensitive column lookup helper
        const getColumn = (keys: string[]) => {
          for (const key of Object.keys(row)) {
            const lowerKey = key.toLowerCase();
            if (keys.some(k => lowerKey.includes(k.toLowerCase()))) {
              return row[key];
            }
          }
          return undefined;
        };
        
        // Flexible column matching for various Excel formats
        const name = getColumn(['name', 'company']);
        if (name) {
          await storage.createCompany({
            name,
            isin: getColumn(['isin', 'type', 'identifier']),
            sector: getColumn(['sector', 'level2']),
            industry: getColumn(['industry', 'level4', 'level5']),
            country: getColumn(['country', 'geographic', 'region']),
            analysisStatus: 'idle'
          });
          count++;
        }
      }
      
      res.json({ message: "Import successful", count });
    } catch (error) {
      console.error("Import failed:", error);
      res.status(400).json({ message: "Import failed" });
    }
  });

  // Trigger Analysis
  app.post(api.companies.analyze.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const company = await storage.getCompany(id);
    if (!company) return res.status(404).json({ message: "Company not found" });

    // Start background analysis
    (async () => {
      try {
        await storage.updateCompany(id, { analysisStatus: 'searching' });
        
        // 1. Discovery
        const docs = await searchCompanyDocuments(company.name);
        
        // 2. Download & Process
        await storage.updateCompany(id, { analysisStatus: 'analyzing' });
        const docTexts: string[] = [];
        
        for (const doc of docs) {
           const savedDoc = await storage.createDocument({
             companyId: id,
             url: doc.url,
             title: doc.title,
             type: doc.type,
             publicationYear: new Date().getFullYear(), // Approximate
           });
           
           const text = await processDocument(doc.url, doc.type as 'pdf'|'html');
           if (text) {
             // Save content to DB? Schema has 'content'.
             // Update doc with content? We created it above. 
             // Ideally we create it after fetching.
             // But let's just use the text for analysis.
             docTexts.push(text);
           }
        }

        // 3. Analysis using 44-measure framework
        if (docTexts.length > 0) {
          const analysis = await analyzeCompanyMeasures(company.name, docTexts);
          
          // Clear old scores and save new ones
          await storage.clearMeasureScores(id);
          const measureScores = convertToMeasureScores(id, analysis);
          await storage.createMeasureScores(measureScores);
          
          await storage.updateCompany(id, {
            totalScore: analysis.scorePercentage,
            summary: analysis.summary,
            analysisStatus: 'completed'
          });
        } else {
          await storage.updateCompany(id, { 
            analysisStatus: 'failed', 
            summary: 'No documents found or processed.' 
          });
        }

      } catch (error) {
        console.error(`Analysis failed for company ${id}:`, error);
        await storage.updateCompany(id, { analysisStatus: 'failed' });
      }
    })();

    res.status(202).json({ message: "Analysis started" });
  });

  // Document List (redundant with detail view but good for separate fetches)
  app.get(api.documents.list.path, async (req, res) => {
    const id = parseInt(req.params.id);
    const docs = await storage.getDocuments(id);
    res.json(docs);
  });

  // Batch Analysis - Process all or selected companies
  app.post(api.batch.analyze.path, async (req, res) => {
    if (batchState.isRunning) {
      return res.status(409).json({ message: "Batch already running", totalCompanies: batchState.total });
    }

    const companies = await storage.getCompanies();
    const toAnalyze = companies.filter(c => c.analysisStatus !== 'completed');
    
    batchState = {
      isRunning: true,
      currentCompany: '',
      completed: 0,
      total: toAnalyze.length,
      failed: 0,
      retryRound: 0,
    };

    // Clear retry attempts for fresh batch
    companyRetryAttempts.clear();

    // Start batch in background using the reusable function
    runBatch(toAnalyze);

    res.status(202).json({ message: "Batch analysis started", totalCompanies: toAnalyze.length });
  });

  // Batch Status - calculate from database for accurate counts after restarts
  app.get(api.batch.status.path, async (req, res) => {
    const companies = await storage.getCompanies();
    const completed = companies.filter(c => c.analysisStatus === 'completed').length;
    const failed = companies.filter(c => c.analysisStatus === 'failed').length;
    const inProgress = companies.filter(c => c.analysisStatus === 'searching' || c.analysisStatus === 'analyzing');
    
    res.json({
      isRunning: batchState.isRunning,
      currentCompany: batchState.currentCompany || (inProgress[0]?.name || ''),
      completed,
      total: companies.length,
      failed,
    });
  });

  // Auto-resume batch on server start if there are incomplete companies
  setTimeout(async () => {
    if (batchState.isRunning) return;
    
    const companies = await storage.getCompanies();
    const incomplete = companies.filter(c => 
      c.analysisStatus !== 'completed' && c.analysisStatus !== 'failed'
    );
    
    if (incomplete.length > 0) {
      console.log(`\n=== Auto-resuming batch: ${incomplete.length} companies pending ===`);
      
      // Reset any stuck "analyzing" or "searching" status to idle for retry
      for (const c of incomplete) {
        if (c.analysisStatus === 'analyzing' || c.analysisStatus === 'searching') {
          await storage.updateCompany(c.id, { analysisStatus: 'idle' });
        }
      }
      
      // Trigger batch via internal call
      const allCompanies = await storage.getCompanies();
      const toAnalyze = allCompanies.filter(c => c.analysisStatus === 'idle');
      
      if (toAnalyze.length > 0) {
        batchState = {
          isRunning: true,
          currentCompany: '',
          completed: 0,
          total: toAnalyze.length,
          failed: 0,
          retryRound: 0,
        };
        
        runBatch(toAnalyze);
      }
    }
  }, 5000);

  // Export Spreadsheet with detailed measure scores
  app.get(api.export.spreadsheet.path, async (req, res) => {
    try {
      const companies = await storage.getCompanies();
      const completedCompanies = companies.filter(c => c.analysisStatus === 'completed');
      
      const rows: any[] = [];
      const measureIds = MEASURES.map(m => m.id);
      
      for (const company of completedCompanies) {
        const scores = await storage.getMeasureScores(company.id);
        const docs = await storage.getDocuments(company.id);
        const docSources = docs.map(d => d.title || d.url).slice(0, 5).join('; ');
        
        const row: any = {
          'Company': company.name,
          'Sector': company.sector || '',
          'Country': company.country || '',
          'Total Score (%)': company.totalScore,
          'Total Points': scores.reduce((sum, s) => sum + s.score, 0),
          'Max Points': 220,
          'Documents Analyzed': docs.length,
          'Sources': docSources,
        };
        
        for (const measureId of measureIds) {
          const score = scores.find(s => s.measureId === measureId);
          row[`${measureId}_Score`] = score?.score ?? 0;
          row[`${measureId}_Evidence`] = score?.evidenceSummary ?? 'No evidence found';
          row[`${measureId}_Confidence`] = score?.confidence ?? 'N/A';
          const quotes = score?.quotes as Array<{text: string, source: string}> | null;
          row[`${measureId}_Source`] = quotes?.map(q => q.source).join('; ') ?? '';
        }
        
        rows.push(row);
      }
      
      const wb = XLSX.utils.book_new();
      
      const summaryData = rows.map(r => ({
        Company: r['Company'],
        Sector: r['Sector'],
        Country: r['Country'],
        'Total Score (%)': r['Total Score (%)'],
        'Total Points': r['Total Points'],
        'Documents': r['Documents Analyzed'],
        'Sources': r['Sources'],
      }));
      const summaryWs = XLSX.utils.json_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(wb, summaryWs, 'Summary');
      
      const detailRows = rows.map(r => {
        const detail: any = { Company: r['Company'] };
        for (const m of MEASURES) {
          detail[`${m.id} (${m.title.slice(0, 30)})`] = r[`${m.id}_Score`];
        }
        return detail;
      });
      const scoresWs = XLSX.utils.json_to_sheet(detailRows);
      XLSX.utils.book_append_sheet(wb, scoresWs, 'Scores by Measure');
      
      for (const company of completedCompanies.slice(0, 50)) {
        const companyRow = rows.find(r => r['Company'] === company.name);
        if (!companyRow) continue;
        
        const evidenceRows = MEASURES.map(m => ({
          'Measure ID': m.id,
          'Measure': m.title,
          'Category': m.category,
          'Score': companyRow[`${m.id}_Score`],
          'Confidence': companyRow[`${m.id}_Confidence`],
          'Evidence': companyRow[`${m.id}_Evidence`],
          'Source': companyRow[`${m.id}_Source`],
        }));
        const companyWs = XLSX.utils.json_to_sheet(evidenceRows);
        const sheetName = company.name.slice(0, 28).replace(/[\\\/\?\*\[\]]/g, '');
        XLSX.utils.book_append_sheet(wb, companyWs, sheetName);
      }
      
      const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
      
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=climate_risk_analysis.xlsx');
      res.send(buffer);
    } catch (error) {
      console.error("Export failed:", error);
      res.status(500).json({ message: "Export failed" });
    }
  });

  return httpServer;
}
