import axios, { AxiosError, AxiosResponse } from 'axios';
import * as cheerio from 'cheerio';
import { PDFParse } from 'pdf-parse';

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
];

const MAX_RETRIES = 3;
const RETRY_DELAYS = [1000, 2000, 4000];
const MAX_CONTENT_SIZE = 100000;

function getRandomUserAgent(): string {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function getBrowserHeaders(referer?: string): Record<string, string> {
  const headers: Record<string, string> = {
    'User-Agent': getRandomUserAgent(),
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/pdf',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept-Encoding': 'gzip, deflate, br',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Sec-Fetch-Dest': 'document',
    'Sec-Fetch-Mode': 'navigate',
    'Sec-Fetch-Site': 'none',
    'Sec-Fetch-User': '?1',
    'Cache-Control': 'max-age=0',
  };
  
  if (referer) {
    headers['Referer'] = referer;
  }
  
  return headers;
}

async function fetchWithRetry(
  url: string,
  responseType: 'arraybuffer' | 'text',
  attempt: number = 0,
  referer?: string
): Promise<AxiosResponse | null> {
  try {
    const headers = getBrowserHeaders(referer);
    
    if (attempt > 0) {
      headers['User-Agent'] = USER_AGENTS[attempt % USER_AGENTS.length];
    }
    
    const response = await axios.get(url, {
      responseType,
      timeout: 30000,
      headers,
      maxRedirects: 10,
      validateStatus: (status) => status < 400,
      maxContentLength: 50 * 1024 * 1024,
      decompress: true,
    });
    
    return response;
  } catch (error) {
    const axiosError = error as AxiosError;
    const status = axiosError.response?.status;
    
    if (status === 403 || status === 429 || status === 503) {
      if (attempt < MAX_RETRIES - 1) {
        console.log(`  Retry ${attempt + 1} for ${url} after ${status} error`);
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt]));
        return fetchWithRetry(url, responseType, attempt + 1, referer);
      }
    }
    
    if (axiosError.code === 'ECONNRESET' || axiosError.code === 'ETIMEDOUT') {
      if (attempt < MAX_RETRIES - 1) {
        console.log(`  Retry ${attempt + 1} for ${url} after timeout`);
        await new Promise(r => setTimeout(r, RETRY_DELAYS[attempt]));
        return fetchWithRetry(url, responseType, attempt + 1, referer);
      }
    }
    
    console.log(`  Fetch failed for ${url}: ${axiosError.message}`);
    return null;
  }
}

function detectContentType(response: AxiosResponse): 'pdf' | 'html' | 'unknown' {
  const contentType = response.headers['content-type']?.toLowerCase() || '';
  
  if (contentType.includes('application/pdf')) {
    return 'pdf';
  }
  if (contentType.includes('text/html') || contentType.includes('application/xhtml')) {
    return 'html';
  }
  
  const url = response.request?.res?.responseUrl || response.config.url || '';
  if (url.toLowerCase().includes('.pdf')) {
    return 'pdf';
  }
  
  if (response.data instanceof Buffer || response.data instanceof ArrayBuffer) {
    const bytes = new Uint8Array(response.data instanceof Buffer ? response.data : response.data);
    if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) {
      return 'pdf';
    }
  }
  
  return 'unknown';
}

async function extractPdfText(data: Buffer | ArrayBuffer): Promise<string> {
  try {
    const buffer = Buffer.from(data instanceof ArrayBuffer ? data : data);
    const parser = new PDFParse({ data: buffer });
    const parsed = await parser.getText();
    
    let text = parsed.text || '';
    
    text = text
      .replace(/\s+/g, ' ')
      .replace(/([.!?])\s+/g, '$1\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
    
    return text.slice(0, MAX_CONTENT_SIZE);
  } catch (error: any) {
    console.log(`  PDF parsing error: ${error.message}`);
    return '';
  }
}

function extractHtmlText(html: string, url: string): string {
  try {
    const $ = cheerio.load(html);
    
    $('script, style, noscript, iframe, nav, footer, header, aside, .cookie-banner, .advertisement, .sidebar, #sidebar, .nav, #nav, .footer, #footer, .header, #header, .menu, #menu').remove();
    
    let mainContent = '';
    
    const mainSelectors = [
      'main',
      'article',
      '[role="main"]',
      '.main-content',
      '#main-content',
      '.content',
      '#content',
      '.article-body',
      '.post-content',
      '.entry-content',
      '.report-content',
      '.sustainability-content',
    ];
    
    for (const selector of mainSelectors) {
      const element = $(selector);
      if (element.length > 0) {
        mainContent = element.text();
        break;
      }
    }
    
    if (!mainContent || mainContent.length < 500) {
      mainContent = $('body').text();
    }
    
    mainContent = mainContent
      .replace(/\s+/g, ' ')
      .replace(/\t/g, ' ')
      .trim();
    
    const metaDescription = $('meta[name="description"]').attr('content') || '';
    const title = $('title').text().trim();
    
    let fullText = '';
    if (title) fullText += `Title: ${title}\n\n`;
    if (metaDescription) fullText += `Description: ${metaDescription}\n\n`;
    fullText += mainContent;
    
    return fullText.slice(0, MAX_CONTENT_SIZE);
  } catch (error: any) {
    console.log(`  HTML parsing error: ${error.message}`);
    return '';
  }
}

async function tryAlternativeDownload(url: string): Promise<string> {
  try {
    const urlObj = new URL(url);
    const domain = urlObj.hostname;
    
    const response = await fetchWithRetry(url, 'arraybuffer', 0, `https://${domain}/`);
    if (response) {
      const contentType = detectContentType(response);
      if (contentType === 'pdf') {
        return await extractPdfText(response.data);
      } else if (contentType === 'html') {
        const htmlText = Buffer.from(response.data).toString('utf-8');
        return extractHtmlText(htmlText, url);
      }
    }
  } catch (error) {
  }
  
  return '';
}

export async function processDocument(url: string, type: 'pdf' | 'html'): Promise<string> {
  console.log(`Processing document: ${url} (type: ${type})`);
  
  const responseType = type === 'pdf' ? 'arraybuffer' : 'text';
  let response = await fetchWithRetry(url, responseType as 'arraybuffer' | 'text');
  
  if (!response) {
    console.log(`  Primary fetch failed, trying alternative methods...`);
    const altContent = await tryAlternativeDownload(url);
    if (altContent) {
      console.log(`  Alternative download successful: ${altContent.length} chars`);
      return altContent;
    }
    return '';
  }
  
  const detectedType = detectContentType(response);
  console.log(`  Detected content type: ${detectedType}`);
  
  let content = '';
  
  if (detectedType === 'pdf' || type === 'pdf') {
    if (response.data instanceof Buffer || response.data instanceof ArrayBuffer) {
      content = await extractPdfText(response.data);
    } else {
      const textResponse = await fetchWithRetry(url, 'arraybuffer');
      if (textResponse) {
        content = await extractPdfText(textResponse.data);
      }
    }
  } else {
    const htmlContent = typeof response.data === 'string' 
      ? response.data 
      : Buffer.from(response.data).toString('utf-8');
    content = extractHtmlText(htmlContent, url);
  }
  
  console.log(`  Extracted ${content.length} characters`);
  return content;
}

export async function processMultipleDocuments(
  documents: Array<{ url: string; type: 'pdf' | 'html' }>
): Promise<Map<string, string>> {
  const results = new Map<string, string>();
  
  const concurrencyLimit = 3;
  const chunks: Array<Array<{ url: string; type: 'pdf' | 'html' }>> = [];
  
  for (let i = 0; i < documents.length; i += concurrencyLimit) {
    chunks.push(documents.slice(i, i + concurrencyLimit));
  }
  
  for (const chunk of chunks) {
    const promises = chunk.map(async (doc) => {
      const content = await processDocument(doc.url, doc.type);
      return { url: doc.url, content };
    });
    
    const chunkResults = await Promise.allSettled(promises);
    
    for (const result of chunkResults) {
      if (result.status === 'fulfilled') {
        results.set(result.value.url, result.value.content);
      }
    }
    
    await new Promise(r => setTimeout(r, 500));
  }
  
  return results;
}

export function combineDocumentContent(contents: Map<string, string>): string {
  const allContent: string[] = [];
  
  contents.forEach((content, url) => {
    if (content && content.length > 100) {
      allContent.push(`\n--- Document: ${url} ---\n${content}\n`);
    }
  });
  
  const combined = allContent.join('\n');
  
  if (combined.length > MAX_CONTENT_SIZE * 2) {
    return combined.slice(0, MAX_CONTENT_SIZE * 2);
  }
  
  return combined;
}
