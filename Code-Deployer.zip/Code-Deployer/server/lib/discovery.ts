import axios from 'axios';
import * as cheerio from 'cheerio';

const GOOGLE_API_KEY = process.env.GOOGLE_SEARCH_API_KEY;
const SEARCH_ENGINE_ID = process.env.GOOGLE_SEARCH_ENGINE_ID;

interface DiscoveredDocument {
  title: string;
  url: string;
  snippet?: string;
  type: 'pdf' | 'html';
  source: string;
  priority: number;
}

const SEARCH_QUERY_TEMPLATES = [
  // Core sustainability/climate reports
  { query: '"{company}" sustainability report filetype:pdf', priority: 1 },
  { query: '"{company}" annual report climate risk filetype:pdf', priority: 1 },
  { query: '"{company}" ESG report {year} filetype:pdf', priority: 2 },
  
  // TCFD-specific (physical risk disclosure standard)
  { query: '"{company}" TCFD report physical risk filetype:pdf', priority: 1 },
  { query: '"{company}" TCFD disclosure filetype:pdf', priority: 2 },
  { query: '"{company}" task force climate-related financial disclosures filetype:pdf', priority: 2 },
  
  // CDP responses (major physical risk data source)
  { query: '"{company}" CDP climate change response filetype:pdf', priority: 1 },
  { query: '"{company}" CDP water security filetype:pdf', priority: 2 },
  { query: 'site:cdp.net "{company}" climate', priority: 2 },
  
  // Physical risk specific
  { query: '"{company}" physical climate risk assessment filetype:pdf', priority: 1 },
  { query: '"{company}" climate scenario analysis filetype:pdf', priority: 1 },
  { query: '"{company}" climate adaptation plan filetype:pdf', priority: 1 },
  { query: '"{company}" climate resilience strategy filetype:pdf', priority: 2 },
  { query: '"{company}" extreme weather risk assessment', priority: 2 },
  { query: '"{company}" flood risk hurricane drought assessment', priority: 3 },
  
  // Asset/operational resilience
  { query: '"{company}" asset resilience climate impact filetype:pdf', priority: 2 },
  { query: '"{company}" business continuity climate disaster filetype:pdf', priority: 3 },
  { query: '"{company}" supply chain climate risk filetype:pdf', priority: 2 },
  
  // Regulatory filings
  { query: 'site:sec.gov "{company}" 10-K climate physical risk', priority: 2 },
  { query: '"{company}" climate action plan filetype:pdf', priority: 3 },
  { query: '"{company}" environmental report filetype:pdf', priority: 3 },
  { query: '"{company}" investor relations sustainability', priority: 4 },
];

const KNOWN_REPORT_PATTERNS: Record<string, string[]> = {
  'shell': [
    'https://reports.shell.com/sustainability-report/2023/',
    'https://www.shell.com/sustainability/our-approach/managing-climate-related-risks.html',
    'https://www.shell.com/energy-and-innovation/the-energy-future/scenarios.html',
  ],
  'bp': [
    'https://www.bp.com/content/dam/bp/business-sites/en/global/corporate/pdfs/sustainability/group-reports/bp-sustainability-report-2023.pdf',
    'https://www.bp.com/content/dam/bp/business-sites/en/global/corporate/pdfs/sustainability/group-reports/bp-tcfd-report-2023.pdf',
  ],
  'exxon': [
    'https://corporate.exxonmobil.com/-/media/Global/Files/sustainability-report/publication/Sustainability-Report.pdf',
    'https://corporate.exxonmobil.com/-/media/Global/Files/energy-and-carbon-summary/Energy-and-Carbon-Summary.pdf',
  ],
  'chevron': [
    'https://www.chevron.com/-/media/chevron/sustainability/documents/2023-corporate-sustainability-report.pdf',
    'https://www.chevron.com/-/media/chevron/sustainability/documents/climate-change-resilience.pdf',
  ],
  'totalenergies': [
    'https://totalenergies.com/sites/g/files/nytnzq121/files/documents/2024-03/Sustainability_Climate_2024_Progress_Report_EN.pdf',
  ],
  'microsoft': [
    'https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RW1lMjE',
  ],
  'apple': [
    'https://www.apple.com/environment/pdf/Apple_Environmental_Progress_Report_2024.pdf',
  ],
  'amazon': [
    'https://sustainability.aboutamazon.com/2022-sustainability-report.pdf',
  ],
};

const SEC_EDGAR_CIK_MAP: Record<string, string> = {
  'shell': '1306965',
  'bp': '313807',
  'exxon': '34088',
  'exxonmobil': '34088',
  'chevron': '93410',
  'conocophillips': '1163165',
};

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
];

function getRandomUserAgent(): string {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

function normalizeCompanyName(name: string): string {
  return name.toLowerCase()
    .replace(/\s*(plc|inc|corp|corporation|ltd|limited|co|company|group|holdings)\s*\.?$/i, '')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

function detectDocumentType(url: string): 'pdf' | 'html' {
  const lowerUrl = url.toLowerCase();
  if (lowerUrl.endsWith('.pdf') || lowerUrl.includes('.pdf?') || lowerUrl.includes('/pdf/')) {
    return 'pdf';
  }
  if (lowerUrl.includes('filetype=pdf') || lowerUrl.includes('format=pdf')) {
    return 'pdf';
  }
  return 'html';
}

async function searchGoogle(companyName: string): Promise<DiscoveredDocument[]> {
  if (!GOOGLE_API_KEY || !SEARCH_ENGINE_ID) {
    console.warn("Google Search API keys missing - skipping Google search");
    return [];
  }

  const year = new Date().getFullYear();
  const results: DiscoveredDocument[] = [];
  const seenUrls = new Set<string>();

  for (const template of SEARCH_QUERY_TEMPLATES) {
    const query = template.query
      .replace('{company}', companyName)
      .replace('{year}', year.toString());
    
    try {
      const url = `https://www.googleapis.com/customsearch/v1?key=${GOOGLE_API_KEY}&cx=${SEARCH_ENGINE_ID}&q=${encodeURIComponent(query)}&num=5`;
      const response = await axios.get(url, { timeout: 10000 });
      
      const items = response.data.items || [];
      for (const item of items) {
        const docUrl = item.link;
        if (!seenUrls.has(docUrl)) {
          seenUrls.add(docUrl);
          results.push({
            title: item.title,
            url: docUrl,
            snippet: item.snippet,
            type: detectDocumentType(docUrl),
            source: 'google',
            priority: template.priority,
          });
        }
      }
      
      await new Promise(r => setTimeout(r, 200));
    } catch (error: any) {
      if (error.response?.status === 429) {
        console.warn("Google API rate limit reached");
        break;
      }
      console.error(`Search failed for "${query}":`, error.message);
    }
  }

  return results;
}

async function searchSECEdgar(companyName: string): Promise<DiscoveredDocument[]> {
  const normalizedName = normalizeCompanyName(companyName);
  const results: DiscoveredDocument[] = [];
  
  const cik = SEC_EDGAR_CIK_MAP[normalizedName];
  
  try {
    let searchUrl: string;
    if (cik) {
      searchUrl = `https://efts.sec.gov/LATEST/search-index?q=climate%20risk&dateRange=custom&startdt=2023-01-01&enddt=2025-12-31&forms=10-K,10-Q,20-F&ciks=${cik}`;
    } else {
      searchUrl = `https://efts.sec.gov/LATEST/search-index?q="${encodeURIComponent(companyName)}"%20climate%20risk&dateRange=custom&startdt=2023-01-01&enddt=2025-12-31&forms=10-K,10-Q,20-F`;
    }
    
    const response = await axios.get(searchUrl, {
      timeout: 15000,
      headers: { 
        'User-Agent': 'ClimateRiskAnalyzer/1.0 (climate.analyzer@example.com)',
        'Accept': 'application/json',
      },
    });
    
    const hits = response.data?.hits?.hits || [];
    for (const hit of hits.slice(0, 5)) {
      const filing = hit._source;
      if (filing && filing.file_num) {
        const filingUrl = `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${filing.ciks?.[0] || cik}&type=${filing.form}&dateb=&owner=include&count=10&search_text=`;
        results.push({
          title: `${filing.display_names?.[0] || companyName} - ${filing.form} Filing`,
          url: filingUrl,
          snippet: `SEC ${filing.form} filing with climate risk disclosures`,
          type: 'html',
          source: 'sec_edgar',
          priority: 2,
        });
      }
    }
  } catch (error: any) {
    console.log(`SEC EDGAR search: ${error.message}`);
  }
  
  if (cik) {
    try {
      const filingIndexUrl = `https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=${cik}&type=10-K&dateb=&owner=include&count=5&output=atom`;
      const response = await axios.get(filingIndexUrl, {
        timeout: 10000,
        headers: { 'User-Agent': 'ClimateRiskAnalyzer/1.0 (climate.analyzer@example.com)' },
      });
      
      const $ = cheerio.load(response.data, { xmlMode: true });
      $('entry').each((i, entry) => {
        const title = $(entry).find('title').text();
        const link = $(entry).find('link').attr('href');
        if (link && i < 3) {
          results.push({
            title: title || `${companyName} SEC 10-K Filing`,
            url: link,
            type: 'html',
            source: 'sec_edgar',
            priority: 2,
          });
        }
      });
    } catch (error: any) {
      console.log(`SEC filing index fetch: ${error.message}`);
    }
  }
  
  return results;
}

async function getKnownReports(companyName: string): Promise<DiscoveredDocument[]> {
  const normalizedName = normalizeCompanyName(companyName);
  const results: DiscoveredDocument[] = [];
  
  for (const [company, urls] of Object.entries(KNOWN_REPORT_PATTERNS)) {
    if (normalizedName.includes(company) || company.includes(normalizedName)) {
      for (const url of urls) {
        results.push({
          title: `${companyName} - Known Sustainability Report`,
          url,
          type: detectDocumentType(url),
          source: 'known_pattern',
          priority: 0,
        });
      }
    }
  }
  
  return results;
}

async function scrapeCompanyWebsite(companyName: string): Promise<DiscoveredDocument[]> {
  const results: DiscoveredDocument[] = [];
  const normalizedName = normalizeCompanyName(companyName);
  
  const possibleDomains = [
    `https://www.${normalizedName}.com`,
    `https://corporate.${normalizedName}.com`,
    `https://${normalizedName}.com`,
  ];
  
  const sustainabilityPaths = [
    '/sustainability',
    '/sustainability/reports',
    '/sustainability/reporting',
    '/investors/annual-reports',
    '/about/sustainability',
    '/responsibility',
    '/esg',
    '/climate',
  ];
  
  for (const domain of possibleDomains) {
    for (const path of sustainabilityPaths) {
      try {
        const url = `${domain}${path}`;
        const response = await axios.get(url, {
          timeout: 8000,
          headers: {
            'User-Agent': getRandomUserAgent(),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
          },
          maxRedirects: 5,
          validateStatus: (status) => status < 400,
        });
        
        const $ = cheerio.load(response.data);
        
        $('a[href*=".pdf"], a[href*="report"], a[href*="sustainability"], a[href*="annual"]').each((i, el) => {
          const href = $(el).attr('href');
          const text = $(el).text().trim();
          
          if (href && (
            href.toLowerCase().includes('sustainability') ||
            href.toLowerCase().includes('annual') ||
            href.toLowerCase().includes('climate') ||
            href.toLowerCase().includes('tcfd') ||
            href.toLowerCase().includes('esg') ||
            text.toLowerCase().includes('report')
          )) {
            let fullUrl = href;
            if (href.startsWith('/')) {
              fullUrl = `${domain}${href}`;
            } else if (!href.startsWith('http')) {
              fullUrl = `${domain}/${href}`;
            }
            
            if (!results.some(r => r.url === fullUrl)) {
              results.push({
                title: text || `${companyName} Report`,
                url: fullUrl,
                type: detectDocumentType(fullUrl),
                source: 'website_scrape',
                priority: 1,
              });
            }
          }
        });
        
        if (results.length > 0) {
          break;
        }
      } catch (error) {
      }
    }
    
    if (results.length > 0) {
      break;
    }
  }
  
  return results.slice(0, 10);
}

async function searchReportAggregators(companyName: string): Promise<DiscoveredDocument[]> {
  const results: DiscoveredDocument[] = [];
  const encodedName = encodeURIComponent(companyName);
  
  const aggregators = [
    {
      url: `https://www.responsibilityreports.com/Companies?search=${encodedName}`,
      name: 'ResponsibilityReports',
    },
    {
      url: `https://www.annualreports.com/Company/${encodedName.toLowerCase().replace(/\s+/g, '-')}`,
      name: 'AnnualReports',
    },
  ];
  
  for (const aggregator of aggregators) {
    try {
      const response = await axios.get(aggregator.url, {
        timeout: 10000,
        headers: { 'User-Agent': getRandomUserAgent() },
        validateStatus: (status) => status < 400,
      });
      
      const $ = cheerio.load(response.data);
      
      $('a[href*=".pdf"]').each((i, el) => {
        if (i >= 5) return;
        const href = $(el).attr('href');
        const text = $(el).text().trim();
        
        if (href) {
          let fullUrl = href;
          if (!href.startsWith('http')) {
            const baseUrl = new URL(aggregator.url);
            fullUrl = `${baseUrl.origin}${href.startsWith('/') ? '' : '/'}${href}`;
          }
          
          results.push({
            title: text || `${companyName} Report from ${aggregator.name}`,
            url: fullUrl,
            type: 'pdf',
            source: aggregator.name.toLowerCase(),
            priority: 2,
          });
        }
      });
    } catch (error) {
    }
  }
  
  return results;
}

export async function searchCompanyDocuments(companyName: string): Promise<DiscoveredDocument[]> {
  console.log(`Starting comprehensive document discovery for: ${companyName}`);
  
  const allResults: DiscoveredDocument[] = [];
  const seenUrls = new Set<string>();
  
  const discoveryTasks = [
    { name: 'known_reports', task: getKnownReports(companyName) },
    { name: 'google_search', task: searchGoogle(companyName) },
    { name: 'sec_edgar', task: searchSECEdgar(companyName) },
    { name: 'website_scrape', task: scrapeCompanyWebsite(companyName) },
    { name: 'aggregators', task: searchReportAggregators(companyName) },
  ];
  
  const results = await Promise.allSettled(discoveryTasks.map(t => t.task));
  
  results.forEach((result, index) => {
    const taskName = discoveryTasks[index].name;
    if (result.status === 'fulfilled') {
      console.log(`  ${taskName}: found ${result.value.length} documents`);
      for (const doc of result.value) {
        if (!seenUrls.has(doc.url)) {
          seenUrls.add(doc.url);
          allResults.push(doc);
        }
      }
    } else {
      console.log(`  ${taskName}: failed - ${result.reason}`);
    }
  });
  
  allResults.sort((a, b) => {
    if (a.type === 'pdf' && b.type !== 'pdf') return -1;
    if (a.type !== 'pdf' && b.type === 'pdf') return 1;
    return a.priority - b.priority;
  });
  
  console.log(`Total unique documents found: ${allResults.length}`);
  
  return allResults.slice(0, 15);
}

export { DiscoveredDocument };
