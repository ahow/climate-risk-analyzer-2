import * as XLSX from 'xlsx';
import axios from 'axios';

export async function fetchCompanyList(url: string): Promise<any[]> {
  try {
    const response = await axios.get(url, { responseType: 'arraybuffer' });
    const workbook = XLSX.read(response.data, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(sheet);
    return data;
  } catch (error) {
    console.error("Error fetching company list:", error);
    throw new Error("Failed to fetch or parse Excel file");
  }
}
