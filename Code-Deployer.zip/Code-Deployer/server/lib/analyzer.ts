import Anthropic from '@anthropic-ai/sdk';
import { MEASURES, CATEGORIES, type Measure } from '@shared/measures';
import type { InsertMeasureScore } from '@shared/schema';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY || 'dummy',
});

export interface MeasureAnalysisResult {
  measureId: string;
  score: number;
  evidenceSummary: string;
  coverage?: string;
  confidence: 'High' | 'Medium' | 'Low';
  quotes: Array<{ text: string; source: string; page?: string }>;
}

export interface CategoryAnalysisResult {
  categoryNumber: number;
  categoryName: string;
  measures: MeasureAnalysisResult[];
}

export interface CompanyAnalysisResult {
  companyName: string;
  totalScore: number;
  maxPossibleScore: number;
  scorePercentage: number;
  categories: CategoryAnalysisResult[];
  summary: string;
  analyzedAt: Date;
}

function getMeasuresByCategory(categoryNumber: number): Measure[] {
  return MEASURES.filter(m => m.categoryNumber === categoryNumber);
}

function buildMeasurePrompt(measures: Measure[]): string {
  return measures.map(m => `
**${m.id}: ${m.title}**
Definition: ${m.definition}

What Constitutes Evidence:
${m.whatConstitutesEvidence.map(e => `- ${e}`).join('\n')}

What Does NOT Constitute Evidence:
${m.whatDoesNotConstituteEvidence.map(e => `- ${e}`).join('\n')}

Scoring Guidance:
${Object.entries(m.scoringGuidance).map(([score, desc]) => `- Score ${score}: ${desc}`).join('\n')}
${m.coverageMetric ? `\nCoverage Metric: ${m.coverageMetric}` : ''}
${m.notes ? `\nNotes: ${m.notes}` : ''}
`).join('\n---\n');
}

function reconcileMeasures(
  categoryMeasures: Measure[],
  llmResults: MeasureAnalysisResult[]
): MeasureAnalysisResult[] {
  const resultMap = new Map(llmResults.map(r => [r.measureId, r]));
  
  return categoryMeasures.map(measure => {
    const existing = resultMap.get(measure.id);
    if (existing) {
      return {
        measureId: measure.id,
        score: Math.min(5, Math.max(0, existing.score || 0)),
        evidenceSummary: existing.evidenceSummary || "No evidence found",
        coverage: existing.coverage,
        confidence: existing.confidence || 'Low',
        quotes: existing.quotes || []
      };
    }
    console.warn(`Measure ${measure.id} was missing from LLM output, auto-filling with score 0`);
    return {
      measureId: measure.id,
      score: 0,
      evidenceSummary: "No evidence found in analyzed documents",
      coverage: undefined,
      confidence: 'Low' as const,
      quotes: []
    };
  });
}

async function analyzeCategory(
  companyName: string,
  categoryNumber: number,
  categoryName: string,
  documentText: string
): Promise<CategoryAnalysisResult> {
  const measures = getMeasuresByCategory(categoryNumber);
  
  if (!process.env.ANTHROPIC_API_KEY) {
    return {
      categoryNumber,
      categoryName,
      measures: measures.map(m => ({
        measureId: m.id,
        score: 0,
        evidenceSummary: "API key not configured",
        confidence: 'Low' as const,
        quotes: []
      }))
    };
  }

  const measureDefinitions = buildMeasurePrompt(measures);
  
  const prompt = `You are an expert analyst evaluating "${companyName}" on their physical climate risk management practices.

TASK: Analyze the provided documents and score EACH measure in Category ${categoryNumber}: ${categoryName}

SCORING PHILOSOPHY:
- This assessment specifically evaluates PHYSICAL climate risk management (floods, storms, heat, sea level rise, drought, wildfires)
- Transition risk content (emissions reduction, net zero, decarbonization) is NOT directly relevant but may indicate general climate awareness
- Award partial credit (scores 1-2) when there is general climate risk awareness even if not specifically "physical risk" focused
- Award higher scores (3-5) only when there is explicit, specific physical risk management evidence

INSTRUCTIONS:
1. Only use evidence directly from the provided text - DO NOT make up or assume information
2. If no evidence exists for a measure, score it 0 and state "No evidence found"
3. If evidence exists but is not specific to physical risk, score 1-2 and explain the gap
4. Extract EXACT QUOTES from the text as evidence (include the verbatim text)
5. Consider that companies may use different terminology:
   - "Climate resilience" often means physical risk adaptation
   - "Extreme weather" refers to physical hazards
   - "Asset integrity" in climate context may relate to physical risk
   - "Scenario analysis" may include physical risk scenarios
6. YOU MUST INCLUDE ALL ${measures.length} MEASURES in your response - do not skip any

MEASURES TO EVALUATE:
${measureDefinitions}

DOCUMENTS TO ANALYZE:
${documentText}

RESPONSE FORMAT (JSON):
{
  "measures": [
    {
      "measureId": "M01",
      "score": 3,
      "evidenceSummary": "Brief explanation of what evidence was found and why this score was assigned",
      "coverage": "e.g., '80% of facilities' or null if not applicable",
      "confidence": "High|Medium|Low",
      "quotes": [
        {
          "text": "Exact quote from document",
          "source": "Document name or section",
          "page": "Page number if available"
        }
      ]
    }
  ]
}

IMPORTANT: You MUST include ALL ${measures.length} measures (${measures.map(m => m.id).join(', ')}). Return ONLY valid JSON.`;

  const maxRetries = 2;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      console.log(`  Calling Claude API for category ${categoryNumber} (attempt ${attempt + 1})...`);
      
      const response = await anthropic.messages.create({
        model: "claude-sonnet-4-20250514",
        max_tokens: 6000,
        messages: [{ role: "user", content: prompt }]
      });

      const content = (response.content[0] as any).text;
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        const reconciledMeasures = reconcileMeasures(measures, parsed.measures || []);
        console.log(`  Category ${categoryNumber} completed: ${reconciledMeasures.filter(m => m.score > 0).length}/${measures.length} measures with evidence`);
        return {
          categoryNumber,
          categoryName,
          measures: reconciledMeasures
        };
      } else {
        console.warn(`  Category ${categoryNumber}: No JSON found in response`);
      }
    } catch (error: any) {
      const errorMessage = error.message || String(error);
      const isRateLimit = errorMessage.includes('429') || errorMessage.includes('rate_limit');
      console.error(`  Category ${categoryNumber} attempt ${attempt + 1} failed: ${isRateLimit ? 'Rate limit' : errorMessage.slice(0, 100)}`);
      
      if (attempt < maxRetries) {
        const baseDelay = isRateLimit ? 30000 : 2000;
        const delay = baseDelay * Math.pow(2, attempt);
        console.log(`  Retrying in ${delay / 1000}s...`);
        await new Promise(r => setTimeout(r, delay));
      }
    }
  }
  
  console.error(`Category ${categoryNumber} failed after ${maxRetries + 1} attempts`);
  
  return {
    categoryNumber,
    categoryName,
    measures: measures.map(m => ({
      measureId: m.id,
      score: 0,
      evidenceSummary: "Analysis failed",
      confidence: 'Low' as const,
      quotes: []
    }))
  };
}

function prepareDocumentText(documentsText: string[], maxLength: number = 100000): string {
  const deduped: string[] = [];
  const seen = new Set<string>();
  
  for (const doc of documentsText) {
    if (!doc || doc.length < 100) continue;
    const fingerprint = doc.slice(0, 500).toLowerCase().replace(/\s+/g, ' ');
    if (!seen.has(fingerprint)) {
      seen.add(fingerprint);
      const truncatedDoc = doc.length > 50000 ? doc.slice(0, 50000) + "\n[Document truncated...]" : doc;
      deduped.push(truncatedDoc);
    }
  }
  
  const combined = deduped.join("\n\n=== NEXT DOCUMENT ===\n\n");
  return combined.length > maxLength ? combined.slice(0, maxLength) : combined;
}

export async function analyzeCompanyMeasures(
  companyName: string,
  documentsText: string[]
): Promise<CompanyAnalysisResult> {
  const combinedText = prepareDocumentText(documentsText, 100000);
  
  const categoryResults: CategoryAnalysisResult[] = [];
  
  for (const category of CATEGORIES) {
    console.log(`Analyzing category ${category.number}: ${category.name}...`);
    const result = await analyzeCategory(
      companyName,
      category.number,
      category.name,
      combinedText
    );
    categoryResults.push(result);
  }
  
  const allMeasures = categoryResults.flatMap(c => c.measures);
  const totalScore = allMeasures.reduce((sum, m) => sum + (m.score || 0), 0);
  const maxPossibleScore = MEASURES.length * 5;
  
  return {
    companyName,
    totalScore,
    maxPossibleScore,
    scorePercentage: Math.round((totalScore / maxPossibleScore) * 100),
    categories: categoryResults,
    summary: `Analyzed ${allMeasures.length} measures across ${CATEGORIES.length} categories. Total score: ${totalScore}/${maxPossibleScore} (${Math.round((totalScore / maxPossibleScore) * 100)}%)`,
    analyzedAt: new Date()
  };
}

export function convertToMeasureScores(
  companyId: number,
  analysisResult: CompanyAnalysisResult
): InsertMeasureScore[] {
  const scores: InsertMeasureScore[] = [];
  
  for (const category of analysisResult.categories) {
    for (const measureResult of category.measures) {
      const measureDef = MEASURES.find(m => m.id === measureResult.measureId);
      if (!measureDef) continue;
      
      scores.push({
        companyId,
        measureId: measureResult.measureId,
        category: category.categoryName,
        categoryNumber: category.categoryNumber,
        title: measureDef.title,
        score: measureResult.score || 0,
        evidenceSummary: measureResult.evidenceSummary || null,
        coverage: measureResult.coverage || null,
        confidence: measureResult.confidence || 'Low',
        quotes: measureResult.quotes || []
      });
    }
  }
  
  return scores;
}

export async function analyzeCompanyRisk(companyName: string, documentsText: string[]): Promise<any> {
  const result = await analyzeCompanyMeasures(companyName, documentsText);
  return {
    score: result.scorePercentage,
    summary: result.summary,
    totalScore: result.totalScore,
    maxPossibleScore: result.maxPossibleScore,
    categories: result.categories
  };
}
