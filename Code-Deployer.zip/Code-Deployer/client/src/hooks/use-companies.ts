import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type ImportInput, type AnalyzeInput } from "@shared/routes";

// ============================================
// HOOKS
// ============================================

export function useCompanies(search?: string, sort?: 'score' | 'name' | 'updated') {
  return useQuery({
    queryKey: [api.companies.list.path, search, sort],
    queryFn: async () => {
      // Build query string manually since fetch doesn't support params object directly
      const params = new URLSearchParams();
      if (search) params.append("search", search);
      if (sort) params.append("sort", sort);
      
      const url = `${api.companies.list.path}?${params.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch companies");
      return api.companies.list.responses[200].parse(await res.json());
    },
  });
}

export function useCompany(id: number) {
  return useQuery({
    queryKey: [api.companies.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.companies.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch company details");
      return api.companies.get.responses[200].parse(await res.json());
    },
    // Poll while analyzing to update status live
    refetchInterval: (query) => {
      const status = query.state.data?.analysisStatus;
      return (status === 'searching' || status === 'analyzing') ? 2000 : false;
    }
  });
}

export function useImportCompanies() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: ImportInput) => {
      const validated = api.companies.import.input.parse(data);
      const res = await fetch(api.companies.import.path, {
        method: api.companies.import.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.companies.import.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to import companies");
      }
      return api.companies.import.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.companies.list.path] });
    },
  });
}

export function useAnalyzeCompany() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, forceRefresh }: { id: number } & AnalyzeInput) => {
      const url = buildUrl(api.companies.analyze.path, { id });
      const validated = api.companies.analyze.input.parse({ forceRefresh });
      
      const res = await fetch(url, {
        method: api.companies.analyze.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        if (res.status === 404) throw new Error("Company not found");
        throw new Error("Failed to start analysis");
      }
      return api.companies.analyze.responses[202].parse(await res.json());
    },
    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries({ queryKey: [api.companies.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.companies.get.path, id] });
    },
  });
}
