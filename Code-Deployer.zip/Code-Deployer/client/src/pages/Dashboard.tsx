import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useCompanies } from "@/hooks/use-companies";
import { Layout } from "@/components/Layout";
import { ImportDialog } from "@/components/ImportDialog";
import { StatusBadge } from "@/components/StatusBadge";
import { ScoreIndicator } from "@/components/ScoreIndicator";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Search, Filter, ArrowUpDown, Building2, Play, Download, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { apiRequest } from "@/lib/queryClient";

type BatchStatus = {
  isRunning: boolean;
  currentCompany: string;
  completed: number;
  total: number;
  failed: number;
};

export default function Dashboard() {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<'score' | 'name' | 'updated'>('name');
  const { data: companies, isLoading, error, refetch } = useCompanies(search, sortBy);
  const [batchStatus, setBatchStatus] = useState<BatchStatus | null>(null);
  const [isStartingBatch, setIsStartingBatch] = useState(false);

  useEffect(() => {
    const pollStatus = async () => {
      try {
        const res = await fetch('/api/batch/status');
        const status = await res.json();
        setBatchStatus(status);
        if (status.isRunning) {
          refetch();
        }
      } catch (e) {}
    };
    pollStatus();
    const interval = setInterval(pollStatus, 5000);
    return () => clearInterval(interval);
  }, [refetch]);

  const startBatchAnalysis = async () => {
    setIsStartingBatch(true);
    try {
      await apiRequest('POST', '/api/batch/analyze');
      setBatchStatus({ isRunning: true, currentCompany: '', completed: 0, total: 0, failed: 0 });
    } catch (e) {
      console.error('Failed to start batch:', e);
    }
    setIsStartingBatch(false);
  };

  const downloadExport = () => {
    window.open('/api/export/spreadsheet', '_blank');
  };

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-display font-bold text-slate-900 dark:text-white">Company Analysis</h1>
            <p className="text-slate-500 dark:text-slate-400 mt-1">Monitor climate risk exposure across your portfolio.</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <ImportDialog />
            <Button 
              onClick={startBatchAnalysis} 
              disabled={batchStatus?.isRunning || isStartingBatch}
              data-testid="button-batch-analyze"
            >
              {batchStatus?.isRunning || isStartingBatch ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Analyze All
                </>
              )}
            </Button>
            <Button variant="outline" onClick={downloadExport} data-testid="button-export">
              <Download className="w-4 h-4 mr-2" />
              Export Results
            </Button>
          </div>
        </div>

        {/* Batch Progress */}
        {batchStatus?.isRunning && (
          <Card className="border-emerald-200 bg-emerald-50 dark:bg-emerald-950 dark:border-emerald-800">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-emerald-800 dark:text-emerald-200">
                  Batch Analysis in Progress
                </span>
                <span className="text-sm text-emerald-600 dark:text-emerald-400">
                  {batchStatus.completed} / {batchStatus.total} complete
                  {batchStatus.failed > 0 && ` (${batchStatus.failed} failed)`}
                </span>
              </div>
              <Progress value={batchStatus.total ? (batchStatus.completed / batchStatus.total) * 100 : 0} className="h-2" />
              {batchStatus.currentCompany && (
                <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-2">
                  Currently analyzing: {batchStatus.currentCompany}
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Stats Section - Quick Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl p-6 text-white shadow-lg shadow-emerald-500/20">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-100 font-medium text-sm">Total Companies</p>
                <h3 className="text-3xl font-bold mt-1">{companies?.length || 0}</h3>
              </div>
              <Building2 className="w-10 h-10 text-emerald-200/50" />
            </div>
            <div className="mt-4 pt-4 border-t border-white/10 text-xs text-emerald-100 flex items-center gap-2">
              <span className="bg-white/20 px-1.5 py-0.5 rounded">Live</span>
              Monitoring active portfolio
            </div>
          </div>
          
          <Card className="rounded-2xl shadow-sm border-slate-200">
            <CardContent className="p-6">
              <p className="text-slate-500 font-medium text-sm">Pending Analysis</p>
              <h3 className="text-3xl font-bold text-slate-900 mt-1">
                {companies?.filter(c => c.analysisStatus === 'idle').length || 0}
              </h3>
              <p className="text-xs text-slate-400 mt-4">Companies waiting for data processing</p>
            </CardContent>
          </Card>
          
          <Card className="rounded-2xl shadow-sm border-slate-200">
            <CardContent className="p-6">
              <p className="text-slate-500 font-medium text-sm">Completed</p>
              <h3 className="text-3xl font-bold text-slate-900 mt-1">
                {companies?.filter(c => c.analysisStatus === 'completed').length || 0}
              </h3>
              <p className="text-xs text-slate-400 mt-4">Full risk reports generated</p>
            </CardContent>
          </Card>
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 rounded-xl shadow-sm border border-slate-200">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input 
              placeholder="Search companies by name or ISIN..." 
              className="pl-9 bg-slate-50 border-slate-200 focus:bg-white transition-colors"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              onClick={() => setSortBy(sortBy === 'score' ? 'name' : 'score')}
              className="min-w-[140px] justify-between"
            >
              <span className="flex items-center gap-2 text-slate-600">
                <ArrowUpDown className="w-4 h-4" />
                {sortBy === 'score' ? 'Sort: Risk Score' : 'Sort: Name'}
              </span>
            </Button>
            <Button variant="outline" size="icon" title="Filter options">
              <Filter className="w-4 h-4 text-slate-500" />
            </Button>
          </div>
        </div>

        {/* Companies List */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
          {isLoading ? (
            <div className="p-12 text-center text-slate-400">Loading companies...</div>
          ) : error ? (
            <div className="p-12 text-center text-red-500">Error loading data.</div>
          ) : companies?.length === 0 ? (
            <div className="p-12 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Building2 className="w-8 h-8 text-slate-300" />
              </div>
              <h3 className="text-lg font-medium text-slate-900">No companies found</h3>
              <p className="text-slate-500 mb-6">Import data to get started with analysis.</p>
              <ImportDialog />
            </div>
          ) : (
            <div className="divide-y divide-slate-100">
              <div className="grid grid-cols-12 gap-4 px-6 py-3 bg-slate-50/80 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <div className="col-span-4">Company</div>
                <div className="col-span-2">Sector</div>
                <div className="col-span-2">Country</div>
                <div className="col-span-2">Status</div>
                <div className="col-span-2 text-right">Risk Score</div>
              </div>
              
              {companies?.map((company) => (
                <Link key={company.id} href={`/company/${company.id}`}>
                  <div className="grid grid-cols-12 gap-4 px-6 py-4 items-center hover:bg-slate-50 transition-colors cursor-pointer group">
                    <div className="col-span-4">
                      <div className="font-semibold text-slate-900 group-hover:text-primary transition-colors">
                        {company.name}
                      </div>
                      <div className="text-xs text-slate-400 font-mono mt-0.5">{company.isin}</div>
                    </div>
                    <div className="col-span-2 text-sm text-slate-600">{company.sector}</div>
                    <div className="col-span-2 text-sm text-slate-600">{company.country}</div>
                    <div className="col-span-2">
                      <StatusBadge status={company.analysisStatus} />
                    </div>
                    <div className="col-span-2 flex justify-end">
                      <ScoreIndicator score={company.totalScore} />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
