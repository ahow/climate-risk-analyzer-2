import { useRoute, Link } from "wouter";
import { useCompany, useAnalyzeCompany } from "@/hooks/use-companies";
import { Layout } from "@/components/Layout";
import { StatusBadge } from "@/components/StatusBadge";
import { ScoreIndicator } from "@/components/ScoreIndicator";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ChevronLeft, RefreshCw, FileText, ExternalLink, Calendar, MapPin, Briefcase, Quote, CheckCircle, AlertCircle } from "lucide-react";
import ReactMarkdown from 'react-markdown';
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import type { MeasureScore } from "@shared/schema";

function getScoreColor(score: number): string {
  if (score === 0) return "bg-slate-100 text-slate-500";
  if (score <= 2) return "bg-red-50 text-red-700 border-red-200";
  if (score <= 3) return "bg-amber-50 text-amber-700 border-amber-200";
  return "bg-emerald-50 text-emerald-700 border-emerald-200";
}

function getConfidenceColor(confidence: string): string {
  switch (confidence) {
    case 'High': return "bg-emerald-100 text-emerald-700";
    case 'Medium': return "bg-amber-100 text-amber-700";
    default: return "bg-slate-100 text-slate-500";
  }
}

function MeasureScoresDisplay({ measureScores }: { measureScores: MeasureScore[] }) {
  if (!measureScores || measureScores.length === 0) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center text-slate-500 border border-slate-200">
        <AlertCircle className="w-12 h-12 mx-auto mb-4 opacity-20" />
        <p>No measure scores available yet.</p>
        <p className="text-sm mt-2">Run analysis to evaluate this company against the 44-measure framework.</p>
      </div>
    );
  }

  const groupedByCategory = measureScores.reduce((acc, score) => {
    const key = `${score.categoryNumber}-${score.category}`;
    if (!acc[key]) {
      acc[key] = { categoryNumber: score.categoryNumber, categoryName: score.category, measures: [] };
    }
    acc[key].measures.push(score);
    return acc;
  }, {} as Record<string, { categoryNumber: number; categoryName: string; measures: MeasureScore[] }>);

  const categories = Object.values(groupedByCategory).sort((a, b) => a.categoryNumber - b.categoryNumber);
  
  const totalScore = measureScores.reduce((sum, m) => sum + (m.score || 0), 0);
  const maxScore = measureScores.length * 5;
  const overallPercentage = maxScore > 0 ? Math.round((totalScore / maxScore) * 100) : 0;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between gap-4 pb-2">
          <CardTitle className="text-lg">Overall Assessment</CardTitle>
          <Badge variant="outline" className="text-lg px-3 py-1">
            {totalScore} / {maxScore} ({overallPercentage}%)
          </Badge>
        </CardHeader>
        <CardContent>
          <Progress value={overallPercentage} className="h-3" />
          <p className="text-sm text-slate-500 mt-2">
            Evaluated {measureScores.length} measures across {categories.length} categories
          </p>
        </CardContent>
      </Card>

      <Accordion type="multiple" className="space-y-4">
        {categories.map((cat) => {
          const catScore = cat.measures.reduce((sum, m) => sum + (m.score || 0), 0);
          const catMax = cat.measures.length * 5;
          const catPct = catMax > 0 ? Math.round((catScore / catMax) * 100) : 0;

          return (
            <AccordionItem 
              key={cat.categoryNumber} 
              value={`cat-${cat.categoryNumber}`}
              className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-visible"
            >
              <AccordionTrigger className="px-6 py-4 hover:bg-slate-50">
                <div className="flex items-center gap-4 w-full text-left">
                  <Badge variant="secondary" className="font-mono">
                    {cat.categoryNumber}
                  </Badge>
                  <span className="font-semibold text-slate-800 flex-1">{cat.categoryName}</span>
                  <div className="flex items-center gap-2">
                    <Progress value={catPct} className="w-24 h-2" />
                    <span className="text-sm text-slate-500 w-16 text-right">{catScore}/{catMax}</span>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-6 pb-6">
                <div className="space-y-4">
                  {cat.measures.map((measure) => (
                    <div 
                      key={measure.id} 
                      className="border border-slate-100 rounded-lg p-4 hover:border-slate-200 transition-colors"
                      data-testid={`measure-score-${measure.measureId}`}
                    >
                      <div className="flex items-start justify-between gap-4 mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="outline" className="font-mono text-xs">{measure.measureId}</Badge>
                            <h4 className="font-medium text-slate-900">{measure.title}</h4>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Badge className={getScoreColor(measure.score)}>
                            {measure.score}/5
                          </Badge>
                          {measure.confidence && (
                            <Badge variant="outline" className={getConfidenceColor(measure.confidence)}>
                              {measure.confidence}
                            </Badge>
                          )}
                        </div>
                      </div>

                      {measure.evidenceSummary && (
                        <p className="text-sm text-slate-600 mb-3">{measure.evidenceSummary}</p>
                      )}

                      {measure.coverage && (
                        <p className="text-xs text-slate-500 mb-2">
                          <span className="font-medium">Coverage:</span> {measure.coverage}
                        </p>
                      )}

                      {measure.quotes && Array.isArray(measure.quotes) && measure.quotes.length > 0 && (
                        <div className="mt-3 space-y-2">
                          <p className="text-xs font-medium text-slate-500 flex items-center gap-1">
                            <Quote className="w-3 h-3" /> Evidence Quotes
                          </p>
                          {measure.quotes.map((quote: any, idx: number) => (
                            <blockquote 
                              key={idx} 
                              className="text-xs text-slate-600 border-l-2 border-primary/30 pl-3 py-1 bg-slate-50 rounded-r"
                            >
                              "{quote.text}"
                              {quote.source && (
                                <cite className="block text-slate-400 mt-1 not-italic">
                                  - {quote.source}{quote.page ? `, p.${quote.page}` : ''}
                                </cite>
                              )}
                            </blockquote>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}

export default function CompanyDetail() {
  const [match, params] = useRoute("/company/:id");
  const id = parseInt(params?.id || "0");
  const { data: company, isLoading, error } = useCompany(id);
  const { mutate: analyze, isPending: isAnalyzing } = useAnalyzeCompany();
  const { toast } = useToast();

  if (isLoading) return <div className="h-screen flex items-center justify-center bg-slate-50">Loading details...</div>;
  if (error || !company) return <div className="h-screen flex items-center justify-center bg-slate-50">Company not found</div>;

  const handleAnalyze = () => {
    analyze({ id, forceRefresh: true }, {
      onSuccess: () => {
        toast({ title: "Analysis Started", description: "Fetching documents and analyzing risk..." });
      },
      onError: (err) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const isBusy = company.analysisStatus === 'searching' || company.analysisStatus === 'analyzing';

  return (
    <Layout>
      {/* Breadcrumb & Back */}
      <div className="mb-6">
        <Link href="/" className="inline-flex items-center text-sm text-slate-500 hover:text-slate-800 transition-colors">
          <ChevronLeft className="w-4 h-4 mr-1" />
          Back to Dashboard
        </Link>
      </div>

      {/* Header Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 mb-8">
        <div className="flex flex-col md:flex-row justify-between gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-3xl font-display font-bold text-slate-900">{company.name}</h1>
              <Badge variant="outline" className="font-mono text-xs">{company.isin}</Badge>
            </div>
            
            <div className="flex flex-wrap gap-4 text-sm text-slate-500 mt-4">
              <div className="flex items-center gap-1.5">
                <Briefcase className="w-4 h-4 text-slate-400" />
                {company.sector} / {company.industry}
              </div>
              <div className="flex items-center gap-1.5">
                <MapPin className="w-4 h-4 text-slate-400" />
                {company.country}
              </div>
              <div className="flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-400" />
                Last updated: {company.updatedAt ? format(new Date(company.updatedAt), 'MMM dd, yyyy') : 'Never'}
              </div>
            </div>
            
            <div className="mt-6 flex items-center gap-4">
              <StatusBadge status={company.analysisStatus} />
              <Button 
                onClick={handleAnalyze} 
                disabled={isBusy || isAnalyzing}
                variant={isBusy ? "secondary" : "default"}
                size="sm"
                className="gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${isBusy ? "animate-spin" : ""}`} />
                {isBusy ? "Processing..." : "Run Analysis"}
              </Button>
            </div>
          </div>
          
          <div className="flex-shrink-0 flex items-center justify-center md:justify-end md:w-48 md:border-l border-slate-100 pl-6">
            <ScoreIndicator score={company.totalScore} size="lg" />
          </div>
        </div>
      </div>

      {/* Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="bg-white p-1 border border-slate-200 rounded-xl">
          <TabsTrigger value="overview" className="rounded-lg data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Overview</TabsTrigger>
          <TabsTrigger value="analysis" className="rounded-lg data-[state=active]:bg-primary/10 data-[state=active]:text-primary">Detailed Analysis</TabsTrigger>
          <TabsTrigger value="documents" className="rounded-lg data-[state=active]:bg-primary/10 data-[state=active]:text-primary">
            Documents ({company.documents?.length || 0})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-8 min-h-[400px]">
            {company.summary ? (
              <div className="prose prose-slate max-w-none prose-headings:font-display prose-headings:font-bold prose-h3:text-primary">
                <ReactMarkdown>{company.summary}</ReactMarkdown>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-64 text-slate-400">
                <FileText className="w-12 h-12 mb-4 opacity-20" />
                <p>No analysis summary available.</p>
                <Button variant="ghost" onClick={handleAnalyze} className="mt-2 text-primary">Run analysis to generate report</Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="analysis">
          <MeasureScoresDisplay measureScores={company.measureScores || []} />
        </TabsContent>

        <TabsContent value="documents">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <ScrollArea className="h-[500px]">
              <div className="divide-y divide-slate-100">
                {company.documents && company.documents.length > 0 ? (
                  company.documents.map((doc) => (
                    <div key={doc.id} className="p-4 flex items-center justify-between hover:bg-slate-50 transition-colors">
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className="p-2 bg-blue-50 text-blue-600 rounded-lg flex-shrink-0">
                          <FileText className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="font-medium text-slate-900 truncate pr-4" title={doc.title || doc.url}>
                            {doc.title || "Untitled Document"}
                          </h4>
                          <p className="text-xs text-slate-500 font-mono truncate max-w-[300px] md:max-w-md">
                            {doc.url}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 flex-shrink-0">
                        <div className="text-right hidden sm:block">
                          <Badge variant="secondary" className="text-xs">{doc.type.toUpperCase()}</Badge>
                          <p className="text-xs text-slate-400 mt-1">
                            {doc.publicationYear || "Year Unknown"}
                          </p>
                        </div>
                        <a 
                          href={doc.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="p-2 text-slate-400 hover:text-primary transition-colors"
                        >
                          <ExternalLink className="w-5 h-5" />
                        </a>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-12 text-center text-slate-500">
                    No documents discovered yet. Start analysis to find reports.
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        </TabsContent>
      </Tabs>
    </Layout>
  );
}
