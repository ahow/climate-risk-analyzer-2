import { useState } from "react";
import { useImportCompanies } from "@/hooks/use-companies";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { UploadCloud, FileSpreadsheet, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const DEFAULT_EXCEL_URL = "https://d2xsxph8kpxj0f.cloudfront.net/310419663031471125/Rur7xAEUjvByHVg3PaP3cz/uploads/public/1763385421369-kd42agn-ShortCompanyListACWI.xlsx";

export function ImportDialog() {
  const [isOpen, setIsOpen] = useState(false);
  const [url, setUrl] = useState(DEFAULT_EXCEL_URL);
  const { mutate, isPending } = useImportCompanies();
  const { toast } = useToast();

  const handleImport = (e: React.FormEvent) => {
    e.preventDefault();
    mutate({ url }, {
      onSuccess: (data) => {
        setIsOpen(false);
        toast({
          title: "Import Successful",
          description: `Imported ${data.count} companies successfully.`,
        });
      },
      onError: (err) => {
        toast({
          title: "Import Failed",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20 transition-all hover:-translate-y-0.5">
          <UploadCloud className="w-4 h-4 mr-2" />
          Import Data
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display text-xl">
            <div className="p-2 bg-green-100 rounded-lg text-green-700">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            Import Companies
          </DialogTitle>
          <DialogDescription>
            Enter the URL of an Excel file (.xlsx) containing company data.
            The file should have columns for Name, ISIN, Sector, etc.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleImport} className="space-y-4 mt-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Excel File URL</label>
            <Input 
              value={url} 
              onChange={(e) => setUrl(e.target.value)} 
              placeholder="https://example.com/data.xlsx"
              className="font-mono text-sm"
              required
            />
            <p className="text-xs text-slate-500 flex items-center gap-1">
              <AlertCircle className="w-3 h-3" />
              Default URL pre-filled for demonstration.
            </p>
          </div>
          
          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending} className="bg-primary hover:bg-primary/90">
              {isPending ? "Importing..." : "Start Import"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
