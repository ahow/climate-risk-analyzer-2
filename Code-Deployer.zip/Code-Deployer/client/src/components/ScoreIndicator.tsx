interface ScoreIndicatorProps {
  score: number | null | undefined;
  size?: "sm" | "lg";
}

export function ScoreIndicator({ score, size = "sm" }: ScoreIndicatorProps) {
  // Score range: 0 - 220 (approx)
  // Low Risk: 0-50 (Green)
  // Medium Risk: 51-100 (Yellow)
  // High Risk: 101+ (Red)
  
  if (score === null || score === undefined) {
    return (
      <div className={`
        inline-flex items-center justify-center rounded-lg bg-slate-100 text-slate-400 font-medium
        ${size === "lg" ? "w-16 h-16 text-xl" : "px-2 py-1 text-xs"}
      `}>
        -
      </div>
    );
  }

  const getColors = (s: number) => {
    if (s <= 50) return "bg-emerald-100 text-emerald-800 border-emerald-200";
    if (s <= 100) return "bg-amber-100 text-amber-800 border-amber-200";
    return "bg-rose-100 text-rose-800 border-rose-200";
  };

  const colorClass = getColors(score);

  if (size === "lg") {
    return (
      <div className="flex flex-col items-center gap-1">
        <div className={`
          flex items-center justify-center w-20 h-20 rounded-2xl border-2 shadow-sm
          text-3xl font-display font-bold ${colorClass}
        `}>
          {Math.round(score)}
        </div>
        <span className="text-xs font-medium text-slate-500 uppercase tracking-wide">Risk Score</span>
      </div>
    );
  }

  return (
    <div className={`
      inline-flex items-center justify-center px-2.5 py-1 rounded-md border text-sm font-bold shadow-sm
      ${colorClass}
    `}>
      {Math.round(score)}
    </div>
  );
}
