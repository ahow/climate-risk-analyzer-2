import { Loader2, CheckCircle, AlertCircle, Search, Clock } from "lucide-react";

type AnalysisStatus = "idle" | "searching" | "analyzing" | "completed" | "failed";

export function StatusBadge({ status }: { status: string }) {
  const normalizedStatus = status as AnalysisStatus;

  const config = {
    idle: {
      color: "bg-slate-100 text-slate-600 border-slate-200",
      icon: Clock,
      label: "Not Started"
    },
    searching: {
      color: "bg-blue-50 text-blue-700 border-blue-200",
      icon: Search,
      label: "Finding Docs"
    },
    analyzing: {
      color: "bg-amber-50 text-amber-700 border-amber-200",
      icon: Loader2,
      label: "Analyzing"
    },
    completed: {
      color: "bg-emerald-50 text-emerald-700 border-emerald-200",
      icon: CheckCircle,
      label: "Completed"
    },
    failed: {
      color: "bg-red-50 text-red-700 border-red-200",
      icon: AlertCircle,
      label: "Failed"
    }
  };

  const { color, icon: Icon, label } = config[normalizedStatus] || config.idle;
  const isAnimating = normalizedStatus === "searching" || normalizedStatus === "analyzing";

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${color}`}>
      <Icon className={`w-3.5 h-3.5 ${isAnimating ? "animate-spin" : ""}`} />
      {label}
    </span>
  );
}
